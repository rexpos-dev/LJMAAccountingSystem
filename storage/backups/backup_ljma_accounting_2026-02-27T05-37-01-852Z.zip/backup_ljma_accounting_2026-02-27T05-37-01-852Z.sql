/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: account_type
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `account_type` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `baseType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asset',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_type_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_job` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filePath` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileSize` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_schedule` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backupTime` datetime(3) NOT NULL,
  `frequency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: brand
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `brand` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brand_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `business_profile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `businessName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactTel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` longtext COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `bankDetails` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: category
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `category` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentCategoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `chart_of_account` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_no` int NOT NULL,
  `account_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` double DEFAULT '0',
  `account_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `last_updated_at` datetime(3) NOT NULL,
  `account_type_no` int NOT NULL DEFAULT '1',
  `account_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fs_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `account_type_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chart_of_account_account_no_key` (`account_no`),
  KEY `chart_of_account_account_type_id_fkey` (`account_type_id`),
  CONSTRAINT `chart_of_account_account_type_id_fkey` FOREIGN KEY (`account_type_id`) REFERENCES `account_type` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `conversion_factor` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `factor` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactFirstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phonePrimary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `creditLimit` double DEFAULT '0',
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'days',
  `paymentTermsValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '30',
  `salesperson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerGroup` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `isEntitledToLoyaltyPoints` tinyint(1) NOT NULL DEFAULT '0',
  `pointSetting` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loyaltyCalculationMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'automatic',
  `loyaltyCardNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer_payments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer_payments` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiptId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `syncedToLedger` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_payments_receiptId_key` (`receiptId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: inventory_transaction
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `inventory_transaction` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `referenceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_transaction_productId_fkey` (`productId`),
  CONSTRAINT `inventory_transaction_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: invoice
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerPONumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `terms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesperson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depositAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billingAddress` text COLLATE utf8mb4_unicode_ci,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci,
  `subtotal` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_invoiceNumber_key` (`invoiceNumber`),
  KEY `invoice_customerId_fkey` (`customerId`),
  CONSTRAINT `invoice_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: invoice_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `invoice_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL,
  `unitPrice` double NOT NULL,
  `total` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_item_invoiceId_fkey` (`invoiceId`),
  KEY `invoice_item_productId_fkey` (`productId`),
  CONSTRAINT `invoice_item_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_board
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_board` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_card
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_card` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `columnId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int NOT NULL,
  `transactionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kanban_card_transactionId_key` (`transactionId`),
  KEY `kanban_card_columnId_fkey` (`columnId`),
  CONSTRAINT `kanban_card_columnId_fkey` FOREIGN KEY (`columnId`) REFERENCES `kanban_column` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kanban_card_transactionId_fkey` FOREIGN KEY (`transactionId`) REFERENCES `inventory_transaction` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_column
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_column` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kanban_column_boardId_fkey` (`boardId`),
  CONSTRAINT `kanban_column_boardId_fkey` FOREIGN KEY (`boardId`) REFERENCES `kanban_board` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loyaltyCardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalPoints` double NOT NULL DEFAULT '0',
  `pointSettingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiryDate` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loyalty_point_customerId_fkey` (`customerId`),
  KEY `loyalty_point_pointSettingId_fkey` (`pointSettingId`),
  CONSTRAINT `loyalty_point_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loyalty_point_pointSettingId_fkey` FOREIGN KEY (`pointSettingId`) REFERENCES `loyalty_point_setting` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point_setting` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `equivalentPoint` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: notification
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `notification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_userId_idx` (`userId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: payables_ledger
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `payables_ledger` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ledger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountDescription` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debitAmount` double NOT NULL DEFAULT '0',
  `creditAmount` double NOT NULL DEFAULT '0',
  `user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: pos_sale_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `pos_sale_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `posSaleId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL,
  `unitPrice` double NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pos_sale_item_posSaleId_idx` (`posSaleId`),
  KEY `pos_sale_item_productId_idx` (`productId`),
  CONSTRAINT `pos_sale_item_posSaleId_fkey` FOREIGN KEY (`posSaleId`) REFERENCES `pos_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pos_sale_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: pos_sales
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `pos_sales` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiptId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `amount` double NOT NULL,
  `cashier` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `syncedToLedger` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `discount` double DEFAULT '0',
  `paymentMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` double DEFAULT '0',
  `tax` double DEFAULT '0',
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pos_sales_receiptId_key` (`receiptId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: pos_sync_log
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `pos_sync_log` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastSyncedAt` datetime(3) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SUCCESS',
  `recordsAdded` int NOT NULL DEFAULT '0',
  `errorMessage` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pos_sync_log_endpoint_key` (`endpoint`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalDescription` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brandId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplierId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitOfMeasureId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `costPrice` double NOT NULL DEFAULT '0',
  `stockQuantity` int NOT NULL DEFAULT '0',
  `minStockLevel` int NOT NULL DEFAULT '0',
  `maxStockLevel` int DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `salesOrder` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoCreateChildren` tinyint(1) NOT NULL DEFAULT '0',
  `initialStock` int NOT NULL DEFAULT '0',
  `reorderPoint` int NOT NULL DEFAULT '0',
  `incomeAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expenseAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product_history
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product_history` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `product_history_productId_fkey` (`productId`),
  CONSTRAINT `product_history_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_order
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplierId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `vendorAddress` text COLLATE utf8mb4_unicode_ci,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci,
  `taxType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `privateComments` text COLLATE utf8mb4_unicode_ci,
  `subtotal` double NOT NULL DEFAULT '0',
  `taxTotal` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `depositAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_supplierId_fkey` (`supplierId`),
  CONSTRAINT `purchase_order_supplierId_fkey` FOREIGN KEY (`supplierId`) REFERENCES `supplier` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_order_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_order_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchaseOrderId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemDescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unitPrice` double NOT NULL,
  `tax` double DEFAULT NULL,
  `total` double NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyingUom` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyPerCase` int DEFAULT NULL,
  `offtake` int DEFAULT NULL,
  `orderQty` int DEFAULT NULL,
  `pieces` int DEFAULT NULL,
  `costPricePerCase` double DEFAULT NULL,
  `costPricePerPiece` double DEFAULT NULL,
  `discount1` double DEFAULT NULL,
  `discount2` double DEFAULT NULL,
  `discount3` double DEFAULT NULL,
  `netCostAmount` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_item_purchaseOrderId_fkey` (`purchaseOrderId`),
  KEY `purchase_order_item_productId_fkey` (`productId`),
  CONSTRAINT `purchase_order_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `purchase_order_item_purchaseOrderId_fkey` FOREIGN KEY (`purchaseOrderId`) REFERENCES `purchase_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `reminder` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: request
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `request` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requesterName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessUnit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chargeTo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `verifiedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approvedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'To Verify',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `formName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depositAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_requestNumber_key` (`requestNumber`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: request_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `request_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `request_item_requestId_fkey` (`requestId`),
  KEY `request_item_productId_fkey` (`productId`),
  CONSTRAINT `request_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `request_item_requestId_fkey` FOREIGN KEY (`requestId`) REFERENCES `request` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sales_user` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniqueId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_user_uniqueId_key` (`uniqueId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `supplier` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `additionalInfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactFirstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTermsValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatInfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: transactions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq` int DEFAULT NULL,
  `ledger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) DEFAULT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` double DEFAULT '0',
  `credit` double DEFAULT '0',
  `balance` double DEFAULT '0',
  `checkAccountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateMatured` datetime(3) DEFAULT NULL,
  `accountName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankBranch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCoincide` tinyint(1) DEFAULT NULL,
  `dailyClosing` int DEFAULT NULL,
  `approval` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToLedger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ssma_timestamp` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_accountNumber_date_idx` (`accountNumber`, `date`),
  KEY `transactions_code_date_idx` (`code`, `date`),
  KEY `transactions_date_idx` (`date`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `unit_of_measure` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_of_measure_code_key` (`code`),
  UNIQUE KEY `unit_of_measure_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_permission` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formPermissions` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission_username_key` (`username`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '633b1ed0-9123-45f3-8a99-cb29424ecb5a',
    '18c54816d039175d5e3d48066161c51c38a976842d9175f25937c8802546a0ef',
    '2026-01-28 08:38:13.232',
    '20260106073417_add_sales_user',
    NULL,
    NULL,
    '2026-01-28 08:38:13.223',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '7af9b917-d2f7-4d87-88f1-6f74adea2a04',
    '9410e048b5ad0d68daf03be7f6f92f917f5b4f68a2028416ee1b934a356aa1a4',
    '2026-01-28 08:40:19.428',
    '20260128084018_add_purchase_order_item_bulk_fields',
    NULL,
    NULL,
    '2026-01-28 08:40:18.912',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'cb4ee741-ddbc-4113-b18f-3db64818dfcd',
    '5ebf57ea84ec53062797d0268b6568a9273cd404b143252c3a6594ca1c6d3dcb',
    '2026-01-28 08:38:13.203',
    '20251229060212_rename_account_number_to_accnt_no',
    NULL,
    NULL,
    '2026-01-28 08:38:13.021',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'd0cbf72e-05ce-465f-ad14-b9b7abfa57c8',
    '9e72cfb7e330ed4870fc06c8650133eacdb1398b8000acf6345707e7f652fcec',
    '2026-01-28 08:38:13.244',
    '20260106091627_add_user_permission_model',
    NULL,
    NULL,
    '2026-01-28 08:38:13.233',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'dff21d21-1ff6-4487-bc4d-7438e13794d4',
    'ce22d20a307f7a87b58fca9e5a6ba88f0e225960099123b743bc796342a88579',
    '2026-01-28 08:38:13.222',
    '20251229064442_add_accnt_type_no',
    NULL,
    NULL,
    '2026-01-28 08:38:13.204',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'ea6b7370-3e4b-4c20-852c-3095eb57dbfb',
    'bfc13f666e5ac3c35fc5e780387c886bc11d20d159a9394284390fdf55779dd6',
    '2026-01-30 05:34:04.269',
    '20260130053404_add_account_fields',
    NULL,
    NULL,
    '2026-01-30 05:34:04.257',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'eb841330-8fdb-4cbe-b19a-f8d3c6c0245b',
    '74487f0a15539b305e49352d2ac9d99babea423b69a957868c25923c48e7a311',
    '2026-01-30 07:13:39.138',
    '20260130070956_sync_account_headers_rename_v2',
    NULL,
    NULL,
    '2026-01-30 07:13:39.074',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: account_type
# ------------------------------------------------------------

INSERT INTO
  `account_type` (`id`, `name`, `baseType`, `createdAt`, `updatedAt`)
VALUES
  (
    'cmlyph1z500006ov7xaz77knr',
    'Liability',
    'Liability',
    '2026-02-23 04:57:55.262',
    '2026-02-23 04:57:55.262'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cml4qkcfm0000wov7st2xnzv9',
    'COMPLETED',
    'E:\\SOFTWARE\\#FIREBASE PROJECT\\LJMAAccounting\\storage\\backups\\backup_ljma_accounting_2026-02-02T05-35-23-145Z.zip',
    'backup_ljma_accounting_2026-02-02T05-35-23-145Z.zip',
    '0.01 MB',
    'admin',
    'Backup completed successfully.',
    '2026-02-02 05:35:23.119',
    '2026-02-02 05:35:23.381'
  );
INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cmlivi1z00000nsv78zhadbwp',
    'COMPLETED',
    'E:\\SOFTWARE\\FIREBASE PROJECT\\LJMAAccounting\\storage\\backups\\backup_ljma_accounting_2026-02-12T03-02-20-821Z.zip',
    'backup_ljma_accounting_2026-02-12T03-02-20-821Z.zip',
    '0.02 MB',
    'admin',
    'Backup completed successfully.',
    '2026-02-12 03:02:20.792',
    '2026-02-12 03:02:21.035'
  );
INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cmm4gmr9600pbxsv7jddmjf1u',
    'RUNNING',
    NULL,
    NULL,
    NULL,
    'admin',
    'Dumping database...',
    '2026-02-27 05:37:01.817',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: brand
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

INSERT INTO
  `business_profile` (
    `id`,
    `businessName`,
    `address`,
    `owner`,
    `contactPhone`,
    `contactTel`,
    `email`,
    `tin`,
    `permit`,
    `logo`,
    `createdAt`,
    `updatedAt`,
    `bankDetails`
  )
VALUES
  (
    'cml7m5pdo0000dov7l71wgi9z',
    'LJMA Accounting',
    'Maragusan, Davao de Oro',
    'Jonas Roslinda',
    '03957117604',
    '02 123456',
    'ljma@gmail..com',
    '125446359845426564',
    '213564816358797',
    NULL,
    '2026-02-04 05:55:20.123',
    '2026-02-04 05:55:20.123',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: category
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml0cg353000060v797rwczmo',
    1000,
    'Coins',
    1000,
    'Asset',
    'Yes',
    'No',
    'Asset',
    '2026-01-30 03:49:05.122',
    '2026-01-30 03:49:05.122',
    1,
    NULL,
    NULL,
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfqb0051pwv7p9a6oj1m',
    1080007,
    'Coins',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2024-08-20 16:00:00.000',
    '2026-02-03 10:53:36.609',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfqk0052pwv7r18x3xnx',
    1080006,
    'Contengency Funds',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2024-05-15 16:00:00.000',
    '2026-02-03 10:53:36.618',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfqr0053pwv7rd9t4mhr',
    1080003,
    'General Funds',
    49858.329999999994,
    'Asset',
    'No',
    'Yes',
    'Cash On Hand',
    '2023-01-03 16:00:00.000',
    '2026-02-23 08:31:57.146',
    1,
    'LJMA General Fund',
    'Cash On Hand',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfr20054pwv7j1eibcf1',
    1080001,
    'Postdated Checks',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2021-08-07 16:00:00.000',
    '2026-02-03 10:53:36.636',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfr70055pwv7topdqqfi',
    1300004,
    'Cashier Expenses',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-09-27 16:00:00.000',
    '2026-02-03 10:53:36.642',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfrg0056pwv73xztjh04',
    1300001,
    'Gunayan, Cherica',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2021-08-07 16:00:00.000',
    '2026-02-03 10:53:36.650',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfro0057pwv7l6kh03l0',
    1300003,
    'Quiminales, John Lloyd',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-03 10:53:36.658',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfru0058pwv7fcid7cx9',
    1300002,
    'Roslinda, Jonas',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-03 10:53:36.665',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfs40059pwv7429uaiwp',
    1400009,
    'Alfonso, Ivy',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2025-07-06 16:00:00.000',
    '2026-02-03 10:53:36.670',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfsc005apwv7vagpcey9',
    1400008,
    'Antonio, Yandie Grace',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2025-06-07 16:00:00.000',
    '2026-02-03 10:53:36.682',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfsk005bpwv7bzmcv30z',
    1400004,
    'Gunayan, Cherica',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-03 10:53:36.691',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfss005cpwv7fvaj6jue',
    1400002,
    'Igar, Feljhen R.',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-03 10:53:36.698',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdft4005dpwv7ot7wjkhc',
    1400005,
    'Quiminales, John Lloyd',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-03 10:53:36.710',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdftb005epwv7gcyzvbps',
    1400001,
    'Roslinda, Jonas',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:36.717',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfti005fpwv7x8hxwlpc',
    1400003,
    'Sisi, Mila Flor',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-03 10:53:36.724',
    1,
    NULL,
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdftq005gpwv706w7xhs2',
    1070003,
    'Fujidenzo Chest Freezer',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2024-10-04 16:00:00.000',
    '2026-02-03 10:53:36.732',
    1,
    '1 Unit',
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfty005hpwv70otiqnmo',
    1070001,
    'Server Computer',
    0,
    'Office Equipment',
    'No',
    'No',
    'Asset',
    '2021-08-03 16:00:00.000',
    '2026-02-03 10:53:36.740',
    1,
    '1 unit',
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfu4005ipwv7j0it3a1r',
    1070004,
    'Supermarket Shelves',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2025-06-23 16:00:00.000',
    '2026-02-03 10:53:36.746',
    1,
    'Supermarket Shelves',
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfud005jpwv7oihnpuuy',
    1070002,
    'Wall Fan',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2024-08-22 16:00:00.000',
    '2026-02-03 10:53:36.755',
    1,
    '-',
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfum005kpwv70x9cehmn',
    1070005,
    'Wireless Data POS System',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2025-11-20 16:00:00.000',
    '2026-02-03 10:53:36.763',
    1,
    '-',
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfus005lpwv7vcee9slf',
    1040000,
    '<>',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:36.771',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfuw005mpwv7r09v5xaq',
    1040003,
    'Bank monthly Interest',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-03-29 16:00:00.000',
    '2026-02-03 10:53:36.775',
    1,
    'Monthly Bank Interest',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfv7005npwv70zeau55g',
    1040016,
    'Borre, Arnold',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-09-02 16:00:00.000',
    '2026-02-03 10:53:36.785',
    1,
    'Rental',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfvg005opwv7owwnt10o',
    1040004,
    'Cash Short/Over',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.794',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfvo005ppwv7b6aen8jk',
    1040002,
    'Check Encashment Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-02-10 16:00:00.000',
    '2026-02-03 10:53:36.802',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfw1005qpwv78yybywdd',
    1040017,
    'Daganato, Annie Jane',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-09-11 16:00:00.000',
    '2026-02-03 10:53:36.814',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfwe005rpwv7u69gm738',
    1040012,
    'Damage Karton Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:36.828',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfwy005spwv7ft8f1s43',
    1040007,
    'Display Allowance',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.848',
    1,
    'Supplier',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfx6005tpwv7zyqqx4vd',
    1040010,
    'Other Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-09-21 16:00:00.000',
    '2026-02-03 10:53:36.856',
    1,
    'Lhets',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfxe005upwv73ggsiulp',
    1040011,
    'Palawan Space Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-10-07 16:00:00.000',
    '2026-02-03 10:53:36.864',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfxk005vpwv7qo4ohurv',
    1040001,
    'Photocopy Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-02-08 16:00:00.000',
    '2026-02-03 10:53:36.869',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfxr005wpwv7usccbvmc',
    1040008,
    'POS Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.878',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfxz005xpwv7rkswvjyx',
    1040015,
    'RENTAL INCOME',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-08-04 16:00:00.000',
    '2026-02-03 10:53:36.884',
    1,
    'Space Rental',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfy6005ypwv7ka5q0a0m',
    1040018,
    'Solar, John Ray',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-11-04 16:00:00.000',
    '2026-02-03 10:53:36.892',
    1,
    'Rental',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfye005zpwv79n3pomxx',
    1040006,
    'STL Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.900',
    1,
    'Monthly rental payment of MRG 1',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfyk0060pwv7m45hkw5s',
    1040005,
    'Suarez Area Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.907',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfyt0061pwv7econmjgi',
    1040013,
    'Sunpride Foods-Pick up Allowance',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-01-06 16:00:00.000',
    '2026-02-03 10:53:36.914',
    1,
    'Freight',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfz00062pwv7m747miod',
    1040014,
    'Suppliers Discount',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-02-13 16:00:00.000',
    '2026-02-03 10:53:36.923',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfz70063pwv72be331c4',
    1040009,
    'Tanduay Incentive Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-09-15 16:00:00.000',
    '2026-02-03 10:53:36.930',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfzd0064pwv74aijv81g',
    1100005,
    'Ayr Warehouse Rental',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2025-06-11 16:00:00.000',
    '2026-02-03 10:53:36.936',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfzm0065pwv7g2p0uwt8',
    1100001,
    'Photo Copier',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:36.944',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdfzw0066pwv710o3ases',
    1100003,
    'Suarez Rental Payment',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-28 16:00:00.000',
    '2026-02-03 10:53:36.952',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg020067pwv7ir7f24pi',
    1100002,
    'Temp Sales 20240830',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-27 16:00:00.000',
    '2026-02-03 10:53:36.961',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg090068pwv78bub1s8c',
    1100004,
    'Temp Sales 20240831',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-30 16:00:00.000',
    '2026-02-03 10:53:36.968',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg0m0069pwv7o44dl9rs',
    1050055,
    'Accommodation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-21 16:00:00.000',
    '2026-02-03 10:53:36.976',
    1,
    'Hotel',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg0s006apwv74ykybobw',
    1050053,
    'Annual Insurance Payment',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-06 16:00:00.000',
    '2026-02-03 10:53:36.987',
    1,
    'The Mercantile Insurance Co.. INC',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg11006bpwv7gf6njrtz',
    1050032,
    'Bad Orders',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-27 16:00:00.000',
    '2026-02-03 10:53:36.995',
    1,
    'Open Seal, Bottle Breakages, Rat bites etc',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg17006cpwv7bgaw7mwg',
    1050039,
    'Bank Fees Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-20 16:00:00.000',
    '2026-02-03 10:53:37.002',
    1,
    'Bank Fees Expense',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg1f006dpwv7qh31nqkm',
    1050046,
    'BIR 1701',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.010',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg1l006epwv7j5bf9gdz',
    1050043,
    'BIR 1702Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.016',
    1,
    'BIR Quarterly Income paymeny',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg1u006fpwv7fe6egux5',
    1050044,
    'BIR 2250-M',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.023',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg23006gpwv7xdyif7la',
    1050049,
    'BIR 2550-M',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-23 16:00:00.000',
    '2026-02-03 10:53:37.033',
    1,
    'BIR Monthly Income payment',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg28006hpwv7pju97a7m',
    1050051,
    'BIR 2550-Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-01-22 16:00:00.000',
    '2026-02-03 10:53:37.039',
    1,
    'Quarterly Value Added tax',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg2g006ipwv797a28yhl',
    1050045,
    'BIR 2551-Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.046',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg2n006jpwv765p4h45t',
    1050001,
    'BIR Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:37.054',
    1,
    'Meal Expenses',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg2t006kpwv7rbrspvqx',
    1050026,
    'BIR Tax Defeciency Settlement',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-28 16:00:00.000',
    '2026-02-03 10:53:37.060',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg2y006lpwv7djl54b3k',
    1050040,
    'Bitpos Subscription Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-23 16:00:00.000',
    '2026-02-03 10:53:37.065',
    1,
    'monthly Subscription payments',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg37006mpwv7l7z7n7kd',
    1050050,
    'Business Permit Fees',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-01-12 16:00:00.000',
    '2026-02-03 10:53:37.073',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg3d006npwv7wpyl53jq',
    1050018,
    'Cash Advance Discoun',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.080',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg3m006opwv7redd8t9k',
    1050035,
    'Cash Short/Over',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-02 16:00:00.000',
    '2026-02-03 10:53:37.088',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg3t006ppwv7gba531u3',
    1050047,
    'Customer Shares',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-11 16:00:00.000',
    '2026-02-03 10:53:37.095',
    1,
    'Points and Loyalty Rewards',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg4m006qpwv7gakbjhlx',
    1050054,
    'Customized Shelves',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-10 16:00:00.000',
    '2026-02-03 10:53:37.124',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg52006rpwv7slpvszfe',
    1050007,
    'Electric Bill',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.140',
    1,
    'Monthly electric payment',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg5b006spwv7i8u1ube0',
    1050006,
    'Fuel',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.149',
    1,
    'All fuel expenses',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg5j006tpwv70xdgzlqs',
    1050038,
    'Garbage Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-16 16:00:00.000',
    '2026-02-03 10:53:37.157',
    1,
    'Menro payment of bulk garbage disposal',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg5r006upwv7x1e27ill',
    1050005,
    'Grocery area Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.164',
    1,
    'Twine/',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg5w006vpwv73ed95fy6',
    1050034,
    'Grocery Supplies Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-01 16:00:00.000',
    '2026-02-03 10:53:37.171',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg62006wpwv7wv1tvkij',
    1050041,
    'Incentives',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-25 16:00:00.000',
    '2026-02-03 10:53:37.177',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg6b006xpwv71yy82jq5',
    1050058,
    'Insurance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-07 16:00:00.000',
    '2026-02-03 10:53:37.185',
    1,
    'vehicle, building',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg6k006ypwv7wm7nfmvg',
    1050012,
    'Internet & Cellphone Load Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.195',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg6r006zpwv7o2ape4yt',
    1050002,
    'Legal Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-14 16:00:00.000',
    '2026-02-03 10:53:37.202',
    1,
    'All Notarized Documents and Court Apperances',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg6z0070pwv72082gbb9',
    1050008,
    'MAECC  Pag-ibig Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.209',
    1,
    'Employer share',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg7a0071pwv7o19a11uu',
    1050010,
    'MAECC  Sss Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.219',
    1,
    'MAECC Employer Share',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg7h0072pwv7rifpcko6',
    1050027,
    'MAECC Permits',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-28 16:00:00.000',
    '2026-02-03 10:53:37.228',
    1,
    'Permits & Fees',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg7p0073pwv79qfoubiq',
    1050009,
    'MAECC Philhealth Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.235',
    1,
    'MAECC Employer share',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg7y0074pwv7sduhbjob',
    1050013,
    'Maintenance & Repair',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.243',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg840075pwv7lyd0hiy8',
    1050056,
    'MARIOSOFT SYSTEM SOLUTIONS',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-05-02 16:00:00.000',
    '2026-02-03 10:53:37.251',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg890076pwv7ojwcxkg9',
    1050011,
    'Meals',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.256',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg8h0077pwv7ma7ev3s2',
    1050003,
    'Miscellaneous Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-17 16:00:00.000',
    '2026-02-03 10:53:37.262',
    1,
    'One time expense amounting to ABOVE 500.00',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg8o0078pwv7x66jn1qz',
    1050024,
    'Monthly Allocation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-10-12 16:00:00.000',
    '2026-02-03 10:53:37.270',
    1,
    'monthly travel allocation JYR',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg8w0079pwv740ctbfju',
    1050019,
    'Monthly Interest',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.279',
    1,
    'Asuncion Yanong monthly interest',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg93007apwv72e4mfula',
    1050048,
    'Office Equipment',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-19 16:00:00.000',
    '2026-02-03 10:53:37.284',
    1,
    'Tangible Supplies',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg9a007bpwv7e24r5xmy',
    1050014,
    'Office Supply',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.293',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg9h007cpwv7c3u404u3',
    1050028,
    'Other Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-02-27 16:00:00.000',
    '2026-02-03 10:53:37.300',
    1,
    'One time expense amounting to BELOW 500.00',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg9n007dpwv7p6wr5xwu',
    1050059,
    'Outside/Security Services',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-15 16:00:00.000',
    '2026-02-03 10:53:37.306',
    1,
    'Security Agency Fee',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdg9u007epwv769z9mw5i',
    1050029,
    'POS Monthly Subscription',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-24 16:00:00.000',
    '2026-02-03 10:53:37.311',
    1,
    'Bitpos Software subscription',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdga2007fpwv7ii5nq59l',
    1050057,
    'Professional Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-03 16:00:00.000',
    '2026-02-03 10:53:37.321',
    1,
    'Processing fee',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgab007gpwv72qa2sbjv',
    1050015,
    'Real Property Tax',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.330',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgah007hpwv7rv39t8hy',
    1050025,
    'Repair & Maintenance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-10 16:00:00.000',
    '2026-02-03 10:53:37.335',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgap007ipwv71jl9f893',
    1050036,
    'Retainers Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-04 16:00:00.000',
    '2026-02-03 10:53:37.343',
    1,
    'Payment of all fees rendered from service providers',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgay007jpwv7ela6usyj',
    1050023,
    'Salaries & Wages',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-20 16:00:00.000',
    '2026-02-03 10:53:37.352',
    1,
    'MAECC payroll',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgb4007kpwv7agdav8v9',
    1050033,
    'Security Guard Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-29 16:00:00.000',
    '2026-02-03 10:53:37.359',
    1,
    'Payroll',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgb9007lpwv7voly3zmx',
    1050022,
    'Shipping Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.364',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgbh007mpwv719n955o5',
    1050016,
    'Solicitation / Donation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.371',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgbo007npwv7n52hku0g',
    1050030,
    'Stocks Unloading Expenses',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-26 16:00:00.000',
    '2026-02-03 10:53:37.378',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgbv007opwv7jt4zjxdu',
    1050031,
    'Tanduay Jobing Discount Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-26 16:00:00.000',
    '2026-02-03 10:53:37.385',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgc4007ppwv76h8h886n',
    1050004,
    'Transportation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.394',
    1,
    'Fare to public transpo',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgcb007qpwv7i8zne056',
    1050042,
    'Trucking/Hauling Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-27 16:00:00.000',
    '2026-02-03 10:53:37.402',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgci007rpwv7bkujnt12',
    1050052,
    'Utility expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-02-19 16:00:00.000',
    '2026-02-03 10:53:37.408',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgcn007spwv70f4oo2co',
    1050020,
    'Vehicle Insurance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.414',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgcu007tpwv7caq4z0x6',
    1050037,
    'Vehicle Registration Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-12 16:00:00.000',
    '2026-02-03 10:53:37.421',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgd1007upwv7m3k8prv0',
    1050021,
    'Vehicles Repair & Maintainance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.428',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cml6hdgda007vpwv7m4oaahuz',
    1050017,
    'Water Bill',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.437',
    1,
    NULL,
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cmlrrrwbi000064v7vjak85eo',
    4000,
    'POS Sales',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2026-02-18 08:27:57.144',
    '2026-02-18 08:27:57.144',
    20,
    'POS Sales',
    'IS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cmlvvtnka0000ocv7aakezzvw',
    5000,
    'Supplier Purchase Order',
    8.33,
    'Expense',
    'No',
    'No',
    'Expense',
    '2026-02-21 05:32:22.278',
    '2026-02-23 08:26:21.488',
    60,
    'Supplier Purchase Order (Liabilities)',
    'BS',
    'Active',
    NULL
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cmlypi1ex00016ov7hzm35fr0',
    2000,
    'Purchase supplier rex',
    -8.33,
    'Liability',
    'No',
    'No',
    'Liability',
    '2026-02-23 04:58:41.193',
    '2026-02-23 08:31:57.154',
    1,
    'Sample purchase order dev',
    'Liability',
    'Active',
    'cmlyph1z500006ov7xaz77knr'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`,
    `account_type_id`
  )
VALUES
  (
    'cmlyzl5la0001bov74r2ziy7t',
    2001,
    'Trademark Account Payables',
    41.67,
    'Liability',
    'No',
    'No',
    'Liability',
    '2026-02-23 09:41:02.734',
    '2026-02-23 09:49:39.519',
    2,
    'Trademark Account Supplier',
    'BS',
    'Active',
    'cmlyph1z500006ov7xaz77knr'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer
# ------------------------------------------------------------

INSERT INTO
  `customer` (
    `id`,
    `code`,
    `customerName`,
    `contactFirstName`,
    `address`,
    `phonePrimary`,
    `phoneAlternative`,
    `email`,
    `isActive`,
    `creditLimit`,
    `isTaxExempt`,
    `paymentTerms`,
    `paymentTermsValue`,
    `salesperson`,
    `customerGroup`,
    `isEntitledToLoyaltyPoints`,
    `pointSetting`,
    `loyaltyCalculationMethod`,
    `loyaltyCardNumber`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'e15622d5-30e0-4620-9817-0c9d60836036',
    'C001',
    'Test Customer',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    1,
    0,
    0,
    'days',
    '30',
    NULL,
    'default',
    0,
    NULL,
    'automatic',
    NULL,
    '2026-02-24 11:54:25.000',
    '2026-02-24 11:54:25.000'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer_payments
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: inventory_transaction
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: invoice
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: invoice_item
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_board
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_card
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_column
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: notification
# ------------------------------------------------------------

INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '082a7cea-612e-4b27-8919-b7efe17cddc0',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    0,
    '2026-02-03 10:46:29.899',
    'cml4yqb0j0000jgv7kq0t3fhs'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '1c22155e-aba2-49b6-8234-20f89aa7d148',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    0,
    '2026-02-03 10:46:29.899',
    'cml4yaaj900016kv7oliupi1e'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '22b00035-4768-44a2-a374-ed4ba0fac222',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    1,
    '2026-02-03 10:46:29.899',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '29b95a2c-1b4b-421d-9eee-b26c06bbee09',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    1,
    '2026-02-03 10:17:06.078',
    'cml4xg7sz00006kv7is4z8efq'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '3f0d978c-3e39-48d9-b0d7-7c25840f9047',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    0,
    '2026-02-02 09:31:35.424',
    'cml4yaaj900016kv7oliupi1e'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '71907671-eac8-4fdd-aacb-fbb67e5da917',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    1,
    '2026-02-03 10:17:06.078',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'a10e58f1-049e-4b72-88d5-aeb3a8226512',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    1,
    '2026-02-02 09:31:35.424',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'cml630dg30001iwv7hes3at8l',
    'reminder_create',
    'New Reminder',
    'event ni',
    'cml630dfu0000iwv7ccb0u9nx',
    1,
    '2026-02-03 04:11:32.498',
    NULL
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'd5c3b56d-7d6f-4ebf-a802-905fafff995a',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    0,
    '2026-02-03 10:17:06.078',
    'cml4yqb0j0000jgv7kq0t3fhs'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'dc1da047-b222-4c2b-a364-29013e3848f6',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    1,
    '2026-02-02 09:31:35.424',
    'cml4yqb0j0000jgv7kq0t3fhs'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'e3d58d59-1f8d-4e3b-91a9-6b81b63fe930',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new REQUEST AND AUTHORIZATION OF CASH ADVANCES (REQ-00001) requires your verification.',
    'ec05873d-da80-400a-9e6e-451982aaf64d',
    1,
    '2026-02-03 08:47:08.172',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'e871f8a5-ea64-4df9-8328-516c00bbc515',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    1,
    '2026-02-03 10:46:29.899',
    'cml4xg7sz00006kv7is4z8efq'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'ebf058ed-0ef3-452b-ba20-2b5109b3383f',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00001) requires your verification.',
    'a96b6030-f28c-4600-b84b-6f57e08b07bd',
    1,
    '2026-02-02 09:04:18.118',
    'cml4xg7sz00006kv7is4z8efq'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'ec5edb3c-d990-4578-8f87-bdf3bfcdc937',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    0,
    '2026-02-03 10:17:06.078',
    'cml4yaaj900016kv7oliupi1e'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'fc625a98-c76c-4bf5-b58b-b41b89ce3b1c',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    1,
    '2026-02-02 09:31:35.424',
    'cml4xg7sz00006kv7is4z8efq'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: payables_ledger
# ------------------------------------------------------------

INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyvt2mj0000i4v7757kc7pp',
    '2026-02-23 05:44:43.811',
    NULL,
    'Purchases',
    '2000',
    'Purchase supplier rex',
    'CHOCOMUCHO25G',
    41.67,
    0,
    'admin',
    '2026-02-23 07:55:13.672',
    '2026-02-23 07:55:13.672'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyvt2mj0001i4v7we3h1haj',
    '2026-02-23 05:44:43.811',
    NULL,
    'Purchases',
    '2000',
    'Purchase supplier rex',
    'CHOCOMUCHO25G',
    41.67,
    0,
    'admin',
    '2026-02-23 07:55:13.672',
    '2026-02-23 07:55:13.672'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyvt2mj0002i4v7qbng69bg',
    '2026-02-23 05:44:43.811',
    NULL,
    'Purchases',
    '2000',
    'Purchase supplier rex',
    'CHOCOMUCHO25G',
    41.67,
    0,
    'admin',
    '2026-02-23 07:55:13.672',
    '2026-02-23 07:55:13.672'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyw4m8a0000j8v77kipg96v',
    '2026-02-23 07:59:33.305',
    '1',
    NULL,
    '1080003',
    'General Funds',
    'LJMA General Fund',
    0,
    125.01,
    'admin',
    '2026-02-23 08:04:12.295',
    '2026-02-23 08:04:12.295'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyw4m8a0001j8v7f3lql9xt',
    '2026-02-23 07:59:33.305',
    '1',
    NULL,
    '2000',
    'Purchase supplier rex',
    'Payment for Bill #cmlyr83s',
    125.01,
    0,
    'admin',
    '2026-02-23 08:04:12.295',
    '2026-02-23 08:04:12.295'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlywhv060000scv7u06pqgus',
    '2026-02-23 08:14:02.793',
    '1',
    NULL,
    '1080003',
    'General Funds',
    'LJMA General Fund',
    0,
    125.01,
    'admin',
    '2026-02-23 08:14:30.197',
    '2026-02-23 08:14:30.197'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlywhv060001scv76mhbpzfu',
    '2026-02-23 08:14:02.793',
    '1',
    NULL,
    '2000',
    'Purchase supplier rex',
    'Payment for Bill #cmlyr83s',
    125.01,
    0,
    'admin',
    '2026-02-23 08:14:30.197',
    '2026-02-23 08:14:30.197'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlywx3u10004scv74n29bjb5',
    '2026-02-23 08:24:53.130',
    NULL,
    'Purchases',
    '5000',
    'Supplier Purchase Order',
    'DOWNY 12G',
    8.33,
    0,
    'admin',
    '2026-02-23 08:26:21.480',
    '2026-02-23 08:26:21.480'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlywxgqp0005scv7zvh2t1d3',
    '2026-02-23 08:14:02.793',
    '1',
    NULL,
    '1080003',
    'General Funds',
    'LJMA General Fund',
    0,
    8.33,
    'admin',
    '2026-02-23 08:26:38.208',
    '2026-02-23 08:26:38.208'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlywxgqp0006scv7amttfttb',
    '2026-02-23 08:14:02.793',
    '1',
    NULL,
    '2000',
    'Purchase supplier rex',
    'Payment for Bill #cmlywvxz',
    8.33,
    0,
    'admin',
    '2026-02-23 08:26:38.208',
    '2026-02-23 08:26:38.208'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyx4att0007scv7mti8e11v',
    '2026-02-23 08:14:02.793',
    '1',
    NULL,
    '1080003',
    'General Funds',
    'LJMA General Fund',
    0,
    8.33,
    'admin',
    '2026-02-23 08:31:57.136',
    '2026-02-23 08:31:57.136'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyx4att0008scv7xhgvdw1j',
    '2026-02-23 08:14:02.793',
    '1',
    NULL,
    '2000',
    'Purchase supplier rex',
    'Payment for Bill #cmlywvxz',
    8.33,
    0,
    'admin',
    '2026-02-23 08:31:57.136',
    '2026-02-23 08:31:57.136'
  );
INSERT INTO
  `payables_ledger` (
    `id`,
    `date`,
    `reference`,
    `ledger`,
    `accountNumber`,
    `accountName`,
    `accountDescription`,
    `debitAmount`,
    `creditAmount`,
    `user`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyxm0cf0000sov73gr5x84s',
    '2026-02-09 08:21:12.942',
    NULL,
    'Purchases',
    NULL,
    NULL,
    'SKYFLAKES',
    4.17,
    0,
    'admin',
    '2026-02-23 08:45:43.358',
    '2026-02-23 08:45:43.358'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: pos_sale_item
# ------------------------------------------------------------

INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxcj00g5xsv7zttgb8dn',
    'cmm4fs9lh0001xsv7x9s1ktwx',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxd200g6xsv7dkajtjtk',
    'cmm4fs9mf0003xsv7xhb78cbu',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxdl00g7xsv744n274iy',
    'cmm4fs9n40005xsv74j0s30dl',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxe200g8xsv7mvrn9e3j',
    'cmm4fs9ns0007xsv7ps61jcr9',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxej00g9xsv7vhi31lbu',
    'cmm4fs9o90009xsv7ud0s2wxf',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxf000gaxsv75l3vqpf7',
    'cmm4fs9ow000bxsv7oe51c4lo',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxfh00gbxsv77j3rn4aa',
    'cmm4fs9pd000dxsv70umu4cs3',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    13,
    80,
    1040
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxfm00gcxsv77r46um0i',
    'cmm4fs9pd000dxsv70umu4cs3',
    NULL,
    'CHOCOMUCHO25G',
    16,
    43.75,
    700
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxfw00gdxsv702g2wvds',
    'cmm4fs9pd000dxsv70umu4cs3',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxg300gexsv702mv6tix',
    'cmm4fs9pd000dxsv70umu4cs3',
    NULL,
    'REBISCON BOX',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxgl00gfxsv7d7f1d5iw',
    'cmm4fs9qk000ixsv7cf7op1cs',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxgy00ggxsv7txxpzt33',
    'cmm4fs9r0000kxsv7k5uzeb18',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxhd00ghxsv7k3cnr357',
    'cmm4fs9rc000mxsv7k3f1ykr4',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    6,
    80,
    480
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxht00gixsv7xdox97t6',
    'cmm4fs9rp000oxsv7cu7wveqz',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    12,
    80,
    960
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxi800gjxsv7m6r5g24j',
    'cmm4fs9s8000qxsv72z135255',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    12,
    80,
    960
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxip00gkxsv7gtmveoeg',
    'cmm4fs9sm000sxsv7rgw8ftw1',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    9,
    100,
    900
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxj700glxsv7fan56iyr',
    'cmm4fs9t0000uxsv7toxy89bd',
    NULL,
    'ANTIGRAVITY TEST PRODUCT',
    12,
    80,
    960
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxjn00gmxsv7t26lxtcg',
    'cmm4fs9te000wxsv7rom6573j',
    NULL,
    'SKYFLAKES BOX',
    3,
    52.5,
    157.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxk300gnxsv70hwmcp8k',
    'cmm4fs9tt000yxsv77y0ayfqu',
    NULL,
    'ODONG',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxkm00goxsv7rnlogjit',
    'cmm4fs9u60010xsv7o9hdn2te',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxl200gpxsv7q5wwcco7',
    'cmm4fs9ul0012xsv7syuv7om4',
    NULL,
    'ODONG',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxlh00gqxsv7ws5c7x8j',
    'cmm4fs9v10014xsv7kq2s7gz3',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxlw00grxsv7hn44aaw6',
    'cmm4fs9vk0016xsv722rohjs1',
    NULL,
    'ODONG',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxmb00gsxsv752z9zqdz',
    'cmm4fs9vw0018xsv78s9c4ty9',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxms00gtxsv74ntncawr',
    'cmm4fs9wb001axsv7sog6hzbg',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxn800guxsv7tmgl2w6e',
    'cmm4fs9wp001cxsv7fh9n9z05',
    NULL,
    'ODONG',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxnn00gvxsv7tf8g9x81',
    'cmm4fs9x2001exsv75jpw85x6',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxo000gwxsv7r4ht0jvt',
    'cmm4fs9xf001gxsv7khbuc53u',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxoe00gxxsv7lks052xa',
    'cmm4fs9xt001ixsv7c3utkzl9',
    NULL,
    'Logitech MX Master 3S',
    1,
    6590,
    6590
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxov00gyxsv7l3s1lhcw',
    'cmm4fs9y7001kxsv7pcta5kk4',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxpa00gzxsv76k3f6hde',
    'cmm4fs9yl001mxsv76kes4nva',
    NULL,
    'ODONG',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxpp00h0xsv79nsnyzws',
    'cmm4fs9z1001oxsv7vf7lb0oa',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxq600h1xsv78waoezkk',
    'cmm4fs9zi001qxsv7gsyptpau',
    NULL,
    'ODONG',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxqm00h2xsv7vdg780nu',
    'cmm4fs9zy001sxsv7yokgxvpt',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxr000h3xsv721vvtdp2',
    'cmm4fsa08001uxsv7jvxcqce2',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxrd00h4xsv7sbyc99zr',
    'cmm4fsa0l001wxsv7to26tlym',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxru00h5xsv75hfq5dba',
    'cmm4fsa0z001yxsv7cnpn0tn1',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxs800h6xsv7mjbvqovq',
    'cmm4fsa1h0020xsv7o76i5rc6',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxso00h7xsv7g3eeoal1',
    'cmm4fsa1x0022xsv72k41a2ms',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxt400h8xsv74djjdqf4',
    'cmm4fsa2d0024xsv79v922bly',
    NULL,
    'SKYFLAKES',
    4,
    4.3,
    17.2
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxtl00h9xsv71lxieqq8',
    'cmm4fsa2s0026xsv7gpap2trh',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxtz00haxsv7gz9jvb1t',
    'cmm4fsa390028xsv7ry4ildue',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxud00hbxsv7pvehdlpc',
    'cmm4fsa3p002axsv7v5vdeh8m',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxuq00hcxsv73rkhezys',
    'cmm4fsa41002cxsv73jmjjxvj',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxv400hdxsv7iib7zco1',
    'cmm4fsa4h002exsv7dc94uefc',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxvb00hexsv79hm6jf87',
    'cmm4fsa4h002exsv7dc94uefc',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxvr00hfxsv777rx60a7',
    'cmm4fsa53002hxsv7zu9w99vr',
    NULL,
    'macaroni 25g',
    1,
    100,
    100
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxvw00hgxsv7cmtx2jbb',
    'cmm4fsa53002hxsv7zu9w99vr',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxwb00hhxsv7s1kjmcd4',
    'cmm4fsa5r002kxsv7kiqzzzq3',
    NULL,
    'SKYFLAKES',
    26,
    4.3,
    111.8
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxwp00hixsv7axqg7usv',
    'cmm4fsa64002mxsv7oohqgomx',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxx600hjxsv7uf2wpt3i',
    'cmm4fsa6n002oxsv7gp721wd5',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxxc00hkxsv7qcl9xpjy',
    'cmm4fsa6n002oxsv7gp721wd5',
    NULL,
    'SKYFLAKES',
    1,
    4.3,
    4.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxxq00hlxsv7swd6j5tj',
    'cmm4fsa78002rxsv7vbw7i60g',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxxy00hmxsv7yo3losrd',
    'cmm4fsa78002rxsv7vbw7i60g',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    515,
    515
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxyd00hnxsv7mmvd0y25',
    'cmm4fsa7r002uxsv74r3q7064',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxyu00hoxsv7ij6yf2vr',
    'cmm4fsa85002wxsv7cgafz3ze',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxza00hpxsv7lpd2j1i3',
    'cmm4fsa8i002yxsv7jk55e5qc',
    NULL,
    'SKYFLAKES BOX',
    10,
    53.55,
    535.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxxzn00hqxsv7f06fhd4j',
    'cmm4fsa8v0030xsv7d41wfrtg',
    NULL,
    'SKYFLAKES BOX',
    4,
    53.55,
    214.2
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy0300hrxsv7mqie0gqt',
    'cmm4fsa990032xsv7mx1h2z1f',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy0l00hsxsv7pukwkq42',
    'cmm4fsa9n0034xsv7qxagqwjm',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy0z00htxsv7pmt5ye4a',
    'cmm4fsaa00036xsv7r8a9ev50',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy1l00huxsv7ctkv0ug8',
    'cmm4fsaaf0038xsv7yl6kwawn',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy2j00hvxsv7f6a7bjqq',
    'cmm4fsaau003axsv72v705bzp',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy3500hwxsv7bnyflb97',
    'cmm4fsab8003cxsv70nk20oo2',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy3l00hxxsv7diollalz',
    'cmm4fsabm003exsv752spkjmf',
    NULL,
    'SKYFLAKES BOX',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy3r00hyxsv773rmn6z7',
    'cmm4fsabm003exsv752spkjmf',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy4700hzxsv746iuuu0r',
    'cmm4fsac9003hxsv78jw5lzam',
    NULL,
    'SKYFLAKES BOX',
    6,
    53.55,
    321.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy4o00i0xsv73guidqv8',
    'cmm4fsaco003jxsv7pghg04zc',
    NULL,
    'SKYFLAKES BOX',
    6,
    53.55,
    321.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy5200i1xsv7bq3g0xfb',
    'cmm4fsad2003lxsv73aipaxis',
    NULL,
    'SKYFLAKES BOX',
    9,
    53.55,
    481.95
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy5h00i2xsv73vnp6uzn',
    'cmm4fsadh003nxsv7ut6h9enu',
    NULL,
    'SKYFLAKES BOX',
    10,
    53.55,
    535.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy5v00i3xsv7l9864kbt',
    'cmm4fsadv003pxsv7rf2o79uu',
    NULL,
    'SKYFLAKES BOX',
    5,
    53.55,
    267.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy6900i4xsv7dpnjwvxg',
    'cmm4fsae7003rxsv73bh1eelu',
    NULL,
    'SKYFLAKES BOX',
    6,
    53.55,
    321.3
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy6r00i5xsv7ggmmfeen',
    'cmm4fsaew003txsv7r1xuea0n',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy7500i6xsv7kr3e4dw4',
    'cmm4fsafo003vxsv7005x9y6j',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy7l00i7xsv7p9tbylgx',
    'cmm4fsag9003xxsv7i9qsa5i5',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy7z00i8xsv7lndzky2o',
    'cmm4fsagt003zxsv7i7pov0ut',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy8e00i9xsv77m3mifzc',
    'cmm4fsah70041xsv72ffp51df',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy8r00iaxsv7iylw65fs',
    'cmm4fsahp0043xsv791cop54p',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy9400ibxsv711do088x',
    'cmm4fsai40045xsv7si2chis3',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy9h00icxsv74jviqp7i',
    'cmm4fsaij0047xsv7p1zec8oj',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxy9v00idxsv7bn659bj5',
    'cmm4fsaiu0049xsv7m53om0j0',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxya900iexsv76rsndz9j',
    'cmm4fsaj8004bxsv7ze1v9ytl',
    NULL,
    'SKYFLAKES BOX',
    5,
    53.55,
    267.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyan00ifxsv7m3qrij6y',
    'cmm4fsajm004dxsv78mwruby3',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyb000igxsv71lp03js4',
    'cmm4fsak0004fxsv7v9ygszqj',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxybf00ihxsv7ogmhm7tl',
    'cmm4fsake004hxsv7ywloiz9x',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxybt00iixsv7ktqttuu1',
    'cmm4fsakr004jxsv7eqcg63md',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyc500ijxsv7ewcywpfe',
    'cmm4fsal4004lxsv789kuw4cc',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxych00ikxsv75608q2ik',
    'cmm4fsalh004nxsv7ldx71znr',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxycv00ilxsv7oekxpfm0',
    'cmm4fsalt004pxsv7ygommuv3',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyd900imxsv7ra8le5aq',
    'cmm4fsam3004rxsv7q08nzpst',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxydq00inxsv72mm1pjum',
    'cmm4fsamf004txsv77wrlkobl',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxye400ioxsv7sk029ko2',
    'cmm4fsamr004vxsv72r4jwk55',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyeh00ipxsv7qzr8ksry',
    'cmm4fsan5004xxsv7hqvcr2mo',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyeu00iqxsv7phc6mrqz',
    'cmm4fsanj004zxsv7f497vjzz',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyf700irxsv7hvxsysdp',
    'cmm4fsanv0051xsv7ae6prt66',
    NULL,
    'SKYFLAKES BOX',
    19,
    53.55,
    1017.45
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyfl00isxsv7wnqjzgph',
    'cmm4fsaob0053xsv7upxyee7w',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyfz00itxsv7bfam19o8',
    'cmm4fsaoo0055xsv7jqnan5og',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxygh00iuxsv71kb373to',
    'cmm4fsap10057xsv7v94oizo1',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxygv00ivxsv7w5fie5gw',
    'cmm4fsape0059xsv7iuor9bq3',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyh800iwxsv7oi25av4d',
    'cmm4fsapr005bxsv7obfipt7k',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyhm00ixxsv74ordoq04',
    'cmm4fsaq4005dxsv7beyzkvof',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyhz00iyxsv7d1oe5g36',
    'cmm4fsaqg005fxsv7zx47f4lm',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyif00izxsv7wuzqz15b',
    'cmm4fsaqv005hxsv7aibqntb0',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyis00j0xsv73ca25wiz',
    'cmm4fsard005jxsv7174u9zz8',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyj400j1xsv7or9boegt',
    'cmm4fsarr005lxsv7afochnmi',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyjh00j2xsv7fbx90ing',
    'cmm4fsas7005nxsv7rk9no9be',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyjl00j3xsv7wforx0v5',
    'cmm4fsas7005nxsv7rk9no9be',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyk200j4xsv7qn1nuw6x',
    'cmm4fsass005qxsv7yjwtalnc',
    NULL,
    'SKYFLAKES BOX',
    11,
    53.55,
    589.05
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxykf00j5xsv7hhj5tgsn',
    'cmm4fsatb005sxsv72iq2flq5',
    NULL,
    'SKYFLAKES BOX',
    16,
    53.55,
    856.8
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyku00j6xsv7xf9oit9j',
    'cmm4fsatr005uxsv7lv8cucfw',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyla00j7xsv76hjmbry5',
    'cmm4fsau5005wxsv73e1v5w67',
    NULL,
    'REBISCON BOX',
    16,
    52.5,
    840
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxylq00j8xsv7z2pwgpgv',
    'cmm4fsaul005yxsv7tcfuo71i',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxylu00j9xsv7zr9mobra',
    'cmm4fsaul005yxsv7tcfuo71i',
    NULL,
    'REBISCON BOX',
    12,
    52.5,
    630
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxym800jaxsv7la3ecute',
    'cmm4fsav50061xsv7mpdm5qfn',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxymo00jbxsv7o8tsezgr',
    'cmm4fsavh0063xsv7hi3bic03',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxymv00jcxsv7lvqurvkp',
    'cmm4fsavh0063xsv7hi3bic03',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyna00jdxsv76xrovf78',
    'cmm4fsaw00066xsv725qykrmv',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxynj00jexsv7033pankr',
    'cmm4fsaw00066xsv725qykrmv',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyny00jfxsv7fy4jmxpt',
    'cmm4fsawm0069xsv7skya9au8',
    NULL,
    'CHOCOMUCHO25G',
    2,
    43.75,
    87.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyob00jgxsv7oxpgsm8s',
    'cmm4fsax2006bxsv73ftycs59',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyor00jhxsv7uoz3kshx',
    'cmm4fsaxh006dxsv7mmq4z86x',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyp600jixsv71uklkiko',
    'cmm4fsaxw006fxsv7fi2qp6ce',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxypk00jjxsv7ptamkq47',
    'cmm4fsay9006hxsv7ptij9ggc',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxypy00jkxsv7t8htn7w0',
    'cmm4fsayq006jxsv7bsmakwd5',
    NULL,
    'CHOCOMUCHO25G',
    4,
    43.75,
    175
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyq500jlxsv7gbiypp65',
    'cmm4fsayq006jxsv7bsmakwd5',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyqa00jmxsv79tclpynn',
    'cmm4fsayq006jxsv7bsmakwd5',
    NULL,
    'Bear Brand  300g',
    1,
    5.85,
    5.85
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyqi00jnxsv7ved6ss4j',
    'cmm4fsayq006jxsv7bsmakwd5',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyqo00joxsv7qgc7n5g4',
    'cmm4fsayq006jxsv7bsmakwd5',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyqx00jpxsv77sxpojt0',
    'cmm4fsayq006jxsv7bsmakwd5',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyrs00jqxsv7jtdnxoj0',
    'cmm4fsazz006qxsv75kxw904u',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxys400jrxsv7ys9r5u4r',
    'cmm4fsazz006qxsv75kxw904u',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyst00jsxsv7vqtii1pk',
    'cmm4fsb0h006txsv7pvotfjsf',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyt400jtxsv7o9yp48ng',
    'cmm4fsb0h006txsv7pvotfjsf',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxytf00juxsv7er5z50lz',
    'cmm4fsb0h006txsv7pvotfjsf',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxytl00jvxsv7awiqgy6n',
    'cmm4fsb0h006txsv7pvotfjsf',
    NULL,
    'REBISCON BOX',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyty00jwxsv7vfe9n1vl',
    'cmm4fsb1l006yxsv7u9rejpit',
    NULL,
    'CHOCO MUCHO BOX',
    1,
    525,
    525
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyup00jxxsv7hcahbzk6',
    'cmm4fsb200070xsv7kdt6wa07',
    NULL,
    'CHOCOMUCHO25G',
    1,
    43.75,
    43.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyvh00jyxsv7ajr55q8g',
    'cmm4fsb2e0072xsv72jlh9hv6',
    NULL,
    'CHOCOMUCHO25G',
    2,
    43.75,
    87.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyw000jzxsv7hg1qg0k6',
    'cmm4fsb2u0074xsv7llqc86nm',
    NULL,
    'CHOCOMUCHO25G',
    12,
    10,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxywb00k0xsv748jzqxaq',
    'cmm4fsb3b0076xsv7kf29v12k',
    NULL,
    'CHOCOMUCHO25G',
    12,
    10,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxywp00k1xsv7mif41s69',
    'cmm4fsb3p0078xsv7ks68khor',
    NULL,
    'CHOCOMUCHO25G',
    5,
    43.75,
    218.75
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyx500k2xsv7vf3n5s2c',
    'cmm4fsb43007axsv7r1kdrmw7',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyxb00k3xsv766kdaelt',
    'cmm4fsb43007axsv7r1kdrmw7',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyxt00k4xsv7qavuga68',
    'cmm4fsb4l007dxsv7ciqztbad',
    NULL,
    'SKYFLAKES',
    2,
    4.46,
    8.92
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyye00k5xsv7y8mfmfkl',
    'cmm4fsb4y007fxsv7wy3eae5u',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyyo00k6xsv7bc61csyt',
    'cmm4fsb4y007fxsv7wy3eae5u',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyza00k7xsv7w7z1yjfp',
    'cmm4fsb5i007ixsv7tc5o8xz2',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxyzj00k8xsv70b8nsxnu',
    'cmm4fsb5i007ixsv7tc5o8xz2',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz0100k9xsv7plf1fzup',
    'cmm4fsb61007lxsv7sgez1s03',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz0700kaxsv74e0elnmr',
    'cmm4fsb61007lxsv7sgez1s03',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz0n00kbxsv7bek81h6i',
    'cmm4fsb6m007oxsv7f2iubhqt',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz0w00kcxsv79udkln4u',
    'cmm4fsb6m007oxsv7f2iubhqt',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz1d00kdxsv7suvqyy7f',
    'cmm4fsb75007rxsv78m10rk0q',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz1s00kexsv7tjesj6qy',
    'cmm4fsb7l007txsv710kih271',
    NULL,
    'SKYFLAKES',
    1,
    4.46,
    4.46
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz2900kfxsv7knl9e4xu',
    'cmm4fsb7y007vxsv70bok0qqf',
    NULL,
    'SKYFLAKES BOX',
    1,
    53.55,
    53.55
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz2q00kgxsv70vlmp9xd',
    'cmm4fsb8b007xxsv71cu6f3lj',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz3600khxsv7hba7jh3b',
    'cmm4fsb8r007zxsv76mis0v2g',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz3m00kixsv7u1nii7kn',
    'cmm4fsb920081xsv7o9hlz0ht',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz4100kjxsv7gp982gxb',
    'cmm4fsb9g0083xsv7ohhqnvku',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz4i00kkxsv7wcgfbzg6',
    'cmm4fsb9u0085xsv7elh915a2',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz5300klxsv7ebm4zdbq',
    'cmm4fsbaa0087xsv7qjzjr7hi',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz5m00kmxsv78wvvvnzp',
    'cmm4fsbao0089xsv7dvwl48ks',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz6400knxsv7k01mazdq',
    'cmm4fsbb3008bxsv7gdczxhij',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz6l00koxsv7js936h07',
    'cmm4fsbbh008dxsv72xxzjj9s',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz7500kpxsv76vshljto',
    'cmm4fsbbv008fxsv7e6hyafyv',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz7o00kqxsv79aqbkgl6',
    'cmm4fsbc9008hxsv7xwm6k6o8',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz8b00krxsv7u581l3j4',
    'cmm4fsbck008jxsv7oagxqotq',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz8u00ksxsv731yp0ubc',
    'cmm4fsbcy008lxsv78jv4vbmb',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz9i00ktxsv7aikkcwph',
    'cmm4fsbdc008nxsv770wi9k6s',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxz9y00kuxsv7xblvjb6j',
    'cmm4fsbdr008pxsv7l28jtljt',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzal00kvxsv7k44zep0p',
    'cmm4fsbe3008rxsv7ktic5nsl',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzb100kwxsv74lgmz3lu',
    'cmm4fsbeg008txsv7g0blte7h',
    NULL,
    'Bear Brand 300g ',
    1,
    140.4,
    140.4
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzbe00kxxsv7bhlnb6jj',
    'cmm4fsbeu008vxsv716prf65e',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzbt00kyxsv74bcmfsir',
    'cmm4fsbf7008xxsv74vicggav',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzce00kzxsv7phm7d8ny',
    'cmm4fsbfk008zxsv79fft3uya',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzcv00l0xsv75f464msc',
    'cmm4fsbfz0091xsv7s7ej4rus',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzde00l1xsv7v1orazan',
    'cmm4fsbgd0093xsv7df7nfhng',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzdv00l2xsv7ktyakk9p',
    'cmm4fsbgr0095xsv7q4jbw05f',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzed00l3xsv713u340ln',
    'cmm4fsbh40097xsv7cf796581',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzew00l4xsv7d2tr8cyq',
    'cmm4fsbhh0099xsv731yi78ii',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzfb00l5xsv710vadmlw',
    'cmm4fsbhz009bxsv7x2iysm5s',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzfs00l6xsv7y1zooctx',
    'cmm4fsbie009dxsv7pelq6xa0',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzg800l7xsv7rp121xgf',
    'cmm4fsbiu009fxsv7ia4gnygf',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzgo00l8xsv779frli9x',
    'cmm4fsbj7009hxsv7lu2u612x',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzh200l9xsv7gguzmzn8',
    'cmm4fsbjk009jxsv7i01bepud',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzhk00laxsv7fw1ua85r',
    'cmm4fsbjy009lxsv71nlzdasf',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzi000lbxsv70gd92676',
    'cmm4fsbkc009nxsv7lzbsmm41',
    NULL,
    'Bear Brand 300g ',
    1,
    140.4,
    140.4
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzih00lcxsv7ktlvn3qv',
    'cmm4fsbkt009pxsv711wiec6p',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxziy00ldxsv7sk0eb9xd',
    'cmm4fsbl9009rxsv7ysyknatd',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzje00lexsv7c2xgosby',
    'cmm4fsblt009txsv7b8mi47tb',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzjw00lfxsv7ydj7k1hq',
    'cmm4fsbm9009vxsv7dmt3sgpn',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzkg00lgxsv701sndgar',
    'cmm4fsbmn009xxsv72rper094',
    NULL,
    'BEAR BRAND SWAK PACK 35G',
    1,
    20,
    20
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzl400lhxsv7cmix5zco',
    'cmm4fsbn1009zxsv706t6yc4q',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzlm00lixsv703cs39cg',
    'cmm4fsbnc00a1xsv777s19u7c',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzm200ljxsv7hyedabem',
    'cmm4fsbnp00a3xsv7mm9lknez',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzm900lkxsv7iqm5tlu4',
    'cmm4fsbnp00a3xsv7mm9lknez',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzmq00llxsv7piqttlb0',
    'cmm4fsbo500a6xsv71kj5576v',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzmw00lmxsv7bo36g8dv',
    'cmm4fsbo500a6xsv71kj5576v',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzn300lnxsv76wpuxp84',
    'cmm4fsbo500a6xsv71kj5576v',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzni00loxsv7pplixn0o',
    'cmm4fsbov00aaxsv7bd90jbe0',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxznp00lpxsv7ert6tl39',
    'cmm4fsbov00aaxsv7bd90jbe0',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxznx00lqxsv7sobi7my6',
    'cmm4fsbov00aaxsv7bd90jbe0',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzoc00lrxsv7c4v3e435',
    'cmm4fsbpn00aexsv7japinh8a',
    NULL,
    'Test Product With Sup 2plier',
    4,
    52.5,
    210
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzor00lsxsv76ri0ndi7',
    'cmm4fsbq200agxsv76kw7zlpk',
    NULL,
    'MILO® Powder 1kg',
    8,
    50,
    400
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzp800ltxsv7juvte4mk',
    'cmm4fsbqg00aixsv7zwy20ejn',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzpf00luxsv7tyjg3ww3',
    'cmm4fsbqg00aixsv7zwy20ejn',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzpm00lvxsv7i2ykari9',
    'cmm4fsbqg00aixsv7zwy20ejn',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzq400lwxsv7xzw1w2et',
    'cmm4fsbr700amxsv7lpipipdx',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzqe00lxxsv745bjyboz',
    'cmm4fsbr700amxsv7lpipipdx',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzr300lyxsv7ozcjltvx',
    'cmm4fsbru00apxsv7wbw001bk',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzrd00lzxsv7lma3tjp5',
    'cmm4fsbru00apxsv7wbw001bk',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzru00m0xsv7c7i5xy7r',
    'cmm4fsbsd00asxsv78qh00dmt',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzrz00m1xsv7p2xywbc9',
    'cmm4fsbsd00asxsv78qh00dmt',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzsd00m2xsv7glvyfyj0',
    'cmm4fsbsw00avxsv7wcpm4lgl',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzsr00m3xsv71rj0y8n5',
    'cmm4fsbt700axxsv73dcm1y4l',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzsx00m4xsv7oalqzekq',
    'cmm4fsbt700axxsv73dcm1y4l',
    NULL,
    'Bear Brand  300g',
    1,
    5.85,
    5.85
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxztc00m5xsv7pqwemlp9',
    'cmm4fsbtp00b0xsv75rs0cf94',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxztr00m6xsv79mzo33au',
    'cmm4fsbtp00b0xsv75rs0cf94',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzum00m7xsv70d3p2pwd',
    'cmm4fsbuo00b3xsv7e5zbkx8f',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzuv00m8xsv7eyxdbo15',
    'cmm4fsbuo00b3xsv7e5zbkx8f',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzvk00m9xsv7dtqflfk3',
    'cmm4fsbve00b6xsv7nsz4zmdo',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzvp00maxsv7nqz36str',
    'cmm4fsbve00b6xsv7nsz4zmdo',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzw300mbxsv7tx70qh4a',
    'cmm4fsbw000b9xsv7qil1jb56',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzw900mcxsv7peh26w3w',
    'cmm4fsbw000b9xsv7qil1jb56',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzwg00mdxsv7spl3zd4z',
    'cmm4fsbw000b9xsv7qil1jb56',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzwu00mexsv74yt6w7r6',
    'cmm4fsbwq00bdxsv7tadn53mk',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzx100mfxsv7p41k0q3z',
    'cmm4fsbwq00bdxsv7tadn53mk',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzxf00mgxsv7s2nlufix',
    'cmm4fsbxa00bgxsv7jyaj6t21',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzxv00mhxsv7ycprvqyf',
    'cmm4fsbxn00bixsv7o9032e3n',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzy900mixsv724ehbasr',
    'cmm4fsbxz00bkxsv72509jvqp',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzym00mjxsv7cn6ff9cg',
    'cmm4fsbyc00bmxsv7uukvi6n6',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzyq00mkxsv7szru27dh',
    'cmm4fsbyc00bmxsv7uukvi6n6',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzz500mlxsv7jutkalvx',
    'cmm4fsbyw00bpxsv7c9k7t2fl',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzze00mmxsv7oms8975m',
    'cmm4fsbyw00bpxsv7c9k7t2fl',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fxzzt00mnxsv7u0tab37h',
    'cmm4fsbzj00bsxsv7ay58a196',
    NULL,
    'Logitech MX Master 3S',
    3,
    6590,
    19770
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy00000moxsv7jyckkk2n',
    'cmm4fsbzj00bsxsv7ay58a196',
    NULL,
    'ODONG',
    4,
    60,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy00500mpxsv7f1o91bp0',
    'cmm4fsbzj00bsxsv7ay58a196',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy00j00mqxsv7dn27k8ze',
    'cmm4fsc0500bwxsv73rjoy27j',
    NULL,
    'Bear Brand 300g ',
    1,
    140.4,
    140.4
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy00x00mrxsv7ar7eds4c',
    'cmm4fsc0k00byxsv794sgvaru',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy01b00msxsv7hlhoeqz7',
    'cmm4fsc0z00c0xsv7xuohznyz',
    NULL,
    'DOWNY BOX 12S',
    1,
    150,
    150
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy01o00mtxsv7n0hooyqw',
    'cmm4fsc1c00c2xsv72jjiwfk8',
    NULL,
    'Bear Brand  300g',
    1,
    5.85,
    5.85
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy02a00muxsv7kpuh69jb',
    'cmm4fsc1p00c4xsv7zojzs4tp',
    NULL,
    'DOWNY BOX 12S',
    1,
    150,
    150
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy02n00mvxsv70an9dvr7',
    'cmm4fsc2200c6xsv7lhvgo0r9',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy03000mwxsv7wizjkiam',
    'cmm4fsc2g00c8xsv7mv337583',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy03d00mxxsv7ibbukuiw',
    'cmm4fsc2s00caxsv7ho92frv4',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy03s00myxsv7szm21aq5',
    'cmm4fsc3k00ccxsv7ulveybgm',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy03x00mzxsv7qkwufzlj',
    'cmm4fsc3k00ccxsv7ulveybgm',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy04a00n0xsv7chgzq0sj',
    'cmm4fsc4k00cfxsv7lmten3cr',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy04h00n1xsv7ubu0igq5',
    'cmm4fsc4k00cfxsv7lmten3cr',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy04w00n2xsv7fkw66iys',
    'cmm4fsc5700cixsv7u5mee55y',
    NULL,
    'Bear Brand  300g',
    1,
    5.85,
    5.85
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy05c00n3xsv7u2l3rynu',
    'cmm4fsc5k00ckxsv7pqphp1d4',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy05p00n4xsv75i0m82cy',
    'cmm4fsc5w00cmxsv7vdh3rygu',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy06300n5xsv7fi1kd82w',
    'cmm4fsc6a00coxsv7oihs4gyp',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy06h00n6xsv7tkljwc0e',
    'cmm4fsc6n00cqxsv713ono8ep',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy06n00n7xsv7lodfeubd',
    'cmm4fsc6n00cqxsv713ono8ep',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy07100n8xsv7ljqm1ity',
    'cmm4fsc7400ctxsv7qzt7j1gl',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy07d00n9xsv7y3p0ye3v',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy07k00naxsv7m9gxt4v8',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'ODONG',
    5,
    60,
    300
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy07q00nbxsv7abqgxgm7',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy07w00ncxsv7m2be8fh7',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy08200ndxsv73846dtjo',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy08900nexsv7xhija48h',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'NESCAFE BOX 35PACK',
    3,
    120,
    360
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy08e00nfxsv7lbouvtzl',
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    NULL,
    'macaroni 25g',
    4,
    52.5,
    210
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy08t00ngxsv74zimqhrf',
    'cmm4fsc9100d3xsv7q28l0n31',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy09000nhxsv7l62hnpfh',
    'cmm4fsc9100d3xsv7q28l0n31',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy09500nixsv70plhlt0l',
    'cmm4fsc9100d3xsv7q28l0n31',
    NULL,
    'DOWNY BOX 12S',
    1,
    150,
    150
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy09l00njxsv73yq2s92u',
    'cmm4fsc9p00d7xsv7vlte8upo',
    NULL,
    'BEAR BRAND SWAK PACK 35G',
    1,
    20,
    20
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy09s00nkxsv7vm5b2kbm',
    'cmm4fsc9p00d7xsv7vlte8upo',
    NULL,
    'DOWNY 12G',
    1,
    12.5,
    12.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy09y00nlxsv75ksgxd4u',
    'cmm4fsc9p00d7xsv7vlte8upo',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ae00nmxsv7g4n8i8s8',
    'cmm4fscae00dbxsv7bu4nwzav',
    NULL,
    'BEAR BRAND SWAK PACK 35G',
    1,
    20,
    20
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ak00nnxsv7c94e0ycc',
    'cmm4fscae00dbxsv7bu4nwzav',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0as00noxsv7clfodn3r',
    'cmm4fscae00dbxsv7bu4nwzav',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0b600npxsv7eoqf1jni',
    'cmm4fscb300dfxsv7ah24gn1z',
    NULL,
    'BEAR BRAND SWAK PACK 35G',
    1,
    20,
    20
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0bc00nqxsv7n90l5mxq',
    'cmm4fscb300dfxsv7ah24gn1z',
    NULL,
    'BEAR BRAND SWACK PACK BOX',
    1,
    240,
    240
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0bk00nrxsv73n6qhb78',
    'cmm4fscb300dfxsv7ah24gn1z',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0bp00nsxsv79hkrhmk8',
    'cmm4fscb300dfxsv7ah24gn1z',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0c700ntxsv7dsgo36ni',
    'cmm4fscby00dkxsv7gqnedjyr',
    NULL,
    'BEAR BRAND SWAK PACK 35G',
    1,
    20,
    20
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0cm00nuxsv7kl2ln680',
    'cmm4fscca00dmxsv7im055dr2',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0d000nvxsv79c399fj4',
    'cmm4fscco00doxsv779xdes3p',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0df00nwxsv7a5l81kmw',
    'cmm4fscd700dqxsv7mww0byvv',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0du00nxxsv765uj9fky',
    'cmm4fscdi00dsxsv72kzfvwvn',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ed00nyxsv765ds11qv',
    'cmm4fscdx00duxsv72042lmxg',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ex00nzxsv7zhn55ab1',
    'cmm4fsce900dwxsv7fms9rja6',
    NULL,
    'Logitech MX Master 3S',
    2,
    6590,
    13180
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0f200o0xsv7fdc72u83',
    'cmm4fsce900dwxsv7fms9rja6',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0fm00o1xsv7h13oe84x',
    'cmm4fscf300dzxsv7hk2bk4rg',
    NULL,
    'DOWNY BOX 12S',
    1,
    150,
    150
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0g300o2xsv7k2no0bsz',
    'cmm4fscfo00e1xsv7nmy9qsky',
    NULL,
    'DOWNY BOX 12S',
    1,
    150,
    150
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0gn00o3xsv7p8pc337a',
    'cmm4fscg900e3xsv7w176nu70',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0gv00o4xsv7do6sj824',
    'cmm4fscg900e3xsv7w176nu70',
    NULL,
    'DOWNY 12G',
    1,
    12.5,
    12.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0hq00o5xsv7mz6mcj6x',
    'cmm4fsch800e6xsv7ae4zqdah',
    NULL,
    'Bear Brand  300g',
    1,
    5.85,
    5.85
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0hy00o6xsv7x043ldf8',
    'cmm4fsch800e6xsv7ae4zqdah',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ie00o7xsv7qniwmuby',
    'cmm4fsci400e9xsv7mnmoj1sj',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0is00o8xsv7pbaujdik',
    'cmm4fsciq00ebxsv7n4zrwfqs',
    NULL,
    'Test Product With Sup 2plier',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0j600o9xsv7xl47zhw6',
    'cmm4fscjl00edxsv7z3gmw3dx',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0jk00oaxsv7nqoe066g',
    'cmm4fsckc00efxsv7dwm19omn',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0jy00obxsv7yxtm0haa',
    'cmm4fsckr00ehxsv7m3sedv69',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0k400ocxsv7h9mlrood',
    'cmm4fsckr00ehxsv7m3sedv69',
    NULL,
    'Test Product With Supplier',
    1,
    105,
    105
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ki00odxsv7yncmn3b0',
    'cmm4fscle00ekxsv7p7hlunoa',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0kz00oexsv7xsvxzwf7',
    'cmm4fsclq00emxsv7vvwhyms6',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ld00ofxsv7gzgsmq3e',
    'cmm4fscm200eoxsv7h5vx1vg0',
    NULL,
    'macaroni 25g',
    1,
    52.5,
    52.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0lk00ogxsv7hb59k0id',
    'cmm4fscm200eoxsv7h5vx1vg0',
    NULL,
    'ODONG',
    1,
    60,
    60
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0lz00ohxsv7f8p0lseq',
    'cmm4fscmk00erxsv7ifjjns5u',
    NULL,
    'iPhone 15 Pro 256GB',
    3,
    70990,
    212970
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0m400oixsv7iukcehpv',
    'cmm4fscmk00erxsv7ifjjns5u',
    NULL,
    'ODONG',
    3,
    60,
    180
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0mk00ojxsv7sxlcba2k',
    'cmm4fscn600euxsv7ff8n0jbd',
    NULL,
    'Bear Brand 300g ',
    1,
    140.4,
    140.4
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0n000okxsv72x0tjrjg',
    'cmm4fscnl00ewxsv75rkgf2ur',
    NULL,
    'Logitech MX Master 3S',
    1,
    6590,
    6590
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0nf00olxsv7mlet4z2i',
    'cmm4fscny00eyxsv7ufc8srsc',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0nl00omxsv7yni423f0',
    'cmm4fscny00eyxsv7ufc8srsc',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0nz00onxsv7505iscla',
    'cmm4fscof00f1xsv7al03sr6k',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0of00ooxsv7s2o43npg',
    'cmm4fscot00f3xsv7slj13gn7',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0ot00opxsv7tve8vcqz',
    'cmm4fscp700f5xsv7ipnce8cr',
    NULL,
    'DOWNY 12G',
    1,
    12.5,
    12.5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0p800oqxsv7gpsn6oqq',
    'cmm4fscpk00f7xsv7r19oqqdm',
    NULL,
    'Bear Brand  300g',
    1,
    5.85,
    5.85
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0pe00orxsv7ual9i2ng',
    'cmm4fscpk00f7xsv7r19oqqdm',
    NULL,
    'Bear Brand 300g ',
    1,
    140.4,
    140.4
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0pu00osxsv7f7k23m91',
    'cmm4fscqa00faxsv7xxzqwznm',
    NULL,
    'NESCAFE BOX 35PACK',
    1,
    120,
    120
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0qe00otxsv7f5iezvms',
    'cmm4fscqo00fcxsv7qx3q4ypw',
    NULL,
    'ODONG',
    1,
    5,
    5
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0qk00ouxsv7exjq936z',
    'cmm4fscqo00fcxsv7qx3q4ypw',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0rc00ovxsv7hlmzj9qn',
    'cmm4fscrd00ffxsv7oxcvbgtl',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0s900owxsv7mpuqlmcr',
    'cmm4fscru00fhxsv7tgrplikh',
    NULL,
    'Bear Brand 300g ',
    1,
    140.4,
    140.4
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0sz00oxxsv7ugmjzv0a',
    'cmm4fscs900fjxsv7ngm959ju',
    NULL,
    'Logitech MX Master 3S',
    1,
    6590,
    6590
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0to00oyxsv7pac1zlr1',
    'cmm4fscso00flxsv7q8vpfrbm',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0tx00ozxsv7d5a4zdes',
    'cmm4fscso00flxsv7q8vpfrbm',
    NULL,
    'NESCAFE STICK 35G',
    1,
    10,
    10
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0u800p0xsv7k3x2dlt1',
    'cmm4fscso00flxsv7q8vpfrbm',
    NULL,
    'Logitech MX Master 3S',
    1,
    6590,
    6590
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0uv00p1xsv71p9cphv6',
    'cmm4fsctb00fpxsv7rmf9ko74',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0v500p2xsv7jck9k542',
    'cmm4fsctb00fpxsv7rmf9ko74',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0vd00p3xsv74orizi7k',
    'cmm4fsctb00fpxsv7rmf9ko74',
    NULL,
    'DOWNY BOX 12S',
    1,
    150,
    150
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0vz00p4xsv71bpjgt08',
    'cmm4fscu200ftxsv7k5jny69a',
    NULL,
    'iPhone 15 Pro 256GB',
    1,
    70990,
    70990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0wa00p5xsv758ursnkj',
    'cmm4fscu200ftxsv7k5jny69a',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0wx00p6xsv7mq6wcxjd',
    'cmm4fscun00fwxsv7f311n7k5',
    NULL,
    'MacBook Air M2 13\"',
    1,
    59990,
    59990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0x600p7xsv74q02vxv3',
    'cmm4fscun00fwxsv7f311n7k5',
    NULL,
    'Samsung Galaxy S23 Ultra',
    1,
    68990,
    68990
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0xj00p8xsv74k2rm60w',
    'cmm4fscv700fzxsv7trhtjt45',
    NULL,
    'MILO Powder 1kg',
    1,
    600,
    600
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0xw00p9xsv7uud5p7he',
    'cmm4fscvk00g1xsv7jr61pjln',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );
INSERT INTO
  `pos_sale_item` (
    `id`,
    `posSaleId`,
    `productId`,
    `productName`,
    `quantity`,
    `unitPrice`,
    `total`
  )
VALUES
  (
    'cmm4fy0yb00paxsv7mi2ymu6g',
    'cmm4fscvx00g3xsv7esqwfw1k',
    NULL,
    'MILO® Powder 1kg',
    1,
    50,
    50
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: pos_sales
# ------------------------------------------------------------

INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9lh0001xsv7x9s1ktwx',
    'INV-1772156518364-5y73w',
    '2026-02-26 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.248',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.300'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9mf0003xsv7xhb78cbu',
    'INV-1772156487868-3i5c7',
    '2026-02-26 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.286',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.320'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9n40005xsv74j0s30dl',
    'INV-1772156276024-yluvq',
    '2026-02-26 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.309',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.340'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9ns0007xsv7ps61jcr9',
    'INV-1772156208846-xpme6',
    '2026-02-26 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.333',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.357'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9o90009xsv7ud0s2wxf',
    'INV-1772156132299-9n3dj',
    '2026-02-26 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.351',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.375'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9ow000bxsv7oe51c4lo',
    'INV-1772151634060-4m493',
    '2026-02-26 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.375',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.392'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9pd000dxsv70umu4cs3',
    'INV-1772151536940-bzouj',
    '2026-02-26 16:00:00.000',
    1796.8,
    NULL,
    0,
    '2026-02-27 05:13:19.392',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.409'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9qk000ixsv7cf7op1cs',
    'INV-1772151408701-ztm09',
    '2026-02-26 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.434',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.449'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9r0000kxsv7k5uzeb18',
    'INV-1772103053963-0xfkq',
    '2026-02-25 16:00:00.000',
    100,
    NULL,
    0,
    '2026-02-27 05:13:19.450',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.465'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9rc000mxsv7k3f1ykr4',
    'INV-1772011998532-q2seu',
    '2026-02-24 16:00:00.000',
    480,
    NULL,
    0,
    '2026-02-27 05:13:19.463',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.478'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9rp000oxsv7cu7wveqz',
    'INV-1772011124751-gvh3g',
    '2026-02-24 16:00:00.000',
    960,
    NULL,
    0,
    '2026-02-27 05:13:19.476',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.494'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9s8000qxsv72z135255',
    'INV-1772010525596-lqoae',
    '2026-02-24 16:00:00.000',
    960,
    NULL,
    0,
    '2026-02-27 05:13:19.494',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.510'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9sm000sxsv7rgw8ftw1',
    'INV-1772010204865-4qpmt',
    '2026-02-24 16:00:00.000',
    900,
    NULL,
    0,
    '2026-02-27 05:13:19.509',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.526'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9t0000uxsv7toxy89bd',
    'INV-1772009573887-6dksg',
    '2026-02-24 16:00:00.000',
    960,
    NULL,
    0,
    '2026-02-27 05:13:19.523',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.544'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9te000wxsv7rom6573j',
    'INV-1771837270348-ao99h',
    '2026-02-22 16:00:00.000',
    157.5,
    NULL,
    0,
    '2026-02-27 05:13:19.537',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.559'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9tt000yxsv77y0ayfqu',
    'inv_1771837257533_psm57a737',
    '2026-02-22 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:19.552',
    0,
    'Charge',
    0,
    0,
    '2026-02-27 05:17:43.576'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9u60010xsv7o9hdn2te',
    'INV-1771837121603-nypbl',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.565',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.593'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9ul0012xsv7syuv7om4',
    'inv_1771837026228_r2jsaaq15',
    '2026-02-22 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:19.580',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:43.610'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9v10014xsv7kq2s7gz3',
    'INV-1771835859517-zdrgw',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.596',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.626'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9vk0016xsv722rohjs1',
    'inv_1771834313627_17c0uhm01',
    '2026-02-22 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:19.615',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:43.641'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9vw0018xsv78s9c4ty9',
    'INV-1771834256269-zs3s3',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.627',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.657'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9wb001axsv7sog6hzbg',
    'INV-1771833885655-7x41u',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.641',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.673'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9wp001cxsv7fh9n9z05',
    'inv_1771833102009_0ttru5zxv',
    '2026-02-22 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:19.656',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:43.689'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9x2001exsv75jpw85x6',
    'INV-1771833039130-cxds9',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.669',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.704'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9xf001gxsv7khbuc53u',
    'INV-1771832490924-uswfg',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.680',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.719'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9xt001ixsv7c3utkzl9',
    'inv_1771832482741_sn6da6mqn',
    '2026-02-22 16:00:00.000',
    6590,
    NULL,
    0,
    '2026-02-27 05:13:19.696',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:43.731'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9y7001kxsv7pcta5kk4',
    'INV-1771831295109-lh60t',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.710',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.746'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9yl001mxsv76kes4nva',
    'inv_1771831242646_bm07ejyxm',
    '2026-02-22 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:19.725',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:43.764'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9z1001oxsv7vf7lb0oa',
    'inv_1771829860099_m0shlfjdv',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.740',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.779'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9zi001qxsv7gsyptpau',
    'inv_1771829752047_may7zc3no',
    '2026-02-22 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:19.757',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.794'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fs9zy001sxsv7yokgxvpt',
    'INV-1771827305074-ry82b',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.772',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.810'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa08001uxsv7jvxcqce2',
    'INV-1771826272398-e7klv',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.783',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.826'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa0l001wxsv7to26tlym',
    'INV-1771825787531-mcz1x',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.796',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.839'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa0z001yxsv7cnpn0tn1',
    'INV-1771825069872-zcxce',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.810',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.855'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa1h0020xsv7o76i5rc6',
    'INV-1771825049918-r6djx',
    '2026-02-22 16:00:00.000',
    515,
    NULL,
    0,
    '2026-02-27 05:13:19.827',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.871'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa1x0022xsv72k41a2ms',
    'INV-1771825022424-8vai0',
    '2026-02-22 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:19.844',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.886'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa2d0024xsv79v922bly',
    'INV-1771823747022-wp7ws',
    '2026-02-22 16:00:00.000',
    17.2,
    NULL,
    0,
    '2026-02-27 05:13:19.860',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.901'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa2s0026xsv7gpap2trh',
    'INV-1771823043883-7ue4e',
    '2026-02-22 16:00:00.000',
    515,
    NULL,
    0,
    '2026-02-27 05:13:19.876',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.917'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa390028xsv7ry4ildue',
    'INV-1771822023023-7g1nb',
    '2026-02-22 16:00:00.000',
    515,
    NULL,
    0,
    '2026-02-27 05:13:19.890',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.932'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa3p002axsv7v5vdeh8m',
    'INV-1771812187787-sqdya',
    '2026-02-22 16:00:00.000',
    4.3,
    NULL,
    0,
    '2026-02-27 05:13:19.907',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.947'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa41002cxsv73jmjjxvj',
    'INV-1771812174778-chb1a',
    '2026-02-22 16:00:00.000',
    515,
    NULL,
    0,
    '2026-02-27 05:13:19.920',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.960'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa4h002exsv7dc94uefc',
    'INV-1771812137858-qci5v',
    '2026-02-22 16:00:00.000',
    519.3,
    NULL,
    0,
    '2026-02-27 05:13:19.936',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.973'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa53002hxsv7zu9w99vr',
    'INV-1771658927621-dhau1',
    '2026-02-20 16:00:00.000',
    69090,
    NULL,
    0,
    '2026-02-27 05:13:19.957',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:43.995'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa5r002kxsv7kiqzzzq3',
    'INV-1771658909701-vuh5n',
    '2026-02-20 16:00:00.000',
    111.8,
    NULL,
    0,
    '2026-02-27 05:13:19.982',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.017'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa64002mxsv7oohqgomx',
    'INV-1771658695725-ptn8f',
    '2026-02-20 16:00:00.000',
    515,
    NULL,
    0,
    '2026-02-27 05:13:19.995',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.032'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa6n002oxsv7gp721wd5',
    'INV-1771657018058-6jes5',
    '2026-02-20 16:00:00.000',
    519.3,
    NULL,
    0,
    '2026-02-27 05:13:20.014',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.047'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa78002rxsv7vbw7i60g',
    'INV-1771656974043-l27hk',
    '2026-02-20 16:00:00.000',
    558.75,
    NULL,
    0,
    '2026-02-27 05:13:20.035',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.067'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa7r002uxsv74r3q7064',
    'INV-1771554417848-r0xnq',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.054',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.090'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa85002wxsv7cgafz3ze',
    'INV-1771554368178-4p8ja',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.068',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.105'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa8i002yxsv7jk55e5qc',
    'INV-1771554116090-19j51',
    '2026-02-19 16:00:00.000',
    535.5,
    NULL,
    0,
    '2026-02-27 05:13:20.080',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.124'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa8v0030xsv7d41wfrtg',
    'INV-1771554022174-zaq02',
    '2026-02-19 16:00:00.000',
    214.2,
    NULL,
    0,
    '2026-02-27 05:13:20.094',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.139'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa990032xsv7mx1h2z1f',
    'INV-1771553246769-fzj1l',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.107',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.153'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsa9n0034xsv7qxagqwjm',
    'INV-1771553183044-rxsjy',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.122',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.169'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaa00036xsv7r8a9ev50',
    'INV-1771552981481-9szkg',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.135',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.185'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaaf0038xsv7yl6kwawn',
    'INV-1771552932629-2svzn',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.149',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.199'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaau003axsv72v705bzp',
    'INV-1771552901842-bzna3',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.165',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.225'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsab8003cxsv70nk20oo2',
    'INV-1771552676301-9kt0t',
    '2026-02-19 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:20.179',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.256'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsabm003exsv752spkjmf',
    'INV-1771552180317-x8mxq',
    '2026-02-19 16:00:00.000',
    60040,
    NULL,
    0,
    '2026-02-27 05:13:20.193',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.278'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsac9003hxsv78jw5lzam',
    'INV-1771490310685-bzooz',
    '2026-02-18 16:00:00.000',
    321.3,
    NULL,
    0,
    '2026-02-27 05:13:20.216',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.301'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaco003jxsv7pghg04zc',
    'INV-1771488726479-v1dt9',
    '2026-02-18 16:00:00.000',
    321.3,
    NULL,
    0,
    '2026-02-27 05:13:20.230',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.317'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsad2003lxsv73aipaxis',
    'INV-1771488036707-mmyus',
    '2026-02-18 16:00:00.000',
    481.95,
    NULL,
    0,
    '2026-02-27 05:13:20.245',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.331'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsadh003nxsv7ut6h9enu',
    'INV-1771487857070-auetz',
    '2026-02-18 16:00:00.000',
    535.5,
    NULL,
    0,
    '2026-02-27 05:13:20.260',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.345'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsadv003pxsv7rf2o79uu',
    'INV-1771405924543-ln04q',
    '2026-02-17 16:00:00.000',
    267.75,
    NULL,
    0,
    '2026-02-27 05:13:20.274',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.361'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsae7003rxsv73bh1eelu',
    'INV-1771404977665-l5ivz',
    '2026-02-17 16:00:00.000',
    321.3,
    NULL,
    0,
    '2026-02-27 05:13:20.286',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.376'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaew003txsv7r1xuea0n',
    'INV-1771402529823-6y1ro',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.310',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.389'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsafo003vxsv7005x9y6j',
    'INV-1771402514001-v4jhr',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.338',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.408'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsag9003xxsv7i9qsa5i5',
    'INV-1771402480159-1uf3v',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.358',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.422'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsagt003zxsv7i7pov0ut',
    'INV-1771395164905-xxrms',
    '2026-02-17 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:20.380',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.437'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsah70041xsv72ffp51df',
    'INV-1771385635319-sftju',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.394',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.451'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsahp0043xsv791cop54p',
    'INV-1771385491435-7dlr0',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.411',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.466'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsai40045xsv7si2chis3',
    'INV-1771385081924-9rkx8',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.426',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.478'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaij0047xsv7p1zec8oj',
    'INV-1771384862472-ipa7r',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.442',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.491'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaiu0049xsv7m53om0j0',
    'INV-1771384460219-qqm21',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.453',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.505'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaj8004bxsv7ze1v9ytl',
    'INV-1771384166270-9vfgh',
    '2026-02-17 16:00:00.000',
    267.75,
    NULL,
    0,
    '2026-02-27 05:13:20.466',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.519'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsajm004dxsv78mwruby3',
    'INV-1771383527540-tpsvy',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.480',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.534'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsak0004fxsv7v9ygszqj',
    'INV-1771383389170-wz5ij',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.495',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.546'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsake004hxsv7ywloiz9x',
    'INV-1771383231825-fh5ke',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.509',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.560'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsakr004jxsv7eqcg63md',
    'INV-1771382845770-qn2hj',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.522',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.575'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsal4004lxsv789kuw4cc',
    'INV-1771382487552-furlf',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.535',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.589'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsalh004nxsv7ldx71znr',
    'INV-1771382430731-y734w',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.548',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.600'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsalt004pxsv7ygommuv3',
    'INV-1771382315286-pgcpu',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.560',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.613'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsam3004rxsv7q08nzpst',
    'INV-1771381102731-l16zg',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.570',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.627'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsamf004txsv77wrlkobl',
    'INV-1771375683890-g7g3t',
    '2026-02-17 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.583',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.644'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsamr004vxsv72r4jwk55',
    'INV-1771233764320-pyawi',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.594',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.659'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsan5004xxsv7hqvcr2mo',
    'INV-1771209726419-ehelf',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.608',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.673'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsanj004zxsv7f497vjzz',
    'INV-1771209668997-xuopo',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.622',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.686'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsanv0051xsv7ae6prt66',
    'INV-1771207596947-ic2tz',
    '2026-02-15 16:00:00.000',
    1017.45,
    NULL,
    0,
    '2026-02-27 05:13:20.634',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.700'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaob0053xsv7upxyee7w',
    'INV-1771207534718-b19am',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.650',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.712'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaoo0055xsv7jqnan5og',
    'INV-1771207361041-1bkrm',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.663',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.727'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsap10057xsv7v94oizo1',
    'INV-1771207338079-omtyw',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.676',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.741'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsape0059xsv7iuor9bq3',
    'INV-1771207248375-1l75w',
    '2026-02-15 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:20.689',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.757'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsapr005bxsv7obfipt7k',
    'INV-1771206931450-zagg2',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.702',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.770'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaq4005dxsv7beyzkvof',
    'INV-1771206597437-aofii',
    '2026-02-15 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:20.716',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.784'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaqg005fxsv7zx47f4lm',
    'INV-1771206216683-l4px6',
    '2026-02-15 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:20.728',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.798'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaqv005hxsv7aibqntb0',
    'INV-1771205747369-p8bru',
    '2026-02-15 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:20.742',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.811'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsard005jxsv7174u9zz8',
    'INV-1771205698279-d2n3v',
    '2026-02-15 16:00:00.000',
    68990,
    NULL,
    0,
    '2026-02-27 05:13:20.759',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.826'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsarr005lxsv7afochnmi',
    'INV-1770963478294-9aqst',
    '2026-02-12 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:20.773',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.839'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsas7005nxsv7rk9no9be',
    'INV-1770955218609-pzgjt',
    '2026-02-12 16:00:00.000',
    568.75,
    NULL,
    0,
    '2026-02-27 05:13:20.790',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.852'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsass005qxsv7yjwtalnc',
    'INV-1770889316078-d863i',
    '2026-02-11 16:00:00.000',
    589.05,
    NULL,
    0,
    '2026-02-27 05:13:20.810',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.870'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsatb005sxsv72iq2flq5',
    'INV-1770889295198-sfi3m',
    '2026-02-11 16:00:00.000',
    856.8,
    NULL,
    0,
    '2026-02-27 05:13:20.829',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.886'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsatr005uxsv7lv8cucfw',
    'INV-1770889017453-411ym',
    '2026-02-11 16:00:00.000',
    525,
    NULL,
    0,
    '2026-02-27 05:13:20.847',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.900'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsau5005wxsv73e1v5w67',
    'INV-1770888991484-s5g4h',
    '2026-02-11 16:00:00.000',
    840,
    NULL,
    0,
    '2026-02-27 05:13:20.861',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.915'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaul005yxsv7tcfuo71i',
    'INV-1770888959394-yjn7n',
    '2026-02-11 16:00:00.000',
    673.75,
    NULL,
    0,
    '2026-02-27 05:13:20.876',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.930'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsav50061xsv7mpdm5qfn',
    'INV-1770887882998-lv2wz',
    '2026-02-11 16:00:00.000',
    525,
    NULL,
    0,
    '2026-02-27 05:13:20.896',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.951'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsavh0063xsv7hi3bic03',
    'INV-1770887507312-kat77',
    '2026-02-11 16:00:00.000',
    568.75,
    NULL,
    0,
    '2026-02-27 05:13:20.907',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.965'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaw00066xsv725qykrmv',
    'INV-1770887462254-4maoq',
    '2026-02-11 16:00:00.000',
    568.75,
    NULL,
    0,
    '2026-02-27 05:13:20.927',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:44.988'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsawm0069xsv7skya9au8',
    'INV-1770885477856-eomd5',
    '2026-02-11 16:00:00.000',
    87.5,
    NULL,
    0,
    '2026-02-27 05:13:20.949',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.011'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsax2006bxsv73ftycs59',
    'INV-1770885293489-avj97',
    '2026-02-11 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:20.964',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.025'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaxh006dxsv7mmq4z86x',
    'INV-1770885245207-ko0po',
    '2026-02-11 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:20.980',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.039'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsaxw006fxsv7fi2qp6ce',
    'INV-1770885223500-ddez0',
    '2026-02-11 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:20.995',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.056'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsay9006hxsv7ptij9ggc',
    'INV-1770885187849-1swvi',
    '2026-02-11 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:21.008',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.072'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsayq006jxsv7bsmakwd5',
    'INV-1770885051942-sgxa6',
    '2026-02-11 16:00:00.000',
    816.9,
    NULL,
    0,
    '2026-02-27 05:13:21.024',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.085'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsazz006qxsv75kxw904u',
    'INV-1770881987802-nzctv',
    '2026-02-11 16:00:00.000',
    568.75,
    NULL,
    0,
    '2026-02-27 05:13:21.069',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.135'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb0h006txsv7pvotfjsf',
    'INV-1770866289802-srm60',
    '2026-02-11 16:00:00.000',
    154.26,
    NULL,
    0,
    '2026-02-27 05:13:21.088',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.182'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb1l006yxsv7u9rejpit',
    'INV-1770794895793-i576a',
    '2026-02-10 16:00:00.000',
    525,
    NULL,
    0,
    '2026-02-27 05:13:21.128',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.229'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb200070xsv7kdt6wa07',
    'INV-1770794827673-cy9p4',
    '2026-02-10 16:00:00.000',
    43.75,
    NULL,
    0,
    '2026-02-27 05:13:21.143',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.242'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb2e0072xsv72jlh9hv6',
    'INV-1770794744884-rj84t',
    '2026-02-10 16:00:00.000',
    87.5,
    NULL,
    0,
    '2026-02-27 05:13:21.157',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.277'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb2u0074xsv7llqc86nm',
    'INV-1770787164559-pfjiu',
    '2026-02-10 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.171',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.300'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb3b0076xsv7kf29v12k',
    'INV-1770787077265-iacdo',
    '2026-02-10 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.190',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.315'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb3p0078xsv7ks68khor',
    'INV-1770786065913-qxe6r',
    '2026-02-10 16:00:00.000',
    218.75,
    NULL,
    0,
    '2026-02-27 05:13:21.204',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.327'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb43007axsv7r1kdrmw7',
    'INV-1770772954713-h9pty',
    '2026-02-10 16:00:00.000',
    58.01,
    NULL,
    0,
    '2026-02-27 05:13:21.218',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.343'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb4l007dxsv7ciqztbad',
    'INV-1770771665361-16uy9',
    '2026-02-10 16:00:00.000',
    8.92,
    NULL,
    0,
    '2026-02-27 05:13:21.236',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.363'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb4y007fxsv7wy3eae5u',
    'INV-1770771637751-eymcv',
    '2026-02-10 16:00:00.000',
    56.96,
    NULL,
    0,
    '2026-02-27 05:13:21.249',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.384'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb5i007ixsv7tc5o8xz2',
    'INV-1770771351001-i2s4h',
    '2026-02-10 16:00:00.000',
    58.01,
    NULL,
    0,
    '2026-02-27 05:13:21.269',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.414'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb61007lxsv7sgez1s03',
    'INV-1770716127353-bhuty',
    '2026-02-09 16:00:00.000',
    58.01,
    NULL,
    0,
    '2026-02-27 05:13:21.288',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.445'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb6m007oxsv7f2iubhqt',
    'INV-1770715766539-e47co',
    '2026-02-09 16:00:00.000',
    57.5,
    NULL,
    0,
    '2026-02-27 05:13:21.309',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.467'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb75007rxsv78m10rk0q',
    'INV-1770706123593-wgo51',
    '2026-02-09 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:21.328',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.493'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb7l007txsv710kih271',
    'INV-1770705933090-fzd6w',
    '2026-02-09 16:00:00.000',
    4.46,
    NULL,
    0,
    '2026-02-27 05:13:21.344',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.509'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb7y007vxsv70bok0qqf',
    'INV-1770705248131-3p9fd',
    '2026-02-09 16:00:00.000',
    53.55,
    NULL,
    0,
    '2026-02-27 05:13:21.357',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.526'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb8b007xxsv71cu6f3lj',
    'INV-1770198113977-aofe3',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.370',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.542'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb8r007zxsv76mis0v2g',
    'INV-1770198100330-0qm6a',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.384',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.558'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb920081xsv7o9hlz0ht',
    'INV-1770192229743-xz9y5',
    '2026-02-03 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:21.397',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.574'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb9g0083xsv7ohhqnvku',
    'INV-1770191952416-g33sj',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.411',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.592'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsb9u0085xsv7elh915a2',
    'INV-1770191072232-0sezc',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.424',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.607'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbaa0087xsv7qjzjr7hi',
    'INV-1770190826802-le573',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.440',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.625'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbao0089xsv7dvwl48ks',
    'INV-1770190538612-okmxs',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.454',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.644'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbb3008bxsv7gdczxhij',
    'INV-1770181174760-ys9z5',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.470',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.663'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbbh008dxsv72xxzjj9s',
    'INV-1770180349929-rp6n8',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.480',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:45.681'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbbv008fxsv7e6hyafyv',
    'INV-1770178352656-ekkzk',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.498',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.699'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbc9008hxsv7xwm6k6o8',
    'INV-1770177817554-lmn0d',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.512',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:45.719'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbck008jxsv7oagxqotq',
    'INV-1770177790778-redml',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.523',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.740'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbcy008lxsv78jv4vbmb',
    'INV-1770177570235-u83zx',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.537',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:45.760'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbdc008nxsv770wi9k6s',
    'INV-1770177561792-cogb7',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.551',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.785'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbdr008pxsv7l28jtljt',
    'INV-1770177451342-8o89v',
    '2026-02-03 16:00:00.000',
    600,
    NULL,
    0,
    '2026-02-27 05:13:21.566',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.803'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbe3008rxsv7ktic5nsl',
    'INV-1770177211217-4oixc',
    '2026-02-03 16:00:00.000',
    68990,
    NULL,
    0,
    '2026-02-27 05:13:21.578',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.824'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbeg008txsv7g0blte7h',
    'INV-1770177100138-2rzou',
    '2026-02-03 16:00:00.000',
    140.4,
    NULL,
    0,
    '2026-02-27 05:13:21.591',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.841'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbeu008vxsv716prf65e',
    'INV-1770176426929-o74h7',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.605',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.857'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbf7008xxsv74vicggav',
    'INV-1770176293874-aq2f3',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.617',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.872'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbfk008zxsv79fft3uya',
    'INV-1770176159048-stx86',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.631',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:45.888'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbfz0091xsv7s7ej4rus',
    'INV-1770176129112-4h6dt',
    '2026-02-03 16:00:00.000',
    600,
    NULL,
    0,
    '2026-02-27 05:13:21.646',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:45.907'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbgd0093xsv7df7nfhng',
    'INV-1770176116514-vwk59',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.660',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.925'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbgr0095xsv7q4jbw05f',
    'INV-1770175796616-h2d4m',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.674',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.944'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbh40097xsv7cf796581',
    'INV-1770175780391-588zb',
    '2026-02-03 16:00:00.000',
    10,
    NULL,
    0,
    '2026-02-27 05:13:21.688',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:45.961'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbhh0099xsv731yi78ii',
    'INV-1770175764892-ind8b',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.701',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.979'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbhz009bxsv7x2iysm5s',
    'INV-1770175597856-semwg',
    '2026-02-03 16:00:00.000',
    10,
    NULL,
    0,
    '2026-02-27 05:13:21.717',
    0,
    '',
    0,
    0,
    '2026-02-27 05:17:45.996'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbie009dxsv7pelq6xa0',
    'INV-1770175033948-whkn3',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.731',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.011'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbiu009fxsv7ia4gnygf',
    'INV-1770174949091-kzxar',
    '2026-02-03 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:21.747',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.028'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbj7009hxsv7lu2u612x',
    'INV-1770174601812-tw8xu',
    '2026-02-03 16:00:00.000',
    240,
    NULL,
    0,
    '2026-02-27 05:13:21.761',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.046'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbjk009jxsv7i01bepud',
    'INV-1770174584678-p37kn',
    '2026-02-03 16:00:00.000',
    10,
    NULL,
    0,
    '2026-02-27 05:13:21.774',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.061'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbjy009lxsv71nlzdasf',
    'INV-1770174317785-41u0t',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.789',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.075'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbkc009nxsv7lzbsmm41',
    'INV-1770174307666-n2fnm',
    '2026-02-03 16:00:00.000',
    140.4,
    NULL,
    0,
    '2026-02-27 05:13:21.803',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.093'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbkt009pxsv711wiec6p',
    'INV-1770174258394-1f7zu',
    '2026-02-03 16:00:00.000',
    600,
    NULL,
    0,
    '2026-02-27 05:13:21.819',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.109'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbl9009rxsv7ysyknatd',
    'INV-1770174126003-zv3i1',
    '2026-02-03 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:21.836',
    0,
    'Cash',
    0,
    0,
    '2026-02-27 05:17:46.127'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsblt009txsv7b8mi47tb',
    'INV-1770174117651-cecik',
    '2026-02-03 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:21.855',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.142'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbm9009vxsv7dmt3sgpn',
    'INV-1770174100077-aqt4x',
    '2026-02-03 16:00:00.000',
    240,
    NULL,
    0,
    '2026-02-27 05:13:21.871',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.159'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbmn009xxsv72rper094',
    'INV-1770174079689-ypzh5',
    '2026-02-03 16:00:00.000',
    20,
    NULL,
    0,
    '2026-02-27 05:13:21.886',
    0,
    'Bank Transfer',
    0,
    0,
    '2026-02-27 05:17:46.178'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbn1009zxsv706t6yc4q',
    'INV-1770168744834-yfs5n',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.900',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.202'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbnc00a1xsv777s19u7c',
    'INV-1770168719200-wc8nm',
    '2026-02-03 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:21.912',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.222'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbnp00a3xsv7mm9lknez',
    'INV-1770117072614-hzrn4',
    '2026-02-02 16:00:00.000',
    105,
    NULL,
    0,
    '2026-02-27 05:13:21.924',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.238'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbo500a6xsv71kj5576v',
    'INV-1770116970668-lojs1',
    '2026-02-02 16:00:00.000',
    210,
    NULL,
    0,
    '2026-02-27 05:13:21.941',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.262'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbov00aaxsv7bd90jbe0',
    'INV-1770116500532-wu1gr',
    '2026-02-02 16:00:00.000',
    110,
    NULL,
    0,
    '2026-02-27 05:13:21.966',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.291'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbpn00aexsv7japinh8a',
    'INV-1770116317254-oorha',
    '2026-02-02 16:00:00.000',
    210,
    NULL,
    0,
    '2026-02-27 05:13:21.994',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.321'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbq200agxsv76kw7zlpk',
    'INV-1770115986292-z6jg0',
    '2026-02-02 16:00:00.000',
    400,
    NULL,
    0,
    '2026-02-27 05:13:22.009',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.338'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbqg00aixsv7zwy20ejn',
    'INV-1770095253498-xu31s',
    '2026-02-02 16:00:00.000',
    117.5,
    NULL,
    0,
    '2026-02-27 05:13:22.023',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.352'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbr700amxsv7lpipipdx',
    'INV-1770095022681-khbr7',
    '2026-02-02 16:00:00.000',
    71095,
    NULL,
    0,
    '2026-02-27 05:13:22.050',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.383'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbru00apxsv7wbw001bk',
    'INV-1770094727396-klo44',
    '2026-02-02 16:00:00.000',
    139980,
    NULL,
    0,
    '2026-02-27 05:13:22.073',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.411'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbsd00asxsv78qh00dmt',
    'INV-1770091725129-ldujy',
    '2026-02-02 16:00:00.000',
    71042.5,
    NULL,
    0,
    '2026-02-27 05:13:22.092',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.448'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbsw00avxsv7wcpm4lgl',
    'INV-1770091456110-j4zmv',
    '2026-02-02 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.111',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.466'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbt700axxsv73dcm1y4l',
    'INV-1770091271940-7yqy4',
    '2026-02-02 16:00:00.000',
    110.85,
    NULL,
    0,
    '2026-02-27 05:13:22.122',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.480'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbtp00b0xsv75rs0cf94',
    'INV-1770090497905-b5ehh',
    '2026-02-02 16:00:00.000',
    165,
    NULL,
    0,
    '2026-02-27 05:13:22.140',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.502'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbuo00b3xsv7e5zbkx8f',
    'INV-1770089848151-nnawf',
    '2026-02-02 16:00:00.000',
    65,
    NULL,
    0,
    '2026-02-27 05:13:22.174',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.534'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbve00b6xsv7nsz4zmdo',
    'INV-1770089376379-l53ub',
    '2026-02-02 16:00:00.000',
    112.5,
    NULL,
    0,
    '2026-02-27 05:13:22.200',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.573'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbw000b9xsv7qil1jb56',
    'INV-1770082858508-eb77y',
    '2026-02-02 16:00:00.000',
    71155,
    NULL,
    0,
    '2026-02-27 05:13:22.223',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.600'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbwq00bdxsv7tadn53mk',
    'INV-1770081336412-peah2',
    '2026-02-02 16:00:00.000',
    57.5,
    NULL,
    0,
    '2026-02-27 05:13:22.249',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.627'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbxa00bgxsv7jyaj6t21',
    'INV-1770079436805-8dml9',
    '2026-02-02 16:00:00.000',
    5,
    NULL,
    0,
    '2026-02-27 05:13:22.268',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.649'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbxn00bixsv7o9032e3n',
    'INV-1770079309318-iw4ku',
    '2026-02-02 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.281',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.664'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbxz00bkxsv72509jvqp',
    'INV-1770079270274-09lnw',
    '2026-02-02 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.294',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.679'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbyc00bmxsv7uukvi6n6',
    'INV-1770029978167-7luwh',
    '2026-02-01 16:00:00.000',
    170,
    NULL,
    0,
    '2026-02-27 05:13:22.306',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.693'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbyw00bpxsv7c9k7t2fl',
    'INV-1770029575442-5e7mw',
    '2026-02-01 16:00:00.000',
    57.5,
    NULL,
    0,
    '2026-02-27 05:13:22.326',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.711'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsbzj00bsxsv7ay58a196',
    'INV-1770009007439-dwh2l',
    '2026-02-01 16:00:00.000',
    91000,
    NULL,
    0,
    '2026-02-27 05:13:22.349',
    0,
    'CREDIT CARD',
    0,
    0,
    '2026-02-27 05:17:46.734'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc0500bwxsv73rjoy27j',
    'INV-1769589872907-ko4az',
    '2026-01-27 16:00:00.000',
    140.4,
    NULL,
    0,
    '2026-02-27 05:13:22.371',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.760'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc0k00byxsv794sgvaru',
    'INV-1769589260573-e17h2',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.387',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.776'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc0z00c0xsv7xuohznyz',
    'INV-1769588827503-5pgf9',
    '2026-01-27 16:00:00.000',
    150,
    NULL,
    0,
    '2026-02-27 05:13:22.401',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.789'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc1c00c2xsv72jjiwfk8',
    'INV-1769588808151-nw5hf',
    '2026-01-27 16:00:00.000',
    5.85,
    NULL,
    0,
    '2026-02-27 05:13:22.415',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.803'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc1p00c4xsv7zojzs4tp',
    'INV-1769588751307-ww1xd',
    '2026-01-27 16:00:00.000',
    150,
    NULL,
    0,
    '2026-02-27 05:13:22.428',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.816'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc2200c6xsv7lhvgo0r9',
    'INV-1769588475493-y1aj0',
    '2026-01-27 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:22.440',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.837'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc2g00c8xsv7mv337583',
    'INV-1769587953516-9uenv',
    '2026-01-27 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:22.455',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.851'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc2s00caxsv7ho92frv4',
    'INV-1769587746983-nwluq',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.465',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.863'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc3k00ccxsv7ulveybgm',
    'INV-1769587696024-r0dk7',
    '2026-01-27 16:00:00.000',
    130,
    NULL,
    0,
    '2026-02-27 05:13:22.491',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.877'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc4k00cfxsv7lmten3cr',
    'INV-1769587600703-4tm0e',
    '2026-01-27 16:00:00.000',
    250,
    NULL,
    0,
    '2026-02-27 05:13:22.531',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.897'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc5700cixsv7u5mee55y',
    'INV-1769579943686-zyl93',
    '2026-01-27 16:00:00.000',
    5.85,
    NULL,
    0,
    '2026-02-27 05:13:22.554',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.917'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc5k00ckxsv7pqphp1d4',
    'INV-1769579907788-c3ery',
    '2026-01-27 16:00:00.000',
    10,
    NULL,
    0,
    '2026-02-27 05:13:22.567',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.932'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc5w00cmxsv7vdh3rygu',
    'INV-1769579708400-ikmm4',
    '2026-01-27 16:00:00.000',
    600,
    NULL,
    0,
    '2026-02-27 05:13:22.580',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.947'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc6a00coxsv7oihs4gyp',
    'INV-1769577091395-91hnq',
    '2026-01-27 16:00:00.000',
    10,
    NULL,
    0,
    '2026-02-27 05:13:22.593',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.961'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc6n00cqxsv713ono8ep',
    'INV-1769576943974-woh5k',
    '2026-01-27 16:00:00.000',
    840,
    NULL,
    0,
    '2026-02-27 05:13:22.607',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.974'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc7400ctxsv7qzt7j1gl',
    'INV-1769575458367-cmdab',
    '2026-01-27 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:22.623',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:46.996'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc7i00cvxsv7wjlt3w1f',
    'INV-1769571879285-5urse',
    '2026-01-27 16:00:00.000',
    201080,
    NULL,
    0,
    '2026-02-27 05:13:22.637',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.009'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc9100d3xsv7q28l0n31',
    'INV-1769571801476-zec6v',
    '2026-01-27 16:00:00.000',
    400,
    NULL,
    0,
    '2026-02-27 05:13:22.691',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.060'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsc9p00d7xsv7vlte8upo',
    'INV-1769571728843-0xhsn',
    '2026-01-27 16:00:00.000',
    632.5,
    NULL,
    0,
    '2026-02-27 05:13:22.717',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.086'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscae00dbxsv7bu4nwzav',
    'INV-1769571324429-3plec',
    '2026-01-27 16:00:00.000',
    270,
    NULL,
    0,
    '2026-02-27 05:13:22.741',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.115'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscb300dfxsv7ah24gn1z',
    'INV-1769570263504-nqmet',
    '2026-01-27 16:00:00.000',
    129240,
    NULL,
    0,
    '2026-02-27 05:13:22.767',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.143'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscby00dkxsv7gqnedjyr',
    'INV-1769570078024-ohfu2',
    '2026-01-27 16:00:00.000',
    20,
    NULL,
    0,
    '2026-02-27 05:13:22.797',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.178'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscca00dmxsv7im055dr2',
    'INV-1769570045487-rprws',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.810',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.196'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscco00doxsv779xdes3p',
    'INV-1769569587758-yhyuj',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.823',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.210'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscd700dqxsv7mww0byvv',
    'INV-1769569125184-jblwg',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.838',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.224'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscdi00dsxsv72kzfvwvn',
    'INV-1769568686347-5e3tf',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:22.852',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.239'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscdx00duxsv72042lmxg',
    'INV-1769568611227-y7ukq',
    '2026-01-27 16:00:00.000',
    60,
    NULL,
    0,
    '2026-02-27 05:13:22.868',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.257'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsce900dwxsv7fms9rja6',
    'INV-1769567434960-hqkt0',
    '2026-01-27 16:00:00.000',
    73170,
    NULL,
    0,
    '2026-02-27 05:13:22.879',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.276'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscf300dzxsv7hk2bk4rg',
    'INV-1769566747287-gt9zx',
    '2026-01-27 16:00:00.000',
    150,
    NULL,
    0,
    '2026-02-27 05:13:22.909',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.301'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscfo00e1xsv7nmy9qsky',
    'INV-1769565788293-we7tt',
    '2026-01-27 16:00:00.000',
    150,
    NULL,
    0,
    '2026-02-27 05:13:22.930',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.318'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscg900e3xsv7w176nu70',
    'INV-1769565577584-owk0x',
    '2026-01-27 16:00:00.000',
    71002.5,
    NULL,
    0,
    '2026-02-27 05:13:22.952',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.335'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsch800e6xsv7ae4zqdah',
    'INV-1769564434195-i1ww7',
    '2026-01-27 16:00:00.000',
    65.85,
    NULL,
    0,
    '2026-02-27 05:13:22.984',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.365'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsci400e9xsv7mnmoj1sj',
    'INV-1769564005952-kbkkn',
    '2026-01-27 16:00:00.000',
    60,
    NULL,
    0,
    '2026-02-27 05:13:23.018',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.403'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsciq00ebxsv7n4zrwfqs',
    'INV-1769563673005-hpze0',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:23.038',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.418'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscjl00edxsv7z3gmw3dx',
    'INV-1769563229484-6qr58',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:23.071',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.433'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsckc00efxsv7dwm19omn',
    'INV-1769561113625-er7dv',
    '2026-01-27 16:00:00.000',
    105,
    NULL,
    0,
    '2026-02-27 05:13:23.098',
    0,
    'E-WALLET',
    0,
    0,
    '2026-02-27 05:17:47.447'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsckr00ehxsv7m3sedv69',
    'INV-1769560703851-qs4es',
    '2026-01-27 16:00:00.000',
    157.5,
    NULL,
    0,
    '2026-02-27 05:13:23.114',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.461'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscle00ekxsv7p7hlunoa',
    'INV-1769560292388-20c3r',
    '2026-01-27 16:00:00.000',
    52.5,
    NULL,
    0,
    '2026-02-27 05:13:23.137',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.480'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsclq00emxsv7vvwhyms6',
    'INV-1769559873011-1pvjm',
    '2026-01-27 16:00:00.000',
    60,
    NULL,
    0,
    '2026-02-27 05:13:23.149',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.495'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscm200eoxsv7h5vx1vg0',
    'INV-1769559722751-i276h',
    '2026-01-27 16:00:00.000',
    112.5,
    NULL,
    0,
    '2026-02-27 05:13:23.160',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.513'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscmk00erxsv7ifjjns5u',
    'INV-1769169573456-eehk6',
    '2026-01-22 16:00:00.000',
    213150,
    NULL,
    0,
    '2026-02-27 05:13:23.179',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.532'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscn600euxsv7ff8n0jbd',
    'INV-1769042217795-41evf',
    '2026-01-21 16:00:00.000',
    140.4,
    NULL,
    0,
    '2026-02-27 05:13:23.198',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.554'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscnl00ewxsv75rkgf2ur',
    'INV-1768804504068-p3s0g',
    '2026-01-18 16:00:00.000',
    6590,
    NULL,
    0,
    '2026-02-27 05:13:23.215',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.569'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscny00eyxsv7ufc8srsc',
    'INV-1768803406580-t0ry7',
    '2026-01-18 16:00:00.000',
    130,
    NULL,
    0,
    '2026-02-27 05:13:23.228',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.584'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscof00f1xsv7al03sr6k',
    'INV-1768800711931-u14ef',
    '2026-01-18 16:00:00.000',
    70990,
    NULL,
    0,
    '2026-02-27 05:13:23.246',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.606'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscot00f3xsv7slj13gn7',
    'INV-1768800639007-r15od',
    '2026-01-18 16:00:00.000',
    5,
    NULL,
    0,
    '2026-02-27 05:13:23.260',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.622'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscp700f5xsv7ipnce8cr',
    'INV-1768798438730-vbwng',
    '2026-01-18 16:00:00.000',
    12.5,
    NULL,
    0,
    '2026-02-27 05:13:23.274',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.636'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscpk00f7xsv7r19oqqdm',
    'INV-1768790554510-rj1nl',
    '2026-01-18 16:00:00.000',
    146.25,
    NULL,
    0,
    '2026-02-27 05:13:23.288',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.649'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscqa00faxsv7xxzqwznm',
    'INV-1768789954875-h00ha',
    '2026-01-18 16:00:00.000',
    120,
    NULL,
    0,
    '2026-02-27 05:13:23.313',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.670'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscqo00fcxsv7qx3q4ypw',
    'INV-1768788522951-8l91j',
    '2026-01-18 16:00:00.000',
    59995,
    NULL,
    0,
    '2026-02-27 05:13:23.327',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.690'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscrd00ffxsv7oxcvbgtl',
    'INV-1768788277962-ygg6h',
    '2026-01-18 16:00:00.000',
    59990,
    NULL,
    0,
    '2026-02-27 05:13:23.352',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.716'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscru00fhxsv7tgrplikh',
    'INV-1768782963083-z827q',
    '2026-01-18 16:00:00.000',
    140.4,
    NULL,
    0,
    '2026-02-27 05:13:23.369',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.748'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscs900fjxsv7ngm959ju',
    'inv_1768632370238_na8sqv28j',
    '2026-01-16 16:00:00.000',
    6590,
    NULL,
    0,
    '2026-02-27 05:13:23.384',
    0,
    'Charge',
    0,
    0,
    '2026-02-27 05:17:47.775'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscso00flxsv7q8vpfrbm',
    'INV-1768287046853-jj6io',
    '2026-01-12 16:00:00.000',
    66590,
    NULL,
    0,
    '2026-02-27 05:13:23.398',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.802'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fsctb00fpxsv7rmf9ko74',
    'INV-1768282201945-v7z1h',
    '2026-01-12 16:00:00.000',
    129130,
    NULL,
    0,
    '2026-02-27 05:13:23.422',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.846'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscu200ftxsv7k5jny69a',
    'INV-1767943536120-qol8j',
    '2026-01-08 16:00:00.000',
    139980,
    NULL,
    0,
    '2026-02-27 05:13:23.449',
    0,
    'CREDIT CARD',
    0,
    0,
    '2026-02-27 05:17:47.888'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscun00fwxsv7f311n7k5',
    'INV-1767941411197-tpqyi',
    '2026-01-08 16:00:00.000',
    133480,
    NULL,
    0,
    '2026-02-27 05:13:23.470',
    0,
    'CASH',
    0,
    0,
    '2026-02-27 05:17:47.919'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscv700fzxsv7trhtjt45',
    'inv_1766991918676_hdq2zojih',
    '2025-12-28 16:00:00.000',
    600,
    NULL,
    0,
    '2026-02-27 05:13:23.491',
    0,
    'Charge',
    0,
    0,
    '2026-02-27 05:17:47.951'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscvk00g1xsv7jr61pjln',
    'inv_1766991015035_nv7e010f2',
    '2025-12-28 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:23.503',
    0,
    'Charge',
    0,
    0,
    '2026-02-27 05:17:47.963'
  );
INSERT INTO
  `pos_sales` (
    `id`,
    `receiptId`,
    `date`,
    `amount`,
    `cashier`,
    `syncedToLedger`,
    `createdAt`,
    `discount`,
    `paymentMethod`,
    `subtotal`,
    `tax`,
    `updatedAt`
  )
VALUES
  (
    'cmm4fscvx00g3xsv7esqwfw1k',
    'inv_1766989513009_lgrejlzee',
    '2025-12-28 16:00:00.000',
    50,
    NULL,
    0,
    '2026-02-27 05:13:23.516',
    0,
    'Charge',
    0,
    0,
    '2026-02-27 05:17:47.977'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: pos_sync_log
# ------------------------------------------------------------

INSERT INTO
  `pos_sync_log` (
    `id`,
    `endpoint`,
    `lastSyncedAt`,
    `status`,
    `recordsAdded`,
    `errorMessage`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm4bh49e0000xsv7s9977968',
    'sales',
    '2026-02-27 05:17:47.989',
    'SUCCESS',
    250,
    'fetch failed',
    '2026-02-27 03:12:40.651',
    '2026-02-27 05:17:47.992'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product_history
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_order
# ------------------------------------------------------------

INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `depositAccount`
  )
VALUES
  (
    'cml6han4z002wpwv7jptm0cqf',
    'cmkxt7ev30000pov7aicz502z',
    '2026-02-03 10:51:26.207',
    NULL,
    NULL,
    'default',
    NULL,
    NULL,
    95008.56000000001,
    0,
    95008.56000000001,
    'Void',
    '2026-02-03 10:51:26.242',
    '2026-02-04 06:20:45.562',
    NULL
  );
INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `depositAccount`
  )
VALUES
  (
    'cmlewujkb000ezcv7d2u5rgte',
    'cmkxt7ev30000pov7aicz502z',
    '2026-02-09 08:21:12.942',
    '',
    '',
    'default',
    '',
    '',
    4.17,
    0,
    4.17,
    'Approved',
    '2026-02-09 08:28:58.377',
    '2026-02-23 05:56:22.248',
    NULL
  );
INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `depositAccount`
  )
VALUES
  (
    'cmlyr83sp0001w8v7fgfmh9hk',
    'cmlyr79ol0000w8v7joqm7wc5',
    '2026-02-23 05:44:43.811',
    'Tagum City',
    'maragusan',
    'default',
    '',
    '',
    125.01,
    0,
    125.01,
    'Paid',
    '2026-02-23 05:46:56.953',
    '2026-02-23 08:14:30.689',
    'cmlypi1ex00016ov7hzm35fr0'
  );
INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `depositAccount`
  )
VALUES
  (
    'cmlywvxzf0002scv720rjus4q',
    'cmlyr79ol0000w8v7joqm7wc5',
    '2026-02-23 08:24:53.130',
    'Tagum City',
    'maragusan',
    'default',
    '',
    '',
    8.33,
    0,
    8.33,
    'Paid',
    '2026-02-23 08:25:27.243',
    '2026-02-23 08:31:57.196',
    'cmlypi1ex00016ov7hzm35fr0'
  );
INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `depositAccount`
  )
VALUES
  (
    'cmlyzw8c60002bov706ozsui0',
    'cmlyzj9mf0000bov7rkx7awc1',
    '2026-02-23 09:49:22.331',
    'Davao City',
    '',
    'default',
    '',
    '',
    41.67,
    0,
    41.67,
    'Open',
    '2026-02-23 09:49:39.510',
    '2026-02-23 09:49:39.510',
    'cmlyzl5la0001bov74r2ziy7t'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_order_item
# ------------------------------------------------------------

INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51002xpwv7pipk460x',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Aloe Vera 25ml',
    40,
    33.25,
    0,
    798,
    'Baby Oil',
    NULL,
    '48038065',
    'pieces',
    24,
    24,
    40,
    NULL,
    NULL,
    33.25,
    NULL,
    NULL,
    NULL,
    798,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51002ypwv7ju16zco2',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Aloe Vera 50ml',
    0,
    59.75,
    0,
    0,
    'Baby Oil',
    NULL,
    '4801010504207',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    59.75,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51002zpwv7mkmza89u',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Bedtime 50ml',
    36,
    54.5,
    0,
    1962,
    'Baby Oil',
    NULL,
    '9556006060636',
    'pieces',
    1,
    24,
    36,
    1,
    NULL,
    54.5,
    NULL,
    NULL,
    NULL,
    1962,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510030pwv70i3b1qsl',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Lite 125ml',
    12,
    116.05,
    0,
    1392.6,
    'Baby Oil',
    NULL,
    '4801010503323',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    116.05,
    NULL,
    NULL,
    NULL,
    1392.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510031pwv7ww5ckjd3',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Lite 25ml',
    36,
    33.25,
    0,
    1197,
    'Baby Oil',
    NULL,
    '48036016',
    'pieces',
    1,
    24,
    36,
    1,
    NULL,
    33.25,
    NULL,
    NULL,
    NULL,
    1197,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510032pwv7h9406o44',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Lite 50ml',
    12,
    55.8,
    0,
    669.6,
    'Baby Oil',
    NULL,
    '4801010503224',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    55.8,
    NULL,
    NULL,
    NULL,
    669.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510033pwv7flu8ydcc',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Regular 125ml',
    6,
    97.55,
    0,
    585.3,
    'Baby Oil',
    NULL,
    '4801010501312',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    97.55,
    NULL,
    NULL,
    NULL,
    585.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510034pwv763euqzlf',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Regular 25ml',
    48,
    23.15,
    0,
    1111.2,
    'Baby Oil',
    NULL,
    '48035996',
    'pieces',
    1,
    48,
    48,
    1,
    NULL,
    23.15,
    NULL,
    NULL,
    NULL,
    1111.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510035pwv7b12wbbbv',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Regular 50ml',
    24,
    44.45,
    0,
    1066.8,
    'Baby Oil',
    NULL,
    '4801010501213',
    'pieces',
    1,
    48,
    24,
    1,
    NULL,
    44.45,
    NULL,
    NULL,
    NULL,
    1066.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510036pwv7g7flytac',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnson Baby Milk Bath 50g',
    1,
    19.65,
    0,
    943.2,
    'Bath Soap',
    NULL,
    '4801010562313',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    19.65,
    NULL,
    NULL,
    NULL,
    943.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510037pwv7uq0dvte0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Bath Milk+Rice 100ml',
    24,
    60.85,
    0,
    1460.4,
    'Bath Soap',
    NULL,
    '9556006060308',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    60.85,
    NULL,
    NULL,
    NULL,
    1460.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510038pwv7st556k9v',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Bath Regular 100ml',
    6,
    49.85,
    0,
    299.1,
    'Bath Soap',
    NULL,
    '9556006060193',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    49.85,
    NULL,
    NULL,
    NULL,
    299.1,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510039pwv75e2kla3h',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Bath Top to Toe Wash 100ml',
    12,
    85.15,
    0,
    1021.8,
    'Bath Soap',
    NULL,
    '9556006012086',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    85.15,
    NULL,
    NULL,
    NULL,
    1021.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003apwv7ziqnztzn',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Soap Blossoms 50g',
    2,
    23.2,
    0,
    4454.4,
    'Bath Soap',
    NULL,
    '4801010561514',
    'Cases',
    1,
    60,
    2,
    96,
    NULL,
    23.2,
    NULL,
    NULL,
    NULL,
    4454.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003bpwv7xn4srnvb',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Soap Milk 100g',
    0,
    34.3,
    0,
    0,
    'Bath Soap',
    NULL,
    '4801010562108',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    34.3,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003cpwv7lfh8xb64',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Soap Regular 75g',
    24,
    32.2,
    0,
    772.8,
    'Bath Soap',
    NULL,
    '4801010560456',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    32.2,
    NULL,
    NULL,
    NULL,
    772.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003dpwv7l3wr0krv',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Blossoms Baby Soap 75g',
    2,
    37.3,
    0,
    7161.6,
    'Bath Soap',
    NULL,
    '4801010561521',
    'Cases',
    1,
    6,
    2,
    96,
    NULL,
    37.3,
    NULL,
    NULL,
    NULL,
    7161.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003epwv729946w1z',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Milk Baby Soap 75g',
    48,
    37.3,
    0,
    1790.4,
    'Bath Soap',
    NULL,
    '4801010562320',
    'pieces',
    1,
    40,
    48,
    1,
    NULL,
    37.3,
    NULL,
    NULL,
    NULL,
    1790.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003fpwv7xzmwr8ny',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Jonhsons B Soap Blossoms 100g',
    0,
    34.3,
    0,
    0,
    'Bath Soap',
    NULL,
    '4801010561309',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    34.3,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003gpwv7ngxwludx',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 100g',
    0,
    78.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010852',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    78.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003hpwv7ou1p672v',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 200g',
    0,
    146.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010869',
    NULL,
    1,
    6,
    NULL,
    NULL,
    NULL,
    146.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003ipwv7j6hud092',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 25g',
    0,
    28.75,
    0,
    0,
    'Body Powder',
    NULL,
    '4801010120117',
    NULL,
    288,
    288,
    NULL,
    NULL,
    NULL,
    28.75,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003jpwv7fqof95w9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 50g',
    0,
    40.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010890',
    NULL,
    72,
    72,
    NULL,
    NULL,
    NULL,
    40.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003kpwv7bbmekuwu',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Blossoms 100g',
    6,
    67.75,
    0,
    406.5,
    'Body Powder',
    NULL,
    '4801010105206',
    'pieces',
    12,
    12,
    6,
    1,
    NULL,
    67.75,
    NULL,
    NULL,
    NULL,
    406.5,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003lpwv7f85pz4op',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Blossoms 25g',
    96,
    21.25,
    0,
    2040,
    'Body Powder',
    NULL,
    '48040693',
    'pieces',
    288,
    288,
    96,
    1,
    NULL,
    21.25,
    NULL,
    NULL,
    NULL,
    2040,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003mpwv7kmk7oceo',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Blossoms 50g',
    0,
    35.5,
    0,
    0,
    'Body Powder',
    NULL,
    '4801010105107',
    NULL,
    1,
    144,
    NULL,
    NULL,
    NULL,
    35.5,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003npwv7ilsqj8bd',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 100g',
    24,
    58.75,
    0,
    1410,
    'Body Powder',
    NULL,
    '8850007011132',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    58.75,
    NULL,
    NULL,
    NULL,
    1410,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003opwv7m7g03601',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 200g',
    0,
    113.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007011149',
    NULL,
    1,
    12,
    NULL,
    NULL,
    NULL,
    113.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003ppwv7h1e4fqd7',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 25g',
    96,
    20,
    0,
    1920,
    'Body Powder',
    NULL,
    '48032742',
    'pieces',
    1,
    288,
    96,
    1,
    NULL,
    20,
    NULL,
    NULL,
    NULL,
    1920,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003qpwv7j90430m5',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 50g',
    24,
    30.5,
    0,
    732,
    'Body Powder',
    NULL,
    '48033459',
    'pieces',
    1,
    144,
    24,
    1,
    NULL,
    30.5,
    NULL,
    NULL,
    NULL,
    732,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003rpwv7nhag5q0a',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Cooling 50g',
    96,
    24.4,
    0,
    2342.4,
    'Body Powder',
    NULL,
    '4801010107101',
    'pieces',
    1,
    24,
    96,
    1,
    NULL,
    24.4,
    NULL,
    NULL,
    NULL,
    2342.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003spwv7jasfp4cn',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 100g',
    18,
    57.85,
    0,
    1041.3,
    'Body Powder',
    NULL,
    '4801010104209',
    'pieces',
    1,
    24,
    18,
    1,
    NULL,
    57.85,
    NULL,
    NULL,
    NULL,
    1041.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003tpwv7r578y4xl',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 200g',
    18,
    108.85,
    0,
    1959.3,
    'Body Powder',
    NULL,
    '8850007011743',
    'pieces',
    1,
    6,
    18,
    1,
    NULL,
    108.85,
    NULL,
    NULL,
    NULL,
    1959.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003upwv7931xb3u0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 25g',
    2,
    18.8,
    0,
    10828.8,
    'Body Powder',
    NULL,
    '4801010104001',
    'Cases',
    1,
    288,
    2,
    288,
    NULL,
    18.8,
    NULL,
    NULL,
    NULL,
    10828.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003vpwv78l5b4pma',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 50g',
    96,
    29.45,
    0,
    2827.2,
    'Body Powder',
    NULL,
    '4801010104100',
    'pieces',
    1,
    96,
    96,
    1,
    NULL,
    29.45,
    NULL,
    NULL,
    NULL,
    2827.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003wpwv7x4sztdic',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Pure Cornstarch 200g',
    18,
    90.85,
    0,
    1635.3,
    'Body Powder',
    NULL,
    '4801010110309',
    'pieces',
    1,
    12,
    18,
    1,
    NULL,
    90.85,
    NULL,
    NULL,
    NULL,
    1635.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003xpwv70fz0vf3w',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Happy Berries 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010127321',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52003ypwv7wt17khk9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Heaven Scent 25ml',
    24,
    22.9,
    0,
    549.6,
    'Cologne',
    NULL,
    '48035989',
    'pieces',
    1,
    12,
    24,
    1,
    NULL,
    22.9,
    NULL,
    NULL,
    NULL,
    549.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52003zpwv7fdieycfu',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Heaven Scent 50ml',
    48,
    32.95,
    0,
    1581.6,
    'Cologne',
    NULL,
    '4801010127215',
    'pieces',
    1,
    24,
    48,
    1,
    NULL,
    32.95,
    NULL,
    NULL,
    NULL,
    1581.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520040pwv7dl4lhbqt',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Hppy Berries 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010127222',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520041pwv78c1k97r9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Morning Dew 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010126317',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520042pwv7r92ob38y',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Morning Dew 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48032803',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520043pwv7lseq140l',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Morning Dew 50ml',
    12,
    43.95,
    0,
    527.4,
    'Cologne',
    NULL,
    '4801010126218',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    527.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520044pwv7fhooxovk',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Powder Mist 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010125303',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520045pwv7natioq28',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Powder Mist 25ml',
    6,
    26.15,
    0,
    156.9,
    'Cologne',
    NULL,
    '48039086',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    156.9,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520046pwv7mffhr4ei',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Powder Mist 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010125204',
    'pieces',
    1,
    18,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520047pwv7dlsn4iet',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Regular 25ml',
    12,
    27.05,
    0,
    324.6,
    'Cologne',
    NULL,
    '48032766',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    27.05,
    NULL,
    NULL,
    NULL,
    324.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520048pwv7qd26wi07',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Regular 50ml',
    12,
    39.2,
    0,
    470.4,
    'Cologne',
    NULL,
    '4801010121213',
    'pieces',
    1,
    6,
    12,
    1,
    NULL,
    39.2,
    NULL,
    NULL,
    NULL,
    470.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520049pwv7yozhuoy3',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Slide 125ml',
    12,
    89.2,
    0,
    1070.4,
    'Cologne',
    NULL,
    '4801010120223',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    1070.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004apwv7exjvtcz8',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Slide 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48040525',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004bpwv7nnf3wx5o',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Slide 50ml',
    12,
    43.95,
    0,
    527.4,
    'Cologne',
    NULL,
    '4801010120124',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    527.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004cpwv7vsnox2jl',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Summer Swing 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010122326',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004dpwv73jhu1iyy',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Summer Swing 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48039116',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004epwv7uskhefg1',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Summer Swing 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010122227',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004fpwv790zaiqh0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Milk+Rice 100ml',
    12,
    98.45,
    0,
    1181.4,
    'Lotion',
    NULL,
    '9556006060346',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    98.45,
    NULL,
    NULL,
    NULL,
    1181.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004gpwv76aeu0n46',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Milk+Rice 50ml',
    6,
    53.05,
    0,
    318.3,
    'Lotion',
    NULL,
    '4801010515104',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    53.05,
    NULL,
    NULL,
    NULL,
    318.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004hpwv7nb47jyex',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Pink 50ml',
    6,
    46.9,
    0,
    281.4,
    'Lotion',
    NULL,
    '8850007031109',
    'pieces',
    1,
    1,
    6,
    1,
    NULL,
    46.9,
    NULL,
    NULL,
    NULL,
    281.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004ipwv727tpzc12',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Regular 100ml',
    6,
    87.75,
    0,
    526.5,
    'Lotion',
    NULL,
    '8850007030744',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    87.75,
    NULL,
    NULL,
    NULL,
    526.5,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004jpwv73b98u7xq',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Breathable 15s',
    0,
    25.8,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '4801010369127',
    NULL,
    1,
    12,
    NULL,
    NULL,
    NULL,
    25.8,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004kpwv7ua3ioegf',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Breathable 20s',
    1,
    55.84,
    0,
    2010.24,
    'Sanitary Napkins',
    NULL,
    '8850007331261',
    'Cases',
    1,
    36,
    1,
    36,
    NULL,
    55.84,
    NULL,
    NULL,
    NULL,
    2010.24,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004lpwv7rlmo3ooo',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Breathable 8s',
    0,
    24.21,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '8850007331308',
    NULL,
    48,
    24,
    NULL,
    NULL,
    NULL,
    24.21,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004mpwv7cmrjr1w2',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Super Dry 15s',
    1,
    25.75,
    0,
    927,
    'Sanitary Napkins',
    NULL,
    '4801010361121',
    'Cases',
    1,
    36,
    1,
    36,
    NULL,
    25.75,
    NULL,
    NULL,
    NULL,
    927,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004npwv7u9ab20vx',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Super Dry 8s',
    1,
    24.21,
    0,
    1162.08,
    'Sanitary Napkins',
    NULL,
    '8850007331384',
    'Cases',
    1,
    48,
    1,
    48,
    NULL,
    24.21,
    NULL,
    NULL,
    NULL,
    1162.08,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004opwv7bimvs1ok',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Reg. Soft non-wing 12s',
    1,
    55.5,
    0,
    2664,
    'Sanitary Napkins',
    NULL,
    '8850007371441',
    'Cases',
    1,
    24,
    1,
    48,
    NULL,
    55.5,
    NULL,
    NULL,
    NULL,
    2664,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004ppwv7in6i4fji',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft All Night w/ wings 4s',
    1,
    52.96,
    0,
    2542.08,
    'Sanitary Napkins',
    NULL,
    '4801010327103',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    52.96,
    NULL,
    NULL,
    NULL,
    2542.08,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004qpwv706dtiwl0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Long w/ wings 8s',
    1,
    44.85,
    0,
    2152.8,
    'Sanitary Napkins',
    NULL,
    '8850007373261',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    44.85,
    NULL,
    NULL,
    NULL,
    2152.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004rpwv7t0e3jsj7',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. non-wing 8s',
    1,
    41.26,
    0,
    1980.48,
    'Sanitary Napkins',
    NULL,
    '8850007371397',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    41.26,
    NULL,
    NULL,
    NULL,
    1980.48,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004spwv7j5hb7jb5',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 16s',
    1,
    74.6,
    0,
    3580.8,
    'Sanitary Napkins',
    NULL,
    '8850007372882',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    74.6,
    NULL,
    NULL,
    NULL,
    3580.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004tpwv77n7n2lo5',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 1pd',
    0,
    5,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '8850007374053',
    NULL,
    1,
    120,
    NULL,
    NULL,
    NULL,
    5,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004upwv7u2finl7f',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 8s',
    1,
    41.26,
    0,
    1980.48,
    'Sanitary Napkins',
    NULL,
    '8850007371403',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    41.26,
    NULL,
    NULL,
    NULL,
    1980.48,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004vpwv7zgeogeam',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Dry Max Maxi w/o Wings 8s',
    1,
    44.55,
    0,
    2138.4,
    'Sanitary Napkins',
    NULL,
    '8850007372561',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    44.55,
    NULL,
    NULL,
    NULL,
    2138.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004wpwv7d1c90u44',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess DryMax Maxi Wings 8s',
    1,
    45.9,
    0,
    2203.2,
    'Sanitary Napkins',
    NULL,
    '8850007371434',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    45.9,
    NULL,
    NULL,
    NULL,
    2203.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004xpwv7uqeztc0o',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Shampoo Regular 100ml',
    24,
    97.25,
    0,
    2334,
    'Shampoo',
    NULL,
    '9556006014547',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    97.25,
    NULL,
    NULL,
    NULL,
    2334,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004ypwv7vngy3od9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Shampoo Shiny Drops 100ml',
    24,
    89.95,
    0,
    2158.8,
    'Shampoo',
    NULL,
    '4801010524304',
    'pieces',
    1,
    48,
    24,
    1,
    NULL,
    89.95,
    NULL,
    NULL,
    NULL,
    2158.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004zpwv7362ew3ib',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Shampoo w/ Honey 100ml',
    24,
    81.5,
    0,
    1956,
    'Shampoo',
    NULL,
    '9556006014585',
    'pieces',
    1,
    36,
    24,
    1,
    NULL,
    81.5,
    NULL,
    NULL,
    NULL,
    1956,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520050pwv7wum4hp74',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Baby Wipes 20s',
    0,
    50.6,
    0,
    0,
    'Wipe Tissue',
    NULL,
    '4710032504303',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    50.6,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlewujkf000fzcv758sz8c0w',
    'cmlewujkb000ezcv7d2u5rgte',
    NULL,
    'SKYFLAKES',
    1,
    4.17,
    0,
    4.17,
    NULL,
    NULL,
    '387052121177',
    'pc',
    1,
    NULL,
    1,
    NULL,
    4.17,
    4.17,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-09 08:28:58.377',
    '2026-02-09 08:28:58.377'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyr83sr0002w8v7wlm4j17h',
    'cmlyr83sp0001w8v7fgfmh9hk',
    NULL,
    'CHOCOMUCHO25G',
    1,
    41.67,
    0,
    41.67,
    NULL,
    NULL,
    '719612990951',
    'pc',
    1,
    NULL,
    1,
    NULL,
    41.67,
    41.67,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-23 05:46:56.953',
    '2026-02-23 05:46:56.953'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyr83sr0003w8v7vmx0or0w',
    'cmlyr83sp0001w8v7fgfmh9hk',
    NULL,
    'CHOCOMUCHO25G',
    1,
    41.67,
    0,
    41.67,
    NULL,
    NULL,
    '719612990951',
    'pc',
    1,
    NULL,
    1,
    NULL,
    41.67,
    41.67,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-23 05:46:56.953',
    '2026-02-23 05:46:56.953'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyr83sr0004w8v7utae15mg',
    'cmlyr83sp0001w8v7fgfmh9hk',
    NULL,
    'CHOCOMUCHO25G',
    1,
    41.67,
    0,
    41.67,
    NULL,
    NULL,
    '719612990951',
    'pc',
    1,
    NULL,
    1,
    NULL,
    41.67,
    41.67,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-23 05:46:56.953',
    '2026-02-23 05:46:56.953'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlywvxzh0003scv757culde3',
    'cmlywvxzf0002scv720rjus4q',
    NULL,
    'DOWNY 12G',
    1,
    8.33,
    0,
    8.33,
    NULL,
    NULL,
    '281226120524',
    'pc',
    1,
    NULL,
    1,
    NULL,
    8.33,
    8.33,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-23 08:25:27.243',
    '2026-02-23 08:25:27.243'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlyzw8c90003bov7t7waln81',
    'cmlyzw8c60002bov706ozsui0',
    NULL,
    'CHOCOMUCHO25G',
    1,
    41.67,
    0,
    41.67,
    NULL,
    NULL,
    '719612990951',
    'pc',
    1,
    NULL,
    1,
    NULL,
    41.67,
    41.67,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-23 09:49:39.510',
    '2026-02-23 09:49:39.510'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

INSERT INTO
  `reminder` (
    `id`,
    `title`,
    `memo`,
    `date`,
    `endDate`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `isRead`
  )
VALUES
  (
    'cml630dfu0000iwv7ccb0u9nx',
    'event ni',
    'optional ni',
    '2026-02-03 01:00:51.187',
    NULL,
    1,
    '2026-02-03 04:11:32.488',
    '2026-02-03 04:11:32.488',
    0
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: request
# ------------------------------------------------------------

INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `formName`,
    `depositAccount`
  )
VALUES
  (
    '934294aa-f422-45af-9e87-5ffb7055b005',
    'REQ-00002',
    'Rex',
    'CCTV Installer',
    '123',
    'Software Dept',
    NULL,
    'Damage',
    'Charles',
    0,
    'Ver Fier 2',
    'Rex Domingo',
    'Rex Domingo',
    '2026-02-03 10:17:06.078',
    'To Verify',
    '2026-02-03 10:17:06.078',
    '2026-02-03 10:17:06.078',
    'ACCOUNT DEDUCTION REQUEST FORM',
    NULL
  );
INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `formName`,
    `depositAccount`
  )
VALUES
  (
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    'REQ-00003',
    'YOng',
    'Gen Mngr',
    '12335',
    'ljma',
    NULL,
    'Damage Computer',
    'Jason',
    0,
    'Ver Fier',
    'Rex Domingo',
    'Rex Domingo',
    '2026-02-03 10:46:29.899',
    'To Process',
    '2026-02-03 10:46:29.899',
    '2026-02-26 02:40:51.870',
    'ACCOUNT DEDUCTION REQUEST FORM',
    NULL
  );
INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `formName`,
    `depositAccount`
  )
VALUES
  (
    'ec05873d-da80-400a-9e6e-451982aaf64d',
    'REQ-00001',
    'Rex Domingo',
    NULL,
    NULL,
    NULL,
    NULL,
    'Employee Salary Cash Advance',
    NULL,
    15000,
    NULL,
    'Son Jha',
    NULL,
    '2026-02-03 08:47:08.172',
    'To Process',
    '2026-02-03 08:47:08.172',
    '2026-02-03 09:27:07.837',
    'REQUEST AND AUTHORIZATION OF CASH ADVANCES',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: request_item
# ------------------------------------------------------------

INSERT INTO
  `request_item` (
    `id`,
    `requestId`,
    `productId`,
    `description`,
    `quantity`,
    `unit`,
    `unitPrice`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '02559f1e-a48c-404c-8928-c9045a285a56',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    NULL,
    'CCTV installer',
    1,
    NULL,
    0,
    0,
    '2026-02-03 10:17:06.078',
    '2026-02-03 10:17:06.078'
  );
INSERT INTO
  `request_item` (
    `id`,
    `requestId`,
    `productId`,
    `description`,
    `quantity`,
    `unit`,
    `unitPrice`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'a7878542-1963-4fff-946e-1ef0a981174c',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    NULL,
    'Keyboard',
    1,
    NULL,
    449.97,
    449.97,
    '2026-02-03 10:46:29.899',
    '2026-02-03 10:46:29.899'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

INSERT INTO
  `supplier` (
    `id`,
    `name`,
    `contactPerson`,
    `email`,
    `phone`,
    `address`,
    `paymentTerms`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `additionalInfo`,
    `contactFirstName`,
    `fax`,
    `isTaxExempt`,
    `paymentTermsValue`,
    `phoneAlternative`,
    `vatInfo`
  )
VALUES
  (
    'cmkxt7ev30000pov7aicz502z',
    'Davao Reach Global Dist.Corp-Johnson',
    NULL,
    NULL,
    NULL,
    NULL,
    'COD',
    1,
    '2026-01-28 09:14:55.354',
    '2026-02-10 02:26:14.179',
    'Markup: 0%',
    NULL,
    NULL,
    0,
    '30',
    '09357117604',
    NULL
  );
INSERT INTO
  `supplier` (
    `id`,
    `name`,
    `contactPerson`,
    `email`,
    `phone`,
    `address`,
    `paymentTerms`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `additionalInfo`,
    `contactFirstName`,
    `fax`,
    `isTaxExempt`,
    `paymentTermsValue`,
    `phoneAlternative`,
    `vatInfo`
  )
VALUES
  (
    'cmlyr79ol0000w8v7joqm7wc5',
    'Bhagoh IT Firm',
    'Beulah',
    'rextechpos@gmail.com',
    '09357117604',
    'Tagum City',
    'Pay in Days',
    1,
    '2026-02-23 05:46:17.923',
    '2026-02-23 05:46:17.923',
    'Markup: 0%',
    NULL,
    NULL,
    0,
    '30',
    '09357117604',
    '123456845894'
  );
INSERT INTO
  `supplier` (
    `id`,
    `name`,
    `contactPerson`,
    `email`,
    `phone`,
    `address`,
    `paymentTerms`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `additionalInfo`,
    `contactFirstName`,
    `fax`,
    `isTaxExempt`,
    `paymentTermsValue`,
    `phoneAlternative`,
    `vatInfo`
  )
VALUES
  (
    'cmlyzj9mf0000bov7rkx7awc1',
    'TradeMark Corp',
    'TradeMark Corp',
    'trademarkcorp@gmail.com',
    '09357117603',
    'Davao City',
    'COD',
    1,
    '2026-02-23 09:39:34.645',
    '2026-02-23 09:39:34.645',
    'Markup: 0%',
    NULL,
    NULL,
    0,
    '30',
    NULL,
    '434356343623'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: transactions
# ------------------------------------------------------------

INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mw40000scv7u6twlaz0',
    NULL,
    NULL,
    'cml6han4z002wpwv7jptm0cqf',
    '1310',
    '1310',
    '2026-02-03 10:51:26.207',
    NULL,
    'Historical PO Sync - cml6han4z002wpwv7jptm0cqf',
    95008.56000000001,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.146',
    '2026-02-24 08:47:06.146'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mwe0001scv7k26eddh1',
    NULL,
    NULL,
    'cml6han4z002wpwv7jptm0cqf',
    '2000',
    '2000',
    '2026-02-03 10:51:26.207',
    NULL,
    'Historical PO Sync - cml6han4z002wpwv7jptm0cqf',
    0,
    95008.56000000001,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.158',
    '2026-02-24 08:47:06.158'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mwl0002scv7t04tpady',
    NULL,
    NULL,
    'cmlewujkb000ezcv7d2u5rgte',
    '1310',
    '1310',
    '2026-02-09 08:21:12.942',
    NULL,
    'Historical PO Sync - cmlewujkb000ezcv7d2u5rgte',
    4.17,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.165',
    '2026-02-24 08:47:06.165'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mwp0003scv768skxnbj',
    NULL,
    NULL,
    'cmlewujkb000ezcv7d2u5rgte',
    '2000',
    '2000',
    '2026-02-09 08:21:12.942',
    NULL,
    'Historical PO Sync - cmlewujkb000ezcv7d2u5rgte',
    0,
    4.17,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.169',
    '2026-02-24 08:47:06.169'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mwz0004scv73q8k5qd6',
    NULL,
    NULL,
    'cmlyr83sp0001w8v7fgfmh9hk',
    '1310',
    '1310',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical PO Sync - cmlyr83sp0001w8v7fgfmh9hk',
    125.01,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.178',
    '2026-02-24 08:47:06.178'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mx30005scv75mjupalr',
    NULL,
    NULL,
    'cmlyr83sp0001w8v7fgfmh9hk',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical PO Sync - cmlyr83sp0001w8v7fgfmh9hk',
    0,
    125.01,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.183',
    '2026-02-24 08:47:06.183'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mxa0006scv7ztmve0tk',
    NULL,
    NULL,
    'cmlywvxzf0002scv720rjus4q',
    '1310',
    '1310',
    '2026-02-23 08:24:53.130',
    NULL,
    'Historical PO Sync - cmlywvxzf0002scv720rjus4q',
    8.33,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.190',
    '2026-02-24 08:47:06.190'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mxd0007scv79tsrs21e',
    NULL,
    NULL,
    'cmlywvxzf0002scv720rjus4q',
    '2000',
    '2000',
    '2026-02-23 08:24:53.130',
    NULL,
    'Historical PO Sync - cmlywvxzf0002scv720rjus4q',
    0,
    8.33,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.193',
    '2026-02-24 08:47:06.193'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mxj0008scv7xwfrs3z0',
    NULL,
    NULL,
    'cmlyzw8c60002bov706ozsui0',
    '1310',
    '1310',
    '2026-02-23 09:49:22.331',
    NULL,
    'Historical PO Sync - cmlyzw8c60002bov706ozsui0',
    41.67,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.199',
    '2026-02-24 08:47:06.199'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mxn0009scv77yt527r6',
    NULL,
    NULL,
    'cmlyzw8c60002bov706ozsui0',
    '2001',
    '2001',
    '2026-02-23 09:49:22.331',
    NULL,
    'Historical PO Sync - cmlyzw8c60002bov706ozsui0',
    0,
    41.67,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.203',
    '2026-02-24 08:47:06.203'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mxu000ascv7790s58f8',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical Payment Sync - Purchases',
    41.67,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.210',
    '2026-02-24 08:47:06.210'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mxz000bscv7rd7b9qwn',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical Payment Sync - Purchases',
    0,
    41.67,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.214',
    '2026-02-24 08:47:06.214'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3my4000cscv7ww7fh8ux',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical Payment Sync - Purchases',
    41.67,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.220',
    '2026-02-24 08:47:06.220'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3my8000dscv7xfquvfm9',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical Payment Sync - Purchases',
    0,
    41.67,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.223',
    '2026-02-24 08:47:06.223'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3myd000escv7j4jn7ne8',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical Payment Sync - Purchases',
    41.67,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.229',
    '2026-02-24 08:47:06.229'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3myg000fscv7ag0za6mm',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 05:44:43.811',
    NULL,
    'Historical Payment Sync - Purchases',
    0,
    41.67,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.232',
    '2026-02-24 08:47:06.232'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3myk000gscv7lt6zltbl',
    NULL,
    NULL,
    '1',
    '2000',
    '2000',
    '2026-02-23 07:59:33.305',
    NULL,
    'Historical Payment Sync - null',
    125.01,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.236',
    '2026-02-24 08:47:06.236'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3myo000hscv7x77cefdr',
    NULL,
    NULL,
    '1',
    '1080003',
    '1080003',
    '2026-02-23 07:59:33.305',
    NULL,
    'Historical Payment Sync - null',
    0,
    125.01,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.240',
    '2026-02-24 08:47:06.240'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3myu000iscv7r2tfh45c',
    NULL,
    NULL,
    '1',
    '2000',
    '2000',
    '2026-02-23 08:14:02.793',
    NULL,
    'Historical Payment Sync - null',
    125.01,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.246',
    '2026-02-24 08:47:06.246'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3myx000jscv79sv8lat3',
    NULL,
    NULL,
    '1',
    '1080003',
    '1080003',
    '2026-02-23 08:14:02.793',
    NULL,
    'Historical Payment Sync - null',
    0,
    125.01,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.249',
    '2026-02-24 08:47:06.249'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mz4000kscv7luf9mo1u',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-23 08:24:53.130',
    NULL,
    'Historical Payment Sync - Purchases',
    8.33,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.255',
    '2026-02-24 08:47:06.255'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mz7000lscv7lpm3ryh3',
    NULL,
    NULL,
    'PAY-SYNC',
    '5000',
    '5000',
    '2026-02-23 08:24:53.130',
    NULL,
    'Historical Payment Sync - Purchases',
    0,
    8.33,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.259',
    '2026-02-24 08:47:06.259'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mzh000mscv7ho3esaon',
    NULL,
    NULL,
    'PAY-SYNC',
    '2000',
    '2000',
    '2026-02-09 08:21:12.942',
    NULL,
    'Historical Payment Sync - Purchases',
    4.17,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.268',
    '2026-02-24 08:47:06.268'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmm0d3mzk000nscv7x0pyrr2g',
    NULL,
    NULL,
    'PAY-SYNC',
    '1000',
    '1000',
    '2026-02-09 08:21:12.942',
    NULL,
    'Historical Payment Sync - Purchases',
    0,
    4.17,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'System-Sync',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-24 08:47:06.272',
    '2026-02-24 08:47:06.272'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cmkz0donf0000mkv79698rf8x',
    'admin',
    'Rex',
    'Domingo',
    'manager@ljma.com',
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-01-29 05:23:31.464',
    '2026-01-29 05:23:31.464',
    '123700',
    NULL,
    NULL
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4xg7sz00006kv7is4z8efq',
    'Ver',
    'Ver',
    'Fier',
    NULL,
    'Purchaser',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Purchases\",\"Suppliers\",\"Product Brand\",\"Category\",\"Unit of Measure\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH FUND REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\"]',
    1,
    '2026-02-02 08:48:07.807',
    '2026-02-02 08:48:07.807',
    '123',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4yaaj900016kv7oliupi1e',
    'Carl',
    'Carl',
    'Tuganay',
    NULL,
    'Auditor',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Adjustment History\",\"Purchases\",\"Sales\",\"Customers\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\"]',
    1,
    '2026-02-02 09:11:31.027',
    '2026-02-02 09:11:31.027',
    '123700',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4ybmxx00026kv78dkx7znr',
    'Son',
    'Son',
    'Jha',
    NULL,
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-02-02 09:12:33.764',
    '2026-02-02 09:12:33.764',
    '123',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4yqb0j0000jgv7kq0t3fhs',
    'Ver2',
    'Ver',
    'Fier 2',
    NULL,
    'Purchaser',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Purchases\",\"Suppliers\",\"Product Brand\",\"Category\",\"Unit of Measure\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\"]',
    1,
    '2026-02-02 09:23:58.146',
    '2026-02-02 09:23:58.146',
    '123',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml7e8di30000psv75i84gs9i',
    'Flor',
    'Flor',
    'Rebutabo',
    NULL,
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-02-04 02:13:27.767',
    '2026-02-04 02:13:27.767',
    '123',
    NULL,
    'Approver'
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
