/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_job` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filePath` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileSize` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_schedule` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backupTime` datetime(3) NOT NULL,
  `frequency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: brand
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `brand` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brand_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `business_profile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `businessName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactTel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` longtext COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: category
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `category` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentCategoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `chart_of_account` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_no` int NOT NULL,
  `account_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` double DEFAULT '0',
  `account_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `last_updated_at` datetime(3) NOT NULL,
  `account_type_no` int NOT NULL DEFAULT '1',
  `account_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fs_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `chart_of_account_account_no_key` (`account_no`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `conversion_factor` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `factor` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactFirstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phonePrimary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `creditLimit` double DEFAULT '0',
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'days',
  `paymentTermsValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '30',
  `salesperson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerGroup` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `isEntitledToLoyaltyPoints` tinyint(1) NOT NULL DEFAULT '0',
  `pointSetting` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loyaltyCalculationMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'automatic',
  `loyaltyCardNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: inventory_transaction
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `inventory_transaction` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `referenceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_transaction_productId_fkey` (`productId`),
  CONSTRAINT `inventory_transaction_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: invoice
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerPONumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `terms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesperson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depositAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billingAddress` text COLLATE utf8mb4_unicode_ci,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci,
  `subtotal` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_invoiceNumber_key` (`invoiceNumber`),
  KEY `invoice_customerId_fkey` (`customerId`),
  CONSTRAINT `invoice_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: invoice_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `invoice_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL,
  `unitPrice` double NOT NULL,
  `total` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_item_invoiceId_fkey` (`invoiceId`),
  KEY `invoice_item_productId_fkey` (`productId`),
  CONSTRAINT `invoice_item_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_board
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_board` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_card
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_card` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `columnId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int NOT NULL,
  `transactionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kanban_card_transactionId_key` (`transactionId`),
  KEY `kanban_card_columnId_fkey` (`columnId`),
  CONSTRAINT `kanban_card_columnId_fkey` FOREIGN KEY (`columnId`) REFERENCES `kanban_column` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kanban_card_transactionId_fkey` FOREIGN KEY (`transactionId`) REFERENCES `inventory_transaction` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_column
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_column` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kanban_column_boardId_fkey` (`boardId`),
  CONSTRAINT `kanban_column_boardId_fkey` FOREIGN KEY (`boardId`) REFERENCES `kanban_board` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loyaltyCardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalPoints` double NOT NULL DEFAULT '0',
  `pointSettingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiryDate` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loyalty_point_customerId_fkey` (`customerId`),
  KEY `loyalty_point_pointSettingId_fkey` (`pointSettingId`),
  CONSTRAINT `loyalty_point_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loyalty_point_pointSettingId_fkey` FOREIGN KEY (`pointSettingId`) REFERENCES `loyalty_point_setting` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point_setting` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `equivalentPoint` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: notification
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `notification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalDescription` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brandId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplierId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitOfMeasureId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `costPrice` double NOT NULL DEFAULT '0',
  `stockQuantity` int NOT NULL DEFAULT '0',
  `minStockLevel` int NOT NULL DEFAULT '0',
  `maxStockLevel` int DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `salesOrder` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoCreateChildren` tinyint(1) NOT NULL DEFAULT '0',
  `initialStock` int NOT NULL DEFAULT '0',
  `reorderPoint` int NOT NULL DEFAULT '0',
  `incomeAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expenseAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product_history
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product_history` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `product_history_productId_fkey` (`productId`),
  CONSTRAINT `product_history_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_order
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplierId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `vendorAddress` text COLLATE utf8mb4_unicode_ci,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci,
  `taxType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `privateComments` text COLLATE utf8mb4_unicode_ci,
  `subtotal` double NOT NULL DEFAULT '0',
  `taxTotal` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_supplierId_fkey` (`supplierId`),
  CONSTRAINT `purchase_order_supplierId_fkey` FOREIGN KEY (`supplierId`) REFERENCES `supplier` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_order_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_order_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchaseOrderId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemDescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unitPrice` double NOT NULL,
  `tax` double DEFAULT NULL,
  `total` double NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyingUom` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyPerCase` int DEFAULT NULL,
  `offtake` int DEFAULT NULL,
  `orderQty` int DEFAULT NULL,
  `pieces` int DEFAULT NULL,
  `costPricePerCase` double DEFAULT NULL,
  `costPricePerPiece` double DEFAULT NULL,
  `discount1` double DEFAULT NULL,
  `discount2` double DEFAULT NULL,
  `discount3` double DEFAULT NULL,
  `netCostAmount` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_item_purchaseOrderId_fkey` (`purchaseOrderId`),
  KEY `purchase_order_item_productId_fkey` (`productId`),
  CONSTRAINT `purchase_order_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `purchase_order_item_purchaseOrderId_fkey` FOREIGN KEY (`purchaseOrderId`) REFERENCES `purchase_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `reminder` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: request
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `request` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requesterName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessUnit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chargeTo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `verifiedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approvedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'To Verify',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_requestNumber_key` (`requestNumber`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: request_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `request_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `request_item_requestId_fkey` (`requestId`),
  KEY `request_item_productId_fkey` (`productId`),
  CONSTRAINT `request_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `request_item_requestId_fkey` FOREIGN KEY (`requestId`) REFERENCES `request` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sales_user` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniqueId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_user_uniqueId_key` (`uniqueId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `supplier` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `additionalInfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactFirstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTermsValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatInfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: transactions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq` int DEFAULT NULL,
  `ledger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) DEFAULT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` double DEFAULT '0',
  `credit` double DEFAULT '0',
  `balance` double DEFAULT '0',
  `checkAccountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateMatured` datetime(3) DEFAULT NULL,
  `accountName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankBranch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCoincide` tinyint(1) DEFAULT NULL,
  `dailyClosing` int DEFAULT NULL,
  `approval` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToLedger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ssma_timestamp` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `unit_of_measure` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_of_measure_code_key` (`code`),
  UNIQUE KEY `unit_of_measure_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_permission` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission_username_key` (`username`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '633b1ed0-9123-45f3-8a99-cb29424ecb5a',
    '18c54816d039175d5e3d48066161c51c38a976842d9175f25937c8802546a0ef',
    '2026-01-28 08:38:13.232',
    '20260106073417_add_sales_user',
    NULL,
    NULL,
    '2026-01-28 08:38:13.223',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '7af9b917-d2f7-4d87-88f1-6f74adea2a04',
    '9410e048b5ad0d68daf03be7f6f92f917f5b4f68a2028416ee1b934a356aa1a4',
    '2026-01-28 08:40:19.428',
    '20260128084018_add_purchase_order_item_bulk_fields',
    NULL,
    NULL,
    '2026-01-28 08:40:18.912',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'cb4ee741-ddbc-4113-b18f-3db64818dfcd',
    '5ebf57ea84ec53062797d0268b6568a9273cd404b143252c3a6594ca1c6d3dcb',
    '2026-01-28 08:38:13.203',
    '20251229060212_rename_account_number_to_accnt_no',
    NULL,
    NULL,
    '2026-01-28 08:38:13.021',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'd0cbf72e-05ce-465f-ad14-b9b7abfa57c8',
    '9e72cfb7e330ed4870fc06c8650133eacdb1398b8000acf6345707e7f652fcec',
    '2026-01-28 08:38:13.244',
    '20260106091627_add_user_permission_model',
    NULL,
    NULL,
    '2026-01-28 08:38:13.233',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'dff21d21-1ff6-4487-bc4d-7438e13794d4',
    'ce22d20a307f7a87b58fca9e5a6ba88f0e225960099123b743bc796342a88579',
    '2026-01-28 08:38:13.222',
    '20251229064442_add_accnt_type_no',
    NULL,
    NULL,
    '2026-01-28 08:38:13.204',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'ea6b7370-3e4b-4c20-852c-3095eb57dbfb',
    'bfc13f666e5ac3c35fc5e780387c886bc11d20d159a9394284390fdf55779dd6',
    '2026-01-30 05:34:04.269',
    '20260130053404_add_account_fields',
    NULL,
    NULL,
    '2026-01-30 05:34:04.257',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'eb841330-8fdb-4cbe-b19a-f8d3c6c0245b',
    '74487f0a15539b305e49352d2ac9d99babea423b69a957868c25923c48e7a311',
    '2026-01-30 07:13:39.138',
    '20260130070956_sync_account_headers_rename_v2',
    NULL,
    NULL,
    '2026-01-30 07:13:39.074',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cml4qkcfm0000wov7st2xnzv9',
    'RUNNING',
    NULL,
    NULL,
    NULL,
    'admin',
    'Dumping database...',
    '2026-02-02 05:35:23.119',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: brand
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: category
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml0cg353000060v797rwczmo',
    1000,
    'Coins',
    1000,
    'Asset',
    'Yes',
    'No',
    'Asset',
    '2026-01-30 03:49:05.122',
    '2026-01-30 03:49:05.122',
    1,
    NULL,
    NULL,
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puct8005qg0v7aotm9koo',
    1080007,
    'Coins',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2024-08-20 16:00:00.000',
    '2026-02-02 05:15:10.553',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucth005rg0v75e2j77yf',
    1080006,
    'Contengency Funds',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2024-05-15 16:00:00.000',
    '2026-02-02 05:15:10.563',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puctn005sg0v754ypi53x',
    1080003,
    'General Funds',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2023-01-03 16:00:00.000',
    '2026-02-02 05:15:10.570',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puctv005tg0v70rloyoa2',
    1080001,
    'Postdated Checks',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2021-08-07 16:00:00.000',
    '2026-02-02 05:15:10.577',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucu1005ug0v7mzh3v2gm',
    1300004,
    'Cashier Expenses',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-09-27 16:00:00.000',
    '2026-02-02 05:15:10.584',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucu8005vg0v7yhvdxuij',
    1300001,
    'Gunayan, Cherica',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2021-08-07 16:00:00.000',
    '2026-02-02 05:15:10.591',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucuf005wg0v7jnagexq4',
    1300003,
    'Quiminales, John Lloyd',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-02 05:15:10.598',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucun005xg0v75xzk67ho',
    1300002,
    'Roslinda, Jonas',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-02 05:15:10.605',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucuv005yg0v7lv9azd46',
    1400009,
    'Alfonso, Ivy',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2025-07-06 16:00:00.000',
    '2026-02-02 05:15:10.613',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucva005zg0v7d1g1njvc',
    1400008,
    'Antonio, Yandie Grace',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2025-06-07 16:00:00.000',
    '2026-02-02 05:15:10.626',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucvh0060g0v7qd56mj7r',
    1400004,
    'Gunayan, Cherica',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-02 05:15:10.636',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucvy0061g0v71kkq7owh',
    1400002,
    'Igar, Feljhen R.',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-02 05:15:10.646',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucw70062g0v7gqt3fokk',
    1400005,
    'Quiminales, John Lloyd',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-02 05:15:10.662',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucwh0063g0v78x2p15tw',
    1400001,
    'Roslinda, Jonas',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2021-08-08 16:00:00.000',
    '2026-02-02 05:15:10.671',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucwm0064g0v7fbjv6n7g',
    1400003,
    'Sisi, Mila Flor',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-02 05:15:10.677',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucwt0065g0v71crxqlbj',
    1070003,
    'Fujidenzo Chest Freezer',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2024-10-04 16:00:00.000',
    '2026-02-02 05:15:10.684',
    1,
    '1 Unit',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucwy0066g0v77h9lak1m',
    1070001,
    'Server Computer',
    0,
    'Office Equipment',
    'No',
    'No',
    'Asset',
    '2021-08-03 16:00:00.000',
    '2026-02-02 05:15:10.689',
    1,
    '1 unit',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucx50067g0v7jng6vns5',
    1070004,
    'Supermarket Shelves',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2025-06-23 16:00:00.000',
    '2026-02-02 05:15:10.695',
    1,
    'Supermarket Shelves',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucxa0068g0v7kezagz91',
    1070002,
    'Wall Fan',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2024-08-22 16:00:00.000',
    '2026-02-02 05:15:10.701',
    1,
    '-',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucxf0069g0v780esy3u2',
    1070005,
    'Wireless Data POS System',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2025-11-20 16:00:00.000',
    '2026-02-02 05:15:10.706',
    1,
    '-',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucxm006ag0v7eflmddf0',
    1040000,
    '<>',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2021-08-08 16:00:00.000',
    '2026-02-02 05:15:10.714',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucxr006bg0v75qgcxv7p',
    1040003,
    'Bank monthly Interest',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-03-29 16:00:00.000',
    '2026-02-02 05:15:10.718',
    1,
    'Monthly Bank Interest',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucxy006cg0v7jo2tlsxg',
    1040016,
    'Borre, Arnold',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-09-02 16:00:00.000',
    '2026-02-02 05:15:10.725',
    1,
    'Rental',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucy3006dg0v7aakub6v4',
    1040004,
    'Cash Short/Over',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-02 05:15:10.730',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucy9006eg0v79uiff2ac',
    1040002,
    'Check Encashment Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-02-10 16:00:00.000',
    '2026-02-02 05:15:10.736',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucye006fg0v7s3wz1khf',
    1040017,
    'Daganato, Annie Jane',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-09-11 16:00:00.000',
    '2026-02-02 05:15:10.741',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucyk006gg0v788w1c0sm',
    1040012,
    'Damage Karton Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-11-13 16:00:00.000',
    '2026-02-02 05:15:10.746',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucyq006hg0v7tnkzz54x',
    1040007,
    'Display Allowance',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-02 05:15:10.753',
    1,
    'Supplier',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucyu006ig0v7sxv5zcx2',
    1040010,
    'Other Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-09-21 16:00:00.000',
    '2026-02-02 05:15:10.757',
    1,
    'Lhets',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pucz8006jg0v7kwciczfu',
    1040011,
    'Palawan Space Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-10-07 16:00:00.000',
    '2026-02-02 05:15:10.765',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puczl006kg0v7gomcpc86',
    1040001,
    'Photocopy Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-02-08 16:00:00.000',
    '2026-02-02 05:15:10.784',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puczv006lg0v7xin6eg04',
    1040008,
    'POS Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-02 05:15:10.793',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud07006mg0v7akzgcsei',
    1040015,
    'RENTAL INCOME',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-08-04 16:00:00.000',
    '2026-02-02 05:15:10.805',
    1,
    'Space Rental',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud0h006ng0v7ww4tcjez',
    1040018,
    'Solar, John Ray',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-11-04 16:00:00.000',
    '2026-02-02 05:15:10.815',
    1,
    'Rental',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud0n006og0v7a37e0n2l',
    1040006,
    'STL Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-02 05:15:10.822',
    1,
    'Monthly rental payment of MRG 1',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud10006pg0v71e8bywuq',
    1040005,
    'Suarez Area Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-02 05:15:10.833',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud19006qg0v7b6ifio8y',
    1040013,
    'Sunpride Foods-Pick up Allowance',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-01-06 16:00:00.000',
    '2026-02-02 05:15:10.843',
    1,
    'Freight',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud1e006rg0v78uac4575',
    1040014,
    'Suppliers Discount',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-02-13 16:00:00.000',
    '2026-02-02 05:15:10.849',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud1l006sg0v784m27wvd',
    1040009,
    'Tanduay Incentive Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-09-15 16:00:00.000',
    '2026-02-02 05:15:10.855',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud1q006tg0v77ff97hbe',
    1100005,
    'Ayr Warehouse Rental',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2025-06-11 16:00:00.000',
    '2026-02-02 05:15:10.861',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud1x006ug0v7z7otpimi',
    1100001,
    'Photo Copier',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2021-08-08 16:00:00.000',
    '2026-02-02 05:15:10.867',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud24006vg0v7i6k6k51t',
    1100003,
    'Suarez Rental Payment',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-28 16:00:00.000',
    '2026-02-02 05:15:10.874',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud2b006wg0v73pvfnjk0',
    1100002,
    'Temp Sales 20240830',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-27 16:00:00.000',
    '2026-02-02 05:15:10.881',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud2g006xg0v7kho6if4a',
    1100004,
    'Temp Sales 20240831',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-30 16:00:00.000',
    '2026-02-02 05:15:10.887',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud2m006yg0v79njlzxh3',
    1050055,
    'Accommodation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-21 16:00:00.000',
    '2026-02-02 05:15:10.892',
    1,
    'Hotel',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud2s006zg0v789iq2rxm',
    1050053,
    'Annual Insurance Payment',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-06 16:00:00.000',
    '2026-02-02 05:15:10.899',
    1,
    'The Mercantile Insurance Co.. INC',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud2y0070g0v7utt2w93a',
    1050032,
    'Bad Orders',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-27 16:00:00.000',
    '2026-02-02 05:15:10.905',
    1,
    'Open Seal, Bottle Breakages, Rat bites etc',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud360071g0v72s09cjsj',
    1050039,
    'Bank Fees Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-20 16:00:00.000',
    '2026-02-02 05:15:10.913',
    1,
    'Bank Fees Expense',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud3c0072g0v7k7qp1iia',
    1050046,
    'BIR 1701',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-02 05:15:10.918',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud3j0073g0v7zyrw8dg9',
    1050043,
    'BIR 1702Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-02 05:15:10.926',
    1,
    'BIR Quarterly Income paymeny',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud3o0074g0v7d0bpsury',
    1050044,
    'BIR 2250-M',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-02 05:15:10.931',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud3w0075g0v7yojer03x',
    1050049,
    'BIR 2550-M',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-23 16:00:00.000',
    '2026-02-02 05:15:10.939',
    1,
    'BIR Monthly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud410076g0v7xujuw29r',
    1050051,
    'BIR 2550-Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-01-22 16:00:00.000',
    '2026-02-02 05:15:10.944',
    1,
    'Quarterly Value Added tax',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud470077g0v7qn6txady',
    1050045,
    'BIR 2551-Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-02 05:15:10.950',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud4d0078g0v7rnl3lilo',
    1050001,
    'BIR Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2021-08-08 16:00:00.000',
    '2026-02-02 05:15:10.956',
    1,
    'Meal Expenses',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud4k0079g0v7vd5utm8r',
    1050026,
    'BIR Tax Defeciency Settlement',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-28 16:00:00.000',
    '2026-02-02 05:15:10.962',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud4q007ag0v709utdz87',
    1050040,
    'Bitpos Subscription Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-23 16:00:00.000',
    '2026-02-02 05:15:10.968',
    1,
    'monthly Subscription payments',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud4x007bg0v7mn5hbq2r',
    1050050,
    'Business Permit Fees',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-01-12 16:00:00.000',
    '2026-02-02 05:15:10.976',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud52007cg0v7kd87s24w',
    1050018,
    'Cash Advance Discoun',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:10.981',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud58007dg0v7p1qj3u11',
    1050035,
    'Cash Short/Over',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-02 16:00:00.000',
    '2026-02-02 05:15:10.986',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud5e007eg0v7dzqj8xs1',
    1050047,
    'Customer Shares',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-11 16:00:00.000',
    '2026-02-02 05:15:10.993',
    1,
    'Points and Loyalty Rewards',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud5j007fg0v7lidgp0s9',
    1050054,
    'Customized Shelves',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-10 16:00:00.000',
    '2026-02-02 05:15:10.998',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud5q007gg0v70h32oj46',
    1050007,
    'Electric Bill',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.005',
    1,
    'Monthly electric payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud5v007hg0v7mevwm2os',
    1050006,
    'Fuel',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.010',
    1,
    'All fuel expenses',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud63007ig0v7k8pbns1y',
    1050038,
    'Garbage Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-16 16:00:00.000',
    '2026-02-02 05:15:11.017',
    1,
    'Menro payment of bulk garbage disposal',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud68007jg0v7p7fep2z1',
    1050005,
    'Grocery area Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.023',
    1,
    'Twine/',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud6f007kg0v737pe9d1k',
    1050034,
    'Grocery Supplies Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-01 16:00:00.000',
    '2026-02-02 05:15:11.029',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud6k007lg0v71bq86eab',
    1050041,
    'Incentives',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-25 16:00:00.000',
    '2026-02-02 05:15:11.035',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud6r007mg0v722tnm27i',
    1050058,
    'Insurance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-07 16:00:00.000',
    '2026-02-02 05:15:11.041',
    1,
    'vehicle, building',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud6x007ng0v71nqcjka7',
    1050012,
    'Internet & Cellphone Load Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.048',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud73007og0v7e9qtx88k',
    1050002,
    'Legal Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-14 16:00:00.000',
    '2026-02-02 05:15:11.053',
    1,
    'All Notarized Documents and Court Apperances',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud79007pg0v7j7y1x2cd',
    1050008,
    'MAECC  Pag-ibig Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.060',
    1,
    'Employer share',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud7e007qg0v76ctmrx9b',
    1050010,
    'MAECC  Sss Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.065',
    1,
    'MAECC Employer Share',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud7k007rg0v7lvyi5h8q',
    1050027,
    'MAECC Permits',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-28 16:00:00.000',
    '2026-02-02 05:15:11.071',
    1,
    'Permits & Fees',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud7p007sg0v7it7kc3qa',
    1050009,
    'MAECC Philhealth Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.076',
    1,
    'MAECC Employer share',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud7x007tg0v7hwdrzxks',
    1050013,
    'Maintenance & Repair',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.084',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud82007ug0v7rdwmj3sq',
    1050056,
    'MARIOSOFT SYSTEM SOLUTIONS',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-05-02 16:00:00.000',
    '2026-02-02 05:15:11.089',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud87007vg0v7jmkr7h5h',
    1050011,
    'Meals',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.093',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud8d007wg0v7uh37qkhf',
    1050003,
    'Miscellaneous Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-17 16:00:00.000',
    '2026-02-02 05:15:11.100',
    1,
    'One time expense amounting to ABOVE 500.00',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud8i007xg0v71ckbv8oc',
    1050024,
    'Monthly Allocation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-10-12 16:00:00.000',
    '2026-02-02 05:15:11.105',
    1,
    'monthly travel allocation JYR',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud8p007yg0v7zxg83ec0',
    1050019,
    'Monthly Interest',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.112',
    1,
    'Asuncion Yanong monthly interest',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud8u007zg0v7ysm1uxuc',
    1050048,
    'Office Equipment',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-19 16:00:00.000',
    '2026-02-02 05:15:11.117',
    1,
    'Tangible Supplies',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud910080g0v70v9r83hx',
    1050014,
    'Office Supply',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.124',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud970081g0v745fzb8wp',
    1050028,
    'Other Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-02-27 16:00:00.000',
    '2026-02-02 05:15:11.130',
    1,
    'One time expense amounting to BELOW 500.00',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud9d0082g0v7wibp0oxm',
    1050059,
    'Outside/Security Services',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-15 16:00:00.000',
    '2026-02-02 05:15:11.136',
    1,
    'Security Agency Fee',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud9i0083g0v7prvxkpmn',
    1050029,
    'POS Monthly Subscription',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-24 16:00:00.000',
    '2026-02-02 05:15:11.141',
    1,
    'Bitpos Software subscription',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud9p0084g0v7rqd21ttt',
    1050057,
    'Professional Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-03 16:00:00.000',
    '2026-02-02 05:15:11.146',
    1,
    'Processing fee',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pud9v0085g0v7at7hn4x8',
    1050015,
    'Real Property Tax',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.154',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puda10086g0v71iqc63ro',
    1050025,
    'Repair & Maintenance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-10 16:00:00.000',
    '2026-02-02 05:15:11.159',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4puda80087g0v7g8hylhjq',
    1050036,
    'Retainers Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-04 16:00:00.000',
    '2026-02-02 05:15:11.166',
    1,
    'Payment of all fees rendered from service providers',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudad0088g0v78gtv5idk',
    1050023,
    'Salaries & Wages',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-20 16:00:00.000',
    '2026-02-02 05:15:11.172',
    1,
    'MAECC payroll',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudak0089g0v7z40vtfw2',
    1050033,
    'Security Guard Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-29 16:00:00.000',
    '2026-02-02 05:15:11.179',
    1,
    'Payroll',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudap008ag0v7mrwiqck2',
    1050022,
    'Shipping Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.184',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudaw008bg0v7onlev8bq',
    1050016,
    'Solicitation / Donation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.191',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudb1008cg0v7fk5nbnfg',
    1050030,
    'Stocks Unloading Expenses',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-26 16:00:00.000',
    '2026-02-02 05:15:11.196',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudbb008dg0v70l961mff',
    1050031,
    'Tanduay Jobing Discount Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-26 16:00:00.000',
    '2026-02-02 05:15:11.206',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudbf008eg0v7y5b454eh',
    1050004,
    'Transportation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.210',
    1,
    'Fare to public transpo',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudbm008fg0v7dv421t9o',
    1050042,
    'Trucking/Hauling Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-27 16:00:00.000',
    '2026-02-02 05:15:11.217',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudbs008gg0v7h622s06y',
    1050052,
    'Utility expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-02-19 16:00:00.000',
    '2026-02-02 05:15:11.223',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudc0008hg0v7mgug5cwf',
    1050020,
    'Vehicle Insurance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.230',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudc5008ig0v7sc9tbomx',
    1050037,
    'Vehicle Registration Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-12 16:00:00.000',
    '2026-02-02 05:15:11.236',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudcc008jg0v7fjtqy26k',
    1050021,
    'Vehicles Repair & Maintainance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.242',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml4pudcg008kg0v7sctr0a53',
    1050017,
    'Water Bill',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-02 05:15:11.248',
    1,
    NULL,
    'IS',
    'Active'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: inventory_transaction
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: invoice
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: invoice_item
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_board
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_card
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_column
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: notification
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product_history
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_order
# ------------------------------------------------------------

INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67e0000gwv7x391kn3d',
    'cmkxt7ev30000pov7aicz502z',
    '2026-01-28 09:24:03.968',
    NULL,
    NULL,
    'default',
    NULL,
    NULL,
    95008.56000000001,
    0,
    95008.56000000001,
    'Approved',
    '2026-01-28 09:24:04.008',
    '2026-02-02 03:53:06.847'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_order_item
# ------------------------------------------------------------

INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0001gwv7bma4l495',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Aloe Vera 25ml',
    40,
    33.25,
    0,
    798,
    'Baby Oil',
    NULL,
    '48038065',
    'pieces',
    24,
    24,
    40,
    NULL,
    NULL,
    33.25,
    NULL,
    NULL,
    NULL,
    798,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0002gwv7utpopl9n',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Aloe Vera 50ml',
    0,
    59.75,
    0,
    0,
    'Baby Oil',
    NULL,
    '4801010504207',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    59.75,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0003gwv70be2wl6j',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Bedtime 50ml',
    36,
    54.5,
    0,
    1962,
    'Baby Oil',
    NULL,
    '9556006060636',
    'pieces',
    1,
    24,
    36,
    1,
    NULL,
    54.5,
    NULL,
    NULL,
    NULL,
    1962,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0004gwv7ck0rou9e',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Lite 125ml',
    12,
    116.05,
    0,
    1392.6,
    'Baby Oil',
    NULL,
    '4801010503323',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    116.05,
    NULL,
    NULL,
    NULL,
    1392.6,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0005gwv71eby70pp',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Lite 25ml',
    36,
    33.25,
    0,
    1197,
    'Baby Oil',
    NULL,
    '48036016',
    'pieces',
    1,
    24,
    36,
    1,
    NULL,
    33.25,
    NULL,
    NULL,
    NULL,
    1197,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0006gwv7x2z85krh',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Lite 50ml',
    12,
    55.8,
    0,
    669.6,
    'Baby Oil',
    NULL,
    '4801010503224',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    55.8,
    NULL,
    NULL,
    NULL,
    669.6,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0007gwv7p5ywdckc',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Regular 125ml',
    6,
    97.55,
    0,
    585.3,
    'Baby Oil',
    NULL,
    '4801010501312',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    97.55,
    NULL,
    NULL,
    NULL,
    585.3,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0008gwv7jpbiv77b',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Regular 25ml',
    48,
    23.15,
    0,
    1111.2,
    'Baby Oil',
    NULL,
    '48035996',
    'pieces',
    1,
    48,
    48,
    1,
    NULL,
    23.15,
    NULL,
    NULL,
    NULL,
    1111.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g0009gwv720saf5o7',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Oil Regular 50ml',
    24,
    44.45,
    0,
    1066.8,
    'Baby Oil',
    NULL,
    '4801010501213',
    'pieces',
    1,
    48,
    24,
    1,
    NULL,
    44.45,
    NULL,
    NULL,
    NULL,
    1066.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000agwv7yqepeu8o',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnson Baby Milk Bath 50g',
    1,
    19.65,
    0,
    943.2,
    'Bath Soap',
    NULL,
    '4801010562313',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    19.65,
    NULL,
    NULL,
    NULL,
    943.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000bgwv7w5s4qs0e',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Bath Milk+Rice 100ml',
    24,
    60.85,
    0,
    1460.4,
    'Bath Soap',
    NULL,
    '9556006060308',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    60.85,
    NULL,
    NULL,
    NULL,
    1460.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000cgwv71gab56w3',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Bath Regular 100ml',
    6,
    49.85,
    0,
    299.1,
    'Bath Soap',
    NULL,
    '9556006060193',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    49.85,
    NULL,
    NULL,
    NULL,
    299.1,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000dgwv7eqz5iorb',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Bath Top to Toe Wash 100ml',
    12,
    85.15,
    0,
    1021.8,
    'Bath Soap',
    NULL,
    '9556006012086',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    85.15,
    NULL,
    NULL,
    NULL,
    1021.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000egwv703x2qsk5',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Soap Blossoms 50g',
    2,
    23.2,
    0,
    4454.4,
    'Bath Soap',
    NULL,
    '4801010561514',
    'Cases',
    1,
    60,
    2,
    96,
    NULL,
    23.2,
    NULL,
    NULL,
    NULL,
    4454.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000fgwv7q21r3826',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Soap Milk 100g',
    0,
    34.3,
    0,
    0,
    'Bath Soap',
    NULL,
    '4801010562108',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    34.3,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000ggwv7erqa80lb',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Soap Regular 75g',
    24,
    32.2,
    0,
    772.8,
    'Bath Soap',
    NULL,
    '4801010560456',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    32.2,
    NULL,
    NULL,
    NULL,
    772.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000hgwv7deq37mk0',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Blossoms Baby Soap 75g',
    2,
    37.3,
    0,
    7161.6,
    'Bath Soap',
    NULL,
    '4801010561521',
    'Cases',
    1,
    6,
    2,
    96,
    NULL,
    37.3,
    NULL,
    NULL,
    NULL,
    7161.6,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67g000igwv7fmtshx7r',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Milk Baby Soap 75g',
    48,
    37.3,
    0,
    1790.4,
    'Bath Soap',
    NULL,
    '4801010562320',
    'pieces',
    1,
    40,
    48,
    1,
    NULL,
    37.3,
    NULL,
    NULL,
    NULL,
    1790.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000jgwv74ox028bl',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Jonhsons B Soap Blossoms 100g',
    0,
    34.3,
    0,
    0,
    'Bath Soap',
    NULL,
    '4801010561309',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    34.3,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000kgwv7r6be3wwj',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Bedtime 100g',
    0,
    78.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010852',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    78.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000lgwv785e8mcp7',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Bedtime 200g',
    0,
    146.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010869',
    NULL,
    1,
    6,
    NULL,
    NULL,
    NULL,
    146.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000mgwv7hk9ejf0i',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Bedtime 25g',
    0,
    28.75,
    0,
    0,
    'Body Powder',
    NULL,
    '4801010120117',
    NULL,
    288,
    288,
    NULL,
    NULL,
    NULL,
    28.75,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000ngwv7w18saahm',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Bedtime 50g',
    0,
    40.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010890',
    NULL,
    72,
    72,
    NULL,
    NULL,
    NULL,
    40.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000ogwv77c6z4x6e',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Blossoms 100g',
    6,
    67.75,
    0,
    406.5,
    'Body Powder',
    NULL,
    '4801010105206',
    'pieces',
    12,
    12,
    6,
    1,
    NULL,
    67.75,
    NULL,
    NULL,
    NULL,
    406.5,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000pgwv7wv5y9oq3',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Blossoms 25g',
    96,
    21.25,
    0,
    2040,
    'Body Powder',
    NULL,
    '48040693',
    'pieces',
    288,
    288,
    96,
    1,
    NULL,
    21.25,
    NULL,
    NULL,
    NULL,
    2040,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000qgwv7wwjs6y8b',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Blossoms 50g',
    0,
    35.5,
    0,
    0,
    'Body Powder',
    NULL,
    '4801010105107',
    NULL,
    1,
    144,
    NULL,
    NULL,
    NULL,
    35.5,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000rgwv7c6zrytpm',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Classic 100g',
    24,
    58.75,
    0,
    1410,
    'Body Powder',
    NULL,
    '8850007011132',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    58.75,
    NULL,
    NULL,
    NULL,
    1410,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000sgwv70oasx0ga',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Classic 200g',
    0,
    113.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007011149',
    NULL,
    1,
    12,
    NULL,
    NULL,
    NULL,
    113.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000tgwv795pluvgy',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Classic 25g',
    96,
    20,
    0,
    1920,
    'Body Powder',
    NULL,
    '48032742',
    'pieces',
    1,
    288,
    96,
    1,
    NULL,
    20,
    NULL,
    NULL,
    NULL,
    1920,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000ugwv7fqgzlffs',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Classic 50g',
    24,
    30.5,
    0,
    732,
    'Body Powder',
    NULL,
    '48033459',
    'pieces',
    1,
    144,
    24,
    1,
    NULL,
    30.5,
    NULL,
    NULL,
    NULL,
    732,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000vgwv7v3m2kzvd',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Cooling 50g',
    96,
    24.4,
    0,
    2342.4,
    'Body Powder',
    NULL,
    '4801010107101',
    'pieces',
    1,
    24,
    96,
    1,
    NULL,
    24.4,
    NULL,
    NULL,
    NULL,
    2342.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000wgwv7u2rqf017',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Nourishing Milk 100g',
    18,
    57.85,
    0,
    1041.3,
    'Body Powder',
    NULL,
    '4801010104209',
    'pieces',
    1,
    24,
    18,
    1,
    NULL,
    57.85,
    NULL,
    NULL,
    NULL,
    1041.3,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000xgwv7j6yf82ex',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Nourishing Milk 200g',
    18,
    108.85,
    0,
    1959.3,
    'Body Powder',
    NULL,
    '8850007011743',
    'pieces',
    1,
    6,
    18,
    1,
    NULL,
    108.85,
    NULL,
    NULL,
    NULL,
    1959.3,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000ygwv71vk46vhy',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Nourishing Milk 25g',
    2,
    18.8,
    0,
    10828.8,
    'Body Powder',
    NULL,
    '4801010104001',
    'Cases',
    1,
    288,
    2,
    288,
    NULL,
    18.8,
    NULL,
    NULL,
    NULL,
    10828.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h000zgwv7srnhpaa3',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Nourishing Milk 50g',
    96,
    29.45,
    0,
    2827.2,
    'Body Powder',
    NULL,
    '4801010104100',
    'pieces',
    1,
    96,
    96,
    1,
    NULL,
    29.45,
    NULL,
    NULL,
    NULL,
    2827.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0010gwv7o5e3kz39',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Powder Pure Cornstarch 200g',
    18,
    90.85,
    0,
    1635.3,
    'Body Powder',
    NULL,
    '4801010110309',
    'pieces',
    1,
    12,
    18,
    1,
    NULL,
    90.85,
    NULL,
    NULL,
    NULL,
    1635.3,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0011gwv771hoju5l',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Happy Berries 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010127321',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0012gwv7yv275myz',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Heaven Scent 25ml',
    24,
    22.9,
    0,
    549.6,
    'Cologne',
    NULL,
    '48035989',
    'pieces',
    1,
    12,
    24,
    1,
    NULL,
    22.9,
    NULL,
    NULL,
    NULL,
    549.6,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0013gwv78uze6ecs',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Heaven Scent 50ml',
    48,
    32.95,
    0,
    1581.6,
    'Cologne',
    NULL,
    '4801010127215',
    'pieces',
    1,
    24,
    48,
    1,
    NULL,
    32.95,
    NULL,
    NULL,
    NULL,
    1581.6,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0014gwv7qefou5rb',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Hppy Berries 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010127222',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0015gwv79kvp89je',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Morning Dew 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010126317',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0016gwv71om2nw5c',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Morning Dew 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48032803',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0017gwv786ys33me',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Morning Dew 50ml',
    12,
    43.95,
    0,
    527.4,
    'Cologne',
    NULL,
    '4801010126218',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    527.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0018gwv7n8a53ogv',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Powder Mist 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010125303',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0019gwv791egp4qy',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Powder Mist 25ml',
    6,
    26.15,
    0,
    156.9,
    'Cologne',
    NULL,
    '48039086',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    156.9,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001agwv7x1qryz5r',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Powder Mist 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010125204',
    'pieces',
    1,
    18,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001bgwv7l62c1ykp',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Regular 25ml',
    12,
    27.05,
    0,
    324.6,
    'Cologne',
    NULL,
    '48032766',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    27.05,
    NULL,
    NULL,
    NULL,
    324.6,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001cgwv7wyqv8dhk',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Regular 50ml',
    12,
    39.2,
    0,
    470.4,
    'Cologne',
    NULL,
    '4801010121213',
    'pieces',
    1,
    6,
    12,
    1,
    NULL,
    39.2,
    NULL,
    NULL,
    NULL,
    470.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001dgwv71iysuf49',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Slide 125ml',
    12,
    89.2,
    0,
    1070.4,
    'Cologne',
    NULL,
    '4801010120223',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    1070.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001egwv7h3r6la6h',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Slide 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48040525',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001fgwv7gcx5qvwd',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Slide 50ml',
    12,
    43.95,
    0,
    527.4,
    'Cologne',
    NULL,
    '4801010120124',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    527.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001ggwv7erk515qn',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Summer Swing 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010122326',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001hgwv7t2t7oqnh',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Summer Swing 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48039116',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001igwv7eijo0wc7',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Cologne Summer Swing 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010122227',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001jgwv7js3uw5k3',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Lotion Milk+Rice 100ml',
    12,
    98.45,
    0,
    1181.4,
    'Lotion',
    NULL,
    '9556006060346',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    98.45,
    NULL,
    NULL,
    NULL,
    1181.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001kgwv7xcmxfp9e',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Lotion Milk+Rice 50ml',
    6,
    53.05,
    0,
    318.3,
    'Lotion',
    NULL,
    '4801010515104',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    53.05,
    NULL,
    NULL,
    NULL,
    318.3,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001lgwv7epxm6v0k',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Lotion Pink 50ml',
    6,
    46.9,
    0,
    281.4,
    'Lotion',
    NULL,
    '8850007031109',
    'pieces',
    1,
    1,
    6,
    1,
    NULL,
    46.9,
    NULL,
    NULL,
    NULL,
    281.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001mgwv7pyscexv2',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Lotion Regular 100ml',
    6,
    87.75,
    0,
    526.5,
    'Lotion',
    NULL,
    '8850007030744',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    87.75,
    NULL,
    NULL,
    NULL,
    526.5,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001ngwv7iq95w6p8',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Carefree Panty Liner Breathable 15s',
    0,
    25.8,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '4801010369127',
    NULL,
    1,
    12,
    NULL,
    NULL,
    NULL,
    25.8,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001ogwv7h6sz156b',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Carefree Panty Liner Breathable 20s',
    1,
    55.84,
    0,
    2010.24,
    'Sanitary Napkins',
    NULL,
    '8850007331261',
    'Cases',
    1,
    36,
    1,
    36,
    NULL,
    55.84,
    NULL,
    NULL,
    NULL,
    2010.24,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001pgwv7n9ylw8b5',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Carefree Panty Liner Breathable 8s',
    0,
    24.21,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '8850007331308',
    NULL,
    48,
    24,
    NULL,
    NULL,
    NULL,
    24.21,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001qgwv7vbzzv3nh',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Carefree Panty Liner Super Dry 15s',
    1,
    25.75,
    0,
    927,
    'Sanitary Napkins',
    NULL,
    '4801010361121',
    'Cases',
    1,
    36,
    1,
    36,
    NULL,
    25.75,
    NULL,
    NULL,
    NULL,
    927,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001rgwv7at7s9z4d',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Carefree Panty Liner Super Dry 8s',
    1,
    24.21,
    0,
    1162.08,
    'Sanitary Napkins',
    NULL,
    '8850007331384',
    'Cases',
    1,
    48,
    1,
    48,
    NULL,
    24.21,
    NULL,
    NULL,
    NULL,
    1162.08,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001sgwv7tez1x1fo',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Reg. Soft non-wing 12s',
    1,
    55.5,
    0,
    2664,
    'Sanitary Napkins',
    NULL,
    '8850007371441',
    'Cases',
    1,
    24,
    1,
    48,
    NULL,
    55.5,
    NULL,
    NULL,
    NULL,
    2664,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001tgwv71s6ek5xx',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Soft All Night w/ wings 4s',
    1,
    52.96,
    0,
    2542.08,
    'Sanitary Napkins',
    NULL,
    '4801010327103',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    52.96,
    NULL,
    NULL,
    NULL,
    2542.08,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001ugwv7ksuatvy1',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Soft Long w/ wings 8s',
    1,
    44.85,
    0,
    2152.8,
    'Sanitary Napkins',
    NULL,
    '8850007373261',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    44.85,
    NULL,
    NULL,
    NULL,
    2152.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001vgwv7yqavdwil',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Soft Reg. non-wing 8s',
    1,
    41.26,
    0,
    1980.48,
    'Sanitary Napkins',
    NULL,
    '8850007371397',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    41.26,
    NULL,
    NULL,
    NULL,
    1980.48,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001wgwv72x3tgjk8',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 16s',
    1,
    74.6,
    0,
    3580.8,
    'Sanitary Napkins',
    NULL,
    '8850007372882',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    74.6,
    NULL,
    NULL,
    NULL,
    3580.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001xgwv72us5ozpv',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 1pd',
    0,
    5,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '8850007374053',
    NULL,
    1,
    120,
    NULL,
    NULL,
    NULL,
    5,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001ygwv7duz48nd0',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 8s',
    1,
    41.26,
    0,
    1980.48,
    'Sanitary Napkins',
    NULL,
    '8850007371403',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    41.26,
    NULL,
    NULL,
    NULL,
    1980.48,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h001zgwv7248qav8v',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess Dry Max Maxi w/o Wings 8s',
    1,
    44.55,
    0,
    2138.4,
    'Sanitary Napkins',
    NULL,
    '8850007372561',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    44.55,
    NULL,
    NULL,
    NULL,
    2138.4,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0020gwv7vzuxhwwn',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Modess DryMax Maxi Wings 8s',
    1,
    45.9,
    0,
    2203.2,
    'Sanitary Napkins',
    NULL,
    '8850007371434',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    45.9,
    NULL,
    NULL,
    NULL,
    2203.2,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0021gwv7q66pmoty',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Shampoo Regular 100ml',
    24,
    97.25,
    0,
    2334,
    'Shampoo',
    NULL,
    '9556006014547',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    97.25,
    NULL,
    NULL,
    NULL,
    2334,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0022gwv7e2zd2d3n',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Shampoo Shiny Drops 100ml',
    24,
    89.95,
    0,
    2158.8,
    'Shampoo',
    NULL,
    '4801010524304',
    'pieces',
    1,
    48,
    24,
    1,
    NULL,
    89.95,
    NULL,
    NULL,
    NULL,
    2158.8,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0023gwv7b16wcoz0',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons B Shampoo w/ Honey 100ml',
    24,
    81.5,
    0,
    1956,
    'Shampoo',
    NULL,
    '9556006014585',
    'pieces',
    1,
    36,
    24,
    1,
    NULL,
    81.5,
    NULL,
    NULL,
    NULL,
    1956,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkxtj67h0024gwv72rk8fpfi',
    'cmkxtj67e0000gwv7x391kn3d',
    NULL,
    'Johnsons Baby Wipes 20s',
    0,
    50.6,
    0,
    0,
    'Wipe Tissue',
    NULL,
    '4710032504303',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    50.6,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-01-28 09:24:04.008',
    '2026-01-28 09:24:04.008'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: reminder
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: request
# ------------------------------------------------------------

INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '1171438d-913f-46a5-9eac-4e331c9d2d6c',
    'REQ-00001',
    'Roy',
    'Test',
    '12235',
    'test',
    NULL,
    'test',
    'test',
    0,
    '',
    '',
    '',
    '2026-01-29 05:34:22.953',
    'To Verify',
    '2026-01-29 05:34:22.953',
    '2026-01-29 05:34:22.953'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: request_item
# ------------------------------------------------------------

INSERT INTO
  `request_item` (
    `id`,
    `requestId`,
    `productId`,
    `description`,
    `quantity`,
    `unit`,
    `unitPrice`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'd6db4496-0334-4672-ba6d-bbcd5f28846e',
    '1171438d-913f-46a5-9eac-4e331c9d2d6c',
    NULL,
    'tets',
    1,
    NULL,
    100,
    100,
    '2026-01-29 05:34:22.953',
    '2026-01-29 05:34:22.953'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

INSERT INTO
  `supplier` (
    `id`,
    `name`,
    `contactPerson`,
    `email`,
    `phone`,
    `address`,
    `paymentTerms`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `additionalInfo`,
    `contactFirstName`,
    `fax`,
    `isTaxExempt`,
    `paymentTermsValue`,
    `phoneAlternative`,
    `vatInfo`
  )
VALUES
  (
    'cmkxt7ev30000pov7aicz502z',
    'Davao Reach Global Dist.Corp-Johnson',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    1,
    '2026-01-28 09:14:55.354',
    '2026-01-28 09:14:55.354',
    NULL,
    NULL,
    NULL,
    0,
    NULL,
    NULL,
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: transactions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`
  )
VALUES
  (
    'cmkz0donf0000mkv79698rf8x',
    'admin',
    'Rex',
    'Domingo',
    'manager@ljma.com',
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-01-29 05:23:31.464',
    '2026-01-29 05:23:31.464',
    '123700'
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
