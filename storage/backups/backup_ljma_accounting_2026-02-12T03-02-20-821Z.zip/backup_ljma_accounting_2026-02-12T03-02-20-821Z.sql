/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_job` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filePath` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileSize` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_schedule` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backupTime` datetime(3) NOT NULL,
  `frequency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: brand
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `brand` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brand_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `business_profile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `businessName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactTel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` longtext COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `bankDetails` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: category
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `category` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentCategoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `chart_of_account` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_no` int NOT NULL,
  `account_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` double DEFAULT '0',
  `account_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `last_updated_at` datetime(3) NOT NULL,
  `account_type_no` int NOT NULL DEFAULT '1',
  `account_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fs_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `chart_of_account_account_no_key` (`account_no`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `conversion_factor` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `factor` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactFirstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phonePrimary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `creditLimit` double DEFAULT '0',
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'days',
  `paymentTermsValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '30',
  `salesperson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerGroup` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `isEntitledToLoyaltyPoints` tinyint(1) NOT NULL DEFAULT '0',
  `pointSetting` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loyaltyCalculationMethod` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'automatic',
  `loyaltyCardNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: inventory_transaction
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `inventory_transaction` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `referenceId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_transaction_productId_fkey` (`productId`),
  CONSTRAINT `inventory_transaction_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: invoice
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `invoice` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerPONumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `dueDate` datetime(3) DEFAULT NULL,
  `terms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesperson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depositAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billingAddress` text COLLATE utf8mb4_unicode_ci,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci,
  `subtotal` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_invoiceNumber_key` (`invoiceNumber`),
  KEY `invoice_customerId_fkey` (`customerId`),
  CONSTRAINT `invoice_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: invoice_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `invoice_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double NOT NULL,
  `unitPrice` double NOT NULL,
  `total` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_item_invoiceId_fkey` (`invoiceId`),
  KEY `invoice_item_productId_fkey` (`productId`),
  CONSTRAINT `invoice_item_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_board
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_board` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_card
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_card` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `columnId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int NOT NULL,
  `transactionId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kanban_card_transactionId_key` (`transactionId`),
  KEY `kanban_card_columnId_fkey` (`columnId`),
  CONSTRAINT `kanban_card_columnId_fkey` FOREIGN KEY (`columnId`) REFERENCES `kanban_column` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kanban_card_transactionId_fkey` FOREIGN KEY (`transactionId`) REFERENCES `inventory_transaction` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: kanban_column
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `kanban_column` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `kanban_column_boardId_fkey` (`boardId`),
  CONSTRAINT `kanban_column_boardId_fkey` FOREIGN KEY (`boardId`) REFERENCES `kanban_board` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loyaltyCardId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalPoints` double NOT NULL DEFAULT '0',
  `pointSettingId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiryDate` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loyalty_point_customerId_fkey` (`customerId`),
  KEY `loyalty_point_pointSettingId_fkey` (`pointSettingId`),
  CONSTRAINT `loyalty_point_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loyalty_point_pointSettingId_fkey` FOREIGN KEY (`pointSettingId`) REFERENCES `loyalty_point_setting` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point_setting` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `equivalentPoint` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: notification
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `notification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_userId_idx` (`userId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalDescription` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategoryId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brandId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplierId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitOfMeasureId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `costPrice` double NOT NULL DEFAULT '0',
  `stockQuantity` int NOT NULL DEFAULT '0',
  `minStockLevel` int NOT NULL DEFAULT '0',
  `maxStockLevel` int DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `salesOrder` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoCreateChildren` tinyint(1) NOT NULL DEFAULT '0',
  `initialStock` int NOT NULL DEFAULT '0',
  `reorderPoint` int NOT NULL DEFAULT '0',
  `incomeAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expenseAccountId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product_history
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product_history` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `product_history_productId_fkey` (`productId`),
  CONSTRAINT `product_history_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_order
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplierId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime(3) NOT NULL,
  `vendorAddress` text COLLATE utf8mb4_unicode_ci,
  `shippingAddress` text COLLATE utf8mb4_unicode_ci,
  `taxType` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `privateComments` text COLLATE utf8mb4_unicode_ci,
  `subtotal` double NOT NULL DEFAULT '0',
  `taxTotal` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Open',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_supplierId_fkey` (`supplierId`),
  CONSTRAINT `purchase_order_supplierId_fkey` FOREIGN KEY (`supplierId`) REFERENCES `supplier` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: purchase_order_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `purchase_order_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchaseOrderId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itemDescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unitPrice` double NOT NULL,
  `tax` double DEFAULT NULL,
  `total` double NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyingUom` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtyPerCase` int DEFAULT NULL,
  `offtake` int DEFAULT NULL,
  `orderQty` int DEFAULT NULL,
  `pieces` int DEFAULT NULL,
  `costPricePerCase` double DEFAULT NULL,
  `costPricePerPiece` double DEFAULT NULL,
  `discount1` double DEFAULT NULL,
  `discount2` double DEFAULT NULL,
  `discount3` double DEFAULT NULL,
  `netCostAmount` double DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_item_purchaseOrderId_fkey` (`purchaseOrderId`),
  KEY `purchase_order_item_productId_fkey` (`productId`),
  CONSTRAINT `purchase_order_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `purchase_order_item_purchaseOrderId_fkey` FOREIGN KEY (`purchaseOrderId`) REFERENCES `purchase_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `reminder` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: request
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `request` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requesterName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessUnit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chargeTo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `verifiedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approvedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processedBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'To Verify',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `formName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_requestNumber_key` (`requestNumber`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: request_item
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `request_item` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `request_item_requestId_fkey` (`requestId`),
  KEY `request_item_productId_fkey` (`productId`),
  CONSTRAINT `request_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE
  SET
  NULL ON UPDATE CASCADE,
  CONSTRAINT `request_item_requestId_fkey` FOREIGN KEY (`requestId`) REFERENCES `request` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sales_user` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniqueId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_user_uniqueId_key` (`uniqueId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `supplier` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `additionalInfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactFirstName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTermsValue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vatInfo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: transactions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq` int DEFAULT NULL,
  `ledger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) DEFAULT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` double DEFAULT '0',
  `credit` double DEFAULT '0',
  `balance` double DEFAULT '0',
  `checkAccountNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateMatured` datetime(3) DEFAULT NULL,
  `accountName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankBranch` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCoincide` tinyint(1) DEFAULT NULL,
  `dailyClosing` int DEFAULT NULL,
  `approval` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToLedger` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToAccount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ssma_timestamp` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `unit_of_measure` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_of_measure_code_key` (`code`),
  UNIQUE KEY `unit_of_measure_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_permission` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formPermissions` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission_username_key` (`username`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '633b1ed0-9123-45f3-8a99-cb29424ecb5a',
    '18c54816d039175d5e3d48066161c51c38a976842d9175f25937c8802546a0ef',
    '2026-01-28 08:38:13.232',
    '20260106073417_add_sales_user',
    NULL,
    NULL,
    '2026-01-28 08:38:13.223',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '7af9b917-d2f7-4d87-88f1-6f74adea2a04',
    '9410e048b5ad0d68daf03be7f6f92f917f5b4f68a2028416ee1b934a356aa1a4',
    '2026-01-28 08:40:19.428',
    '20260128084018_add_purchase_order_item_bulk_fields',
    NULL,
    NULL,
    '2026-01-28 08:40:18.912',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'cb4ee741-ddbc-4113-b18f-3db64818dfcd',
    '5ebf57ea84ec53062797d0268b6568a9273cd404b143252c3a6594ca1c6d3dcb',
    '2026-01-28 08:38:13.203',
    '20251229060212_rename_account_number_to_accnt_no',
    NULL,
    NULL,
    '2026-01-28 08:38:13.021',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'd0cbf72e-05ce-465f-ad14-b9b7abfa57c8',
    '9e72cfb7e330ed4870fc06c8650133eacdb1398b8000acf6345707e7f652fcec',
    '2026-01-28 08:38:13.244',
    '20260106091627_add_user_permission_model',
    NULL,
    NULL,
    '2026-01-28 08:38:13.233',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'dff21d21-1ff6-4487-bc4d-7438e13794d4',
    'ce22d20a307f7a87b58fca9e5a6ba88f0e225960099123b743bc796342a88579',
    '2026-01-28 08:38:13.222',
    '20251229064442_add_accnt_type_no',
    NULL,
    NULL,
    '2026-01-28 08:38:13.204',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'ea6b7370-3e4b-4c20-852c-3095eb57dbfb',
    'bfc13f666e5ac3c35fc5e780387c886bc11d20d159a9394284390fdf55779dd6',
    '2026-01-30 05:34:04.269',
    '20260130053404_add_account_fields',
    NULL,
    NULL,
    '2026-01-30 05:34:04.257',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    'eb841330-8fdb-4cbe-b19a-f8d3c6c0245b',
    '74487f0a15539b305e49352d2ac9d99babea423b69a957868c25923c48e7a311',
    '2026-01-30 07:13:39.138',
    '20260130070956_sync_account_headers_rename_v2',
    NULL,
    NULL,
    '2026-01-30 07:13:39.074',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cml4qkcfm0000wov7st2xnzv9',
    'COMPLETED',
    'E:\\SOFTWARE\\#FIREBASE PROJECT\\LJMAAccounting\\storage\\backups\\backup_ljma_accounting_2026-02-02T05-35-23-145Z.zip',
    'backup_ljma_accounting_2026-02-02T05-35-23-145Z.zip',
    '0.01 MB',
    'admin',
    'Backup completed successfully.',
    '2026-02-02 05:35:23.119',
    '2026-02-02 05:35:23.381'
  );
INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cmlivi1z00000nsv78zhadbwp',
    'RUNNING',
    NULL,
    NULL,
    NULL,
    'admin',
    'Dumping database...',
    '2026-02-12 03:02:20.792',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: brand
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

INSERT INTO
  `business_profile` (
    `id`,
    `businessName`,
    `address`,
    `owner`,
    `contactPhone`,
    `contactTel`,
    `email`,
    `tin`,
    `permit`,
    `logo`,
    `createdAt`,
    `updatedAt`,
    `bankDetails`
  )
VALUES
  (
    'cml7m5pdo0000dov7l71wgi9z',
    'LJMA Accounting',
    'Maragusan, Davao de Oro',
    'Jonas Roslinda',
    '03957117604',
    '02 123456',
    'ljma@gmail..com',
    '125446359845426564',
    '213564816358797',
    NULL,
    '2026-02-04 05:55:20.123',
    '2026-02-04 05:55:20.123',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: category
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml0cg353000060v797rwczmo',
    1000,
    'Coins',
    1000,
    'Asset',
    'Yes',
    'No',
    'Asset',
    '2026-01-30 03:49:05.122',
    '2026-01-30 03:49:05.122',
    1,
    NULL,
    NULL,
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfqb0051pwv7p9a6oj1m',
    1080007,
    'Coins',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2024-08-20 16:00:00.000',
    '2026-02-03 10:53:36.609',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfqk0052pwv7r18x3xnx',
    1080006,
    'Contengency Funds',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2024-05-15 16:00:00.000',
    '2026-02-03 10:53:36.618',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfqr0053pwv7rd9t4mhr',
    1080003,
    'General Funds',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2023-01-03 16:00:00.000',
    '2026-02-03 10:53:36.625',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfr20054pwv7j1eibcf1',
    1080001,
    'Postdated Checks',
    0,
    'Cash',
    'No',
    'No',
    'Asset',
    '2021-08-07 16:00:00.000',
    '2026-02-03 10:53:36.636',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfr70055pwv7topdqqfi',
    1300004,
    'Cashier Expenses',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-09-27 16:00:00.000',
    '2026-02-03 10:53:36.642',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfrg0056pwv73xztjh04',
    1300001,
    'Gunayan, Cherica',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2021-08-07 16:00:00.000',
    '2026-02-03 10:53:36.650',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfro0057pwv7l6kh03l0',
    1300003,
    'Quiminales, John Lloyd',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-03 10:53:36.658',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfru0058pwv7fcid7cx9',
    1300002,
    'Roslinda, Jonas',
    0,
    'Cash on Hand',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-03 10:53:36.665',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfs40059pwv7429uaiwp',
    1400009,
    'Alfonso, Ivy',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2025-07-06 16:00:00.000',
    '2026-02-03 10:53:36.670',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfsc005apwv7vagpcey9',
    1400008,
    'Antonio, Yandie Grace',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2025-06-07 16:00:00.000',
    '2026-02-03 10:53:36.682',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfsk005bpwv7bzmcv30z',
    1400004,
    'Gunayan, Cherica',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-03 10:53:36.691',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfss005cpwv7fvaj6jue',
    1400002,
    'Igar, Feljhen R.',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-03 10:53:36.698',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdft4005dpwv7ot7wjkhc',
    1400005,
    'Quiminales, John Lloyd',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-09-05 16:00:00.000',
    '2026-02-03 10:53:36.710',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdftb005epwv7gcyzvbps',
    1400001,
    'Roslinda, Jonas',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:36.717',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfti005fpwv7x8hxwlpc',
    1400003,
    'Sisi, Mila Flor',
    0,
    'Fund Transfer',
    'No',
    'No',
    'Asset',
    '2024-08-31 16:00:00.000',
    '2026-02-03 10:53:36.724',
    1,
    NULL,
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdftq005gpwv706w7xhs2',
    1070003,
    'Fujidenzo Chest Freezer',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2024-10-04 16:00:00.000',
    '2026-02-03 10:53:36.732',
    1,
    '1 Unit',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfty005hpwv70otiqnmo',
    1070001,
    'Server Computer',
    0,
    'Office Equipment',
    'No',
    'No',
    'Asset',
    '2021-08-03 16:00:00.000',
    '2026-02-03 10:53:36.740',
    1,
    '1 unit',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfu4005ipwv7j0it3a1r',
    1070004,
    'Supermarket Shelves',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2025-06-23 16:00:00.000',
    '2026-02-03 10:53:36.746',
    1,
    'Supermarket Shelves',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfud005jpwv7oihnpuuy',
    1070002,
    'Wall Fan',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2024-08-22 16:00:00.000',
    '2026-02-03 10:53:36.755',
    1,
    '-',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfum005kpwv70x9cehmn',
    1070005,
    'Wireless Data POS System',
    0,
    'Store Equipments',
    'No',
    'No',
    'Asset',
    '2025-11-20 16:00:00.000',
    '2026-02-03 10:53:36.763',
    1,
    '-',
    'BS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfus005lpwv7vcee9slf',
    1040000,
    '<>',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:36.771',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfuw005mpwv7r09v5xaq',
    1040003,
    'Bank monthly Interest',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-03-29 16:00:00.000',
    '2026-02-03 10:53:36.775',
    1,
    'Monthly Bank Interest',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfv7005npwv70zeau55g',
    1040016,
    'Borre, Arnold',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-09-02 16:00:00.000',
    '2026-02-03 10:53:36.785',
    1,
    'Rental',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfvg005opwv7owwnt10o',
    1040004,
    'Cash Short/Over',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.794',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfvo005ppwv7b6aen8jk',
    1040002,
    'Check Encashment Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-02-10 16:00:00.000',
    '2026-02-03 10:53:36.802',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfw1005qpwv78yybywdd',
    1040017,
    'Daganato, Annie Jane',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-09-11 16:00:00.000',
    '2026-02-03 10:53:36.814',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfwe005rpwv7u69gm738',
    1040012,
    'Damage Karton Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:36.828',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfwy005spwv7ft8f1s43',
    1040007,
    'Display Allowance',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.848',
    1,
    'Supplier',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfx6005tpwv7zyqqx4vd',
    1040010,
    'Other Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-09-21 16:00:00.000',
    '2026-02-03 10:53:36.856',
    1,
    'Lhets',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfxe005upwv73ggsiulp',
    1040011,
    'Palawan Space Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-10-07 16:00:00.000',
    '2026-02-03 10:53:36.864',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfxk005vpwv7qo4ohurv',
    1040001,
    'Photocopy Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-02-08 16:00:00.000',
    '2026-02-03 10:53:36.869',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfxr005wpwv7usccbvmc',
    1040008,
    'POS Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.878',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfxz005xpwv7rkswvjyx',
    1040015,
    'RENTAL INCOME',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-08-04 16:00:00.000',
    '2026-02-03 10:53:36.884',
    1,
    'Space Rental',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfy6005ypwv7ka5q0a0m',
    1040018,
    'Solar, John Ray',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-11-04 16:00:00.000',
    '2026-02-03 10:53:36.892',
    1,
    'Rental',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfye005zpwv79n3pomxx',
    1040006,
    'STL Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.900',
    1,
    'Monthly rental payment of MRG 1',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfyk0060pwv7m45hkw5s',
    1040005,
    'Suarez Area Rental',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-05-08 16:00:00.000',
    '2026-02-03 10:53:36.907',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfyt0061pwv7econmjgi',
    1040013,
    'Sunpride Foods-Pick up Allowance',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-01-06 16:00:00.000',
    '2026-02-03 10:53:36.914',
    1,
    'Freight',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfz00062pwv7m747miod',
    1040014,
    'Suppliers Discount',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2025-02-13 16:00:00.000',
    '2026-02-03 10:53:36.923',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfz70063pwv72be331c4',
    1040009,
    'Tanduay Incentive Income',
    0,
    'Income',
    'No',
    'No',
    'Income',
    '2024-09-15 16:00:00.000',
    '2026-02-03 10:53:36.930',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfzd0064pwv74aijv81g',
    1100005,
    'Ayr Warehouse Rental',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2025-06-11 16:00:00.000',
    '2026-02-03 10:53:36.936',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfzm0065pwv7g2p0uwt8',
    1100001,
    'Photo Copier',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:36.944',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdfzw0066pwv710o3ases',
    1100003,
    'Suarez Rental Payment',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-28 16:00:00.000',
    '2026-02-03 10:53:36.952',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg020067pwv7ir7f24pi',
    1100002,
    'Temp Sales 20240830',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-27 16:00:00.000',
    '2026-02-03 10:53:36.961',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg090068pwv78bub1s8c',
    1100004,
    'Temp Sales 20240831',
    0,
    'Special Project',
    'No',
    'No',
    'Income',
    '2024-08-30 16:00:00.000',
    '2026-02-03 10:53:36.968',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg0m0069pwv7o44dl9rs',
    1050055,
    'Accommodation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-21 16:00:00.000',
    '2026-02-03 10:53:36.976',
    1,
    'Hotel',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg0s006apwv74ykybobw',
    1050053,
    'Annual Insurance Payment',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-06 16:00:00.000',
    '2026-02-03 10:53:36.987',
    1,
    'The Mercantile Insurance Co.. INC',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg11006bpwv7gf6njrtz',
    1050032,
    'Bad Orders',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-27 16:00:00.000',
    '2026-02-03 10:53:36.995',
    1,
    'Open Seal, Bottle Breakages, Rat bites etc',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg17006cpwv7bgaw7mwg',
    1050039,
    'Bank Fees Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-20 16:00:00.000',
    '2026-02-03 10:53:37.002',
    1,
    'Bank Fees Expense',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg1f006dpwv7qh31nqkm',
    1050046,
    'BIR 1701',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.010',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg1l006epwv7j5bf9gdz',
    1050043,
    'BIR 1702Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.016',
    1,
    'BIR Quarterly Income paymeny',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg1u006fpwv7fe6egux5',
    1050044,
    'BIR 2250-M',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.023',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg23006gpwv7xdyif7la',
    1050049,
    'BIR 2550-M',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-23 16:00:00.000',
    '2026-02-03 10:53:37.033',
    1,
    'BIR Monthly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg28006hpwv7pju97a7m',
    1050051,
    'BIR 2550-Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-01-22 16:00:00.000',
    '2026-02-03 10:53:37.039',
    1,
    'Quarterly Value Added tax',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg2g006ipwv797a28yhl',
    1050045,
    'BIR 2551-Q',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-11-13 16:00:00.000',
    '2026-02-03 10:53:37.046',
    1,
    'BIR Quarterly Income payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg2n006jpwv765p4h45t',
    1050001,
    'BIR Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2021-08-08 16:00:00.000',
    '2026-02-03 10:53:37.054',
    1,
    'Meal Expenses',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg2t006kpwv7rbrspvqx',
    1050026,
    'BIR Tax Defeciency Settlement',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-28 16:00:00.000',
    '2026-02-03 10:53:37.060',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg2y006lpwv7djl54b3k',
    1050040,
    'Bitpos Subscription Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-23 16:00:00.000',
    '2026-02-03 10:53:37.065',
    1,
    'monthly Subscription payments',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg37006mpwv7l7z7n7kd',
    1050050,
    'Business Permit Fees',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-01-12 16:00:00.000',
    '2026-02-03 10:53:37.073',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg3d006npwv7wpyl53jq',
    1050018,
    'Cash Advance Discoun',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.080',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg3m006opwv7redd8t9k',
    1050035,
    'Cash Short/Over',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-02 16:00:00.000',
    '2026-02-03 10:53:37.088',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg3t006ppwv7gba531u3',
    1050047,
    'Customer Shares',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-11 16:00:00.000',
    '2026-02-03 10:53:37.095',
    1,
    'Points and Loyalty Rewards',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg4m006qpwv7gakbjhlx',
    1050054,
    'Customized Shelves',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-03-10 16:00:00.000',
    '2026-02-03 10:53:37.124',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg52006rpwv7slpvszfe',
    1050007,
    'Electric Bill',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.140',
    1,
    'Monthly electric payment',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg5b006spwv7i8u1ube0',
    1050006,
    'Fuel',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.149',
    1,
    'All fuel expenses',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg5j006tpwv70xdgzlqs',
    1050038,
    'Garbage Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-16 16:00:00.000',
    '2026-02-03 10:53:37.157',
    1,
    'Menro payment of bulk garbage disposal',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg5r006upwv7x1e27ill',
    1050005,
    'Grocery area Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.164',
    1,
    'Twine/',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg5w006vpwv73ed95fy6',
    1050034,
    'Grocery Supplies Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-01 16:00:00.000',
    '2026-02-03 10:53:37.171',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg62006wpwv7wv1tvkij',
    1050041,
    'Incentives',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-25 16:00:00.000',
    '2026-02-03 10:53:37.177',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg6b006xpwv71yy82jq5',
    1050058,
    'Insurance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-07 16:00:00.000',
    '2026-02-03 10:53:37.185',
    1,
    'vehicle, building',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg6k006ypwv7wm7nfmvg',
    1050012,
    'Internet & Cellphone Load Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.195',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg6r006zpwv7o2ape4yt',
    1050002,
    'Legal Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-14 16:00:00.000',
    '2026-02-03 10:53:37.202',
    1,
    'All Notarized Documents and Court Apperances',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg6z0070pwv72082gbb9',
    1050008,
    'MAECC  Pag-ibig Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.209',
    1,
    'Employer share',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg7a0071pwv7o19a11uu',
    1050010,
    'MAECC  Sss Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.219',
    1,
    'MAECC Employer Share',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg7h0072pwv7rifpcko6',
    1050027,
    'MAECC Permits',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-28 16:00:00.000',
    '2026-02-03 10:53:37.228',
    1,
    'Permits & Fees',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg7p0073pwv79qfoubiq',
    1050009,
    'MAECC Philhealth Counterpart',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.235',
    1,
    'MAECC Employer share',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg7y0074pwv7sduhbjob',
    1050013,
    'Maintenance & Repair',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.243',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg840075pwv7lyd0hiy8',
    1050056,
    'MARIOSOFT SYSTEM SOLUTIONS',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-05-02 16:00:00.000',
    '2026-02-03 10:53:37.251',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg890076pwv7ojwcxkg9',
    1050011,
    'Meals',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.256',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg8h0077pwv7ma7ev3s2',
    1050003,
    'Miscellaneous Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-17 16:00:00.000',
    '2026-02-03 10:53:37.262',
    1,
    'One time expense amounting to ABOVE 500.00',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg8o0078pwv7x66jn1qz',
    1050024,
    'Monthly Allocation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-10-12 16:00:00.000',
    '2026-02-03 10:53:37.270',
    1,
    'monthly travel allocation JYR',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg8w0079pwv740ctbfju',
    1050019,
    'Monthly Interest',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.279',
    1,
    'Asuncion Yanong monthly interest',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg93007apwv72e4mfula',
    1050048,
    'Office Equipment',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-12-19 16:00:00.000',
    '2026-02-03 10:53:37.284',
    1,
    'Tangible Supplies',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg9a007bpwv7e24r5xmy',
    1050014,
    'Office Supply',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.293',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg9h007cpwv7c3u404u3',
    1050028,
    'Other Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-02-27 16:00:00.000',
    '2026-02-03 10:53:37.300',
    1,
    'One time expense amounting to BELOW 500.00',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg9n007dpwv7p6wr5xwu',
    1050059,
    'Outside/Security Services',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-15 16:00:00.000',
    '2026-02-03 10:53:37.306',
    1,
    'Security Agency Fee',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdg9u007epwv769z9mw5i',
    1050029,
    'POS Monthly Subscription',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-24 16:00:00.000',
    '2026-02-03 10:53:37.311',
    1,
    'Bitpos Software subscription',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdga2007fpwv7ii5nq59l',
    1050057,
    'Professional Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-09-03 16:00:00.000',
    '2026-02-03 10:53:37.321',
    1,
    'Processing fee',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgab007gpwv72qa2sbjv',
    1050015,
    'Real Property Tax',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.330',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgah007hpwv7rv39t8hy',
    1050025,
    'Repair & Maintenance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-01-10 16:00:00.000',
    '2026-02-03 10:53:37.335',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgap007ipwv71jl9f893',
    1050036,
    'Retainers Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-04 16:00:00.000',
    '2026-02-03 10:53:37.343',
    1,
    'Payment of all fees rendered from service providers',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgay007jpwv7ela6usyj',
    1050023,
    'Salaries & Wages',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-20 16:00:00.000',
    '2026-02-03 10:53:37.352',
    1,
    'MAECC payroll',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgb4007kpwv7agdav8v9',
    1050033,
    'Security Guard Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-29 16:00:00.000',
    '2026-02-03 10:53:37.359',
    1,
    'Payroll',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgb9007lpwv7voly3zmx',
    1050022,
    'Shipping Fee',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.364',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgbh007mpwv719n955o5',
    1050016,
    'Solicitation / Donation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.371',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgbo007npwv7n52hku0g',
    1050030,
    'Stocks Unloading Expenses',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-26 16:00:00.000',
    '2026-02-03 10:53:37.378',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgbv007opwv7jt4zjxdu',
    1050031,
    'Tanduay Jobing Discount Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-08-26 16:00:00.000',
    '2026-02-03 10:53:37.385',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgc4007ppwv76h8h886n',
    1050004,
    'Transportation',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.394',
    1,
    'Fare to public transpo',
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgcb007qpwv7i8zne056',
    1050042,
    'Trucking/Hauling Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-27 16:00:00.000',
    '2026-02-03 10:53:37.402',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgci007rpwv7bkujnt12',
    1050052,
    'Utility expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-02-19 16:00:00.000',
    '2026-02-03 10:53:37.408',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgcn007spwv70f4oo2co',
    1050020,
    'Vehicle Insurance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.414',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgcu007tpwv7caq4z0x6',
    1050037,
    'Vehicle Registration Expense',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2024-09-12 16:00:00.000',
    '2026-02-03 10:53:37.421',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgd1007upwv7m3k8prv0',
    1050021,
    'Vehicles Repair & Maintainance',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.428',
    1,
    NULL,
    'IS',
    'Active'
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `account_no`,
    `account_name`,
    `balance`,
    `account_type`,
    `header`,
    `bank`,
    `account_category`,
    `date_created`,
    `last_updated_at`,
    `account_type_no`,
    `account_description`,
    `fs_category`,
    `account_status`
  )
VALUES
  (
    'cml6hdgda007vpwv7m4oaahuz',
    1050017,
    'Water Bill',
    0,
    'Expense',
    'No',
    'No',
    'Expense',
    '2023-09-18 16:00:00.000',
    '2026-02-03 10:53:37.437',
    1,
    NULL,
    'IS',
    'Active'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: inventory_transaction
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: invoice
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: invoice_item
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_board
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_card
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: kanban_column
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: notification
# ------------------------------------------------------------

INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '082a7cea-612e-4b27-8919-b7efe17cddc0',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    0,
    '2026-02-03 10:46:29.899',
    'cml4yqb0j0000jgv7kq0t3fhs'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '1c22155e-aba2-49b6-8234-20f89aa7d148',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    0,
    '2026-02-03 10:46:29.899',
    'cml4yaaj900016kv7oliupi1e'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '22b00035-4768-44a2-a374-ed4ba0fac222',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    0,
    '2026-02-03 10:46:29.899',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '29b95a2c-1b4b-421d-9eee-b26c06bbee09',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    1,
    '2026-02-03 10:17:06.078',
    'cml4xg7sz00006kv7is4z8efq'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '3f0d978c-3e39-48d9-b0d7-7c25840f9047',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    0,
    '2026-02-02 09:31:35.424',
    'cml4yaaj900016kv7oliupi1e'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    '71907671-eac8-4fdd-aacb-fbb67e5da917',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    0,
    '2026-02-03 10:17:06.078',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'a10e58f1-049e-4b72-88d5-aeb3a8226512',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    0,
    '2026-02-02 09:31:35.424',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'cml630dg30001iwv7hes3at8l',
    'reminder_create',
    'New Reminder',
    'event ni',
    'cml630dfu0000iwv7ccb0u9nx',
    1,
    '2026-02-03 04:11:32.498',
    NULL
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'd5c3b56d-7d6f-4ebf-a802-905fafff995a',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    0,
    '2026-02-03 10:17:06.078',
    'cml4yqb0j0000jgv7kq0t3fhs'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'dc1da047-b222-4c2b-a364-29013e3848f6',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    1,
    '2026-02-02 09:31:35.424',
    'cml4yqb0j0000jgv7kq0t3fhs'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'e3d58d59-1f8d-4e3b-91a9-6b81b63fe930',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new REQUEST AND AUTHORIZATION OF CASH ADVANCES (REQ-00001) requires your verification.',
    'ec05873d-da80-400a-9e6e-451982aaf64d',
    0,
    '2026-02-03 08:47:08.172',
    'cml4ybmxx00026kv78dkx7znr'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'e871f8a5-ea64-4df9-8328-516c00bbc515',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00003) requires your verification.',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    1,
    '2026-02-03 10:46:29.899',
    'cml4xg7sz00006kv7is4z8efq'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'ebf058ed-0ef3-452b-ba20-2b5109b3383f',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00001) requires your verification.',
    'a96b6030-f28c-4600-b84b-6f57e08b07bd',
    1,
    '2026-02-02 09:04:18.118',
    'cml4xg7sz00006kv7is4z8efq'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'ec5edb3c-d990-4578-8f87-bdf3bfcdc937',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    0,
    '2026-02-03 10:17:06.078',
    'cml4yaaj900016kv7oliupi1e'
  );
INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`,
    `userId`
  )
VALUES
  (
    'fc625a98-c76c-4bf5-b58b-b41b89ce3b1c',
    'REQUEST_VERIFICATION',
    'New Request to Verify',
    'A new ACCOUNT DEDUCTION REQUEST FORM (REQ-00002) requires your verification.',
    '0409ad5a-a881-4083-9699-d8bddede78c3',
    1,
    '2026-02-02 09:31:35.424',
    'cml4xg7sz00006kv7is4z8efq'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product_history
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_order
# ------------------------------------------------------------

INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han4z002wpwv7jptm0cqf',
    'cmkxt7ev30000pov7aicz502z',
    '2026-02-03 10:51:26.207',
    NULL,
    NULL,
    'default',
    NULL,
    NULL,
    95008.56000000001,
    0,
    95008.56000000001,
    'Void',
    '2026-02-03 10:51:26.242',
    '2026-02-04 06:20:45.562'
  );
INSERT INTO
  `purchase_order` (
    `id`,
    `supplierId`,
    `date`,
    `vendorAddress`,
    `shippingAddress`,
    `taxType`,
    `comments`,
    `privateComments`,
    `subtotal`,
    `taxTotal`,
    `total`,
    `status`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlewujkb000ezcv7d2u5rgte',
    'cmkxt7ev30000pov7aicz502z',
    '2026-02-09 08:21:12.942',
    '',
    '',
    'default',
    '',
    '',
    4.17,
    0,
    4.17,
    'Open',
    '2026-02-09 08:28:58.377',
    '2026-02-09 08:28:58.377'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: purchase_order_item
# ------------------------------------------------------------

INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51002xpwv7pipk460x',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Aloe Vera 25ml',
    40,
    33.25,
    0,
    798,
    'Baby Oil',
    NULL,
    '48038065',
    'pieces',
    24,
    24,
    40,
    NULL,
    NULL,
    33.25,
    NULL,
    NULL,
    NULL,
    798,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51002ypwv7ju16zco2',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Aloe Vera 50ml',
    0,
    59.75,
    0,
    0,
    'Baby Oil',
    NULL,
    '4801010504207',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    59.75,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51002zpwv7mkmza89u',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Bedtime 50ml',
    36,
    54.5,
    0,
    1962,
    'Baby Oil',
    NULL,
    '9556006060636',
    'pieces',
    1,
    24,
    36,
    1,
    NULL,
    54.5,
    NULL,
    NULL,
    NULL,
    1962,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510030pwv70i3b1qsl',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Lite 125ml',
    12,
    116.05,
    0,
    1392.6,
    'Baby Oil',
    NULL,
    '4801010503323',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    116.05,
    NULL,
    NULL,
    NULL,
    1392.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510031pwv7ww5ckjd3',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Lite 25ml',
    36,
    33.25,
    0,
    1197,
    'Baby Oil',
    NULL,
    '48036016',
    'pieces',
    1,
    24,
    36,
    1,
    NULL,
    33.25,
    NULL,
    NULL,
    NULL,
    1197,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510032pwv7h9406o44',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Lite 50ml',
    12,
    55.8,
    0,
    669.6,
    'Baby Oil',
    NULL,
    '4801010503224',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    55.8,
    NULL,
    NULL,
    NULL,
    669.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510033pwv7flu8ydcc',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Regular 125ml',
    6,
    97.55,
    0,
    585.3,
    'Baby Oil',
    NULL,
    '4801010501312',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    97.55,
    NULL,
    NULL,
    NULL,
    585.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510034pwv763euqzlf',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Regular 25ml',
    48,
    23.15,
    0,
    1111.2,
    'Baby Oil',
    NULL,
    '48035996',
    'pieces',
    1,
    48,
    48,
    1,
    NULL,
    23.15,
    NULL,
    NULL,
    NULL,
    1111.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510035pwv7b12wbbbv',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Oil Regular 50ml',
    24,
    44.45,
    0,
    1066.8,
    'Baby Oil',
    NULL,
    '4801010501213',
    'pieces',
    1,
    48,
    24,
    1,
    NULL,
    44.45,
    NULL,
    NULL,
    NULL,
    1066.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510036pwv7g7flytac',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnson Baby Milk Bath 50g',
    1,
    19.65,
    0,
    943.2,
    'Bath Soap',
    NULL,
    '4801010562313',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    19.65,
    NULL,
    NULL,
    NULL,
    943.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510037pwv7uq0dvte0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Bath Milk+Rice 100ml',
    24,
    60.85,
    0,
    1460.4,
    'Bath Soap',
    NULL,
    '9556006060308',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    60.85,
    NULL,
    NULL,
    NULL,
    1460.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510038pwv7st556k9v',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Bath Regular 100ml',
    6,
    49.85,
    0,
    299.1,
    'Bath Soap',
    NULL,
    '9556006060193',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    49.85,
    NULL,
    NULL,
    NULL,
    299.1,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han510039pwv75e2kla3h',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Bath Top to Toe Wash 100ml',
    12,
    85.15,
    0,
    1021.8,
    'Bath Soap',
    NULL,
    '9556006012086',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    85.15,
    NULL,
    NULL,
    NULL,
    1021.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003apwv7ziqnztzn',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Soap Blossoms 50g',
    2,
    23.2,
    0,
    4454.4,
    'Bath Soap',
    NULL,
    '4801010561514',
    'Cases',
    1,
    60,
    2,
    96,
    NULL,
    23.2,
    NULL,
    NULL,
    NULL,
    4454.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003bpwv7xn4srnvb',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Soap Milk 100g',
    0,
    34.3,
    0,
    0,
    'Bath Soap',
    NULL,
    '4801010562108',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    34.3,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003cpwv7lfh8xb64',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Soap Regular 75g',
    24,
    32.2,
    0,
    772.8,
    'Bath Soap',
    NULL,
    '4801010560456',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    32.2,
    NULL,
    NULL,
    NULL,
    772.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003dpwv7l3wr0krv',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Blossoms Baby Soap 75g',
    2,
    37.3,
    0,
    7161.6,
    'Bath Soap',
    NULL,
    '4801010561521',
    'Cases',
    1,
    6,
    2,
    96,
    NULL,
    37.3,
    NULL,
    NULL,
    NULL,
    7161.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003epwv729946w1z',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Milk Baby Soap 75g',
    48,
    37.3,
    0,
    1790.4,
    'Bath Soap',
    NULL,
    '4801010562320',
    'pieces',
    1,
    40,
    48,
    1,
    NULL,
    37.3,
    NULL,
    NULL,
    NULL,
    1790.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003fpwv7xzmwr8ny',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Jonhsons B Soap Blossoms 100g',
    0,
    34.3,
    0,
    0,
    'Bath Soap',
    NULL,
    '4801010561309',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    34.3,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003gpwv7ngxwludx',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 100g',
    0,
    78.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010852',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    78.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003hpwv7ou1p672v',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 200g',
    0,
    146.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010869',
    NULL,
    1,
    6,
    NULL,
    NULL,
    NULL,
    146.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003ipwv7j6hud092',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 25g',
    0,
    28.75,
    0,
    0,
    'Body Powder',
    NULL,
    '4801010120117',
    NULL,
    288,
    288,
    NULL,
    NULL,
    NULL,
    28.75,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003jpwv7fqof95w9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Bedtime 50g',
    0,
    40.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007010890',
    NULL,
    72,
    72,
    NULL,
    NULL,
    NULL,
    40.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003kpwv7bbmekuwu',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Blossoms 100g',
    6,
    67.75,
    0,
    406.5,
    'Body Powder',
    NULL,
    '4801010105206',
    'pieces',
    12,
    12,
    6,
    1,
    NULL,
    67.75,
    NULL,
    NULL,
    NULL,
    406.5,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003lpwv7f85pz4op',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Blossoms 25g',
    96,
    21.25,
    0,
    2040,
    'Body Powder',
    NULL,
    '48040693',
    'pieces',
    288,
    288,
    96,
    1,
    NULL,
    21.25,
    NULL,
    NULL,
    NULL,
    2040,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003mpwv7kmk7oceo',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Blossoms 50g',
    0,
    35.5,
    0,
    0,
    'Body Powder',
    NULL,
    '4801010105107',
    NULL,
    1,
    144,
    NULL,
    NULL,
    NULL,
    35.5,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003npwv7ilsqj8bd',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 100g',
    24,
    58.75,
    0,
    1410,
    'Body Powder',
    NULL,
    '8850007011132',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    58.75,
    NULL,
    NULL,
    NULL,
    1410,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003opwv7m7g03601',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 200g',
    0,
    113.25,
    0,
    0,
    'Body Powder',
    NULL,
    '8850007011149',
    NULL,
    1,
    12,
    NULL,
    NULL,
    NULL,
    113.25,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003ppwv7h1e4fqd7',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 25g',
    96,
    20,
    0,
    1920,
    'Body Powder',
    NULL,
    '48032742',
    'pieces',
    1,
    288,
    96,
    1,
    NULL,
    20,
    NULL,
    NULL,
    NULL,
    1920,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003qpwv7j90430m5',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Classic 50g',
    24,
    30.5,
    0,
    732,
    'Body Powder',
    NULL,
    '48033459',
    'pieces',
    1,
    144,
    24,
    1,
    NULL,
    30.5,
    NULL,
    NULL,
    NULL,
    732,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003rpwv7nhag5q0a',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Cooling 50g',
    96,
    24.4,
    0,
    2342.4,
    'Body Powder',
    NULL,
    '4801010107101',
    'pieces',
    1,
    24,
    96,
    1,
    NULL,
    24.4,
    NULL,
    NULL,
    NULL,
    2342.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003spwv7jasfp4cn',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 100g',
    18,
    57.85,
    0,
    1041.3,
    'Body Powder',
    NULL,
    '4801010104209',
    'pieces',
    1,
    24,
    18,
    1,
    NULL,
    57.85,
    NULL,
    NULL,
    NULL,
    1041.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003tpwv7r578y4xl',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 200g',
    18,
    108.85,
    0,
    1959.3,
    'Body Powder',
    NULL,
    '8850007011743',
    'pieces',
    1,
    6,
    18,
    1,
    NULL,
    108.85,
    NULL,
    NULL,
    NULL,
    1959.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003upwv7931xb3u0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 25g',
    2,
    18.8,
    0,
    10828.8,
    'Body Powder',
    NULL,
    '4801010104001',
    'Cases',
    1,
    288,
    2,
    288,
    NULL,
    18.8,
    NULL,
    NULL,
    NULL,
    10828.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003vpwv78l5b4pma',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Nourishing Milk 50g',
    96,
    29.45,
    0,
    2827.2,
    'Body Powder',
    NULL,
    '4801010104100',
    'pieces',
    1,
    96,
    96,
    1,
    NULL,
    29.45,
    NULL,
    NULL,
    NULL,
    2827.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003wpwv7x4sztdic',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Powder Pure Cornstarch 200g',
    18,
    90.85,
    0,
    1635.3,
    'Body Powder',
    NULL,
    '4801010110309',
    'pieces',
    1,
    12,
    18,
    1,
    NULL,
    90.85,
    NULL,
    NULL,
    NULL,
    1635.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han51003xpwv70fz0vf3w',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Happy Berries 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010127321',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52003ypwv7wt17khk9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Heaven Scent 25ml',
    24,
    22.9,
    0,
    549.6,
    'Cologne',
    NULL,
    '48035989',
    'pieces',
    1,
    12,
    24,
    1,
    NULL,
    22.9,
    NULL,
    NULL,
    NULL,
    549.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52003zpwv7fdieycfu',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Heaven Scent 50ml',
    48,
    32.95,
    0,
    1581.6,
    'Cologne',
    NULL,
    '4801010127215',
    'pieces',
    1,
    24,
    48,
    1,
    NULL,
    32.95,
    NULL,
    NULL,
    NULL,
    1581.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520040pwv7dl4lhbqt',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Hppy Berries 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010127222',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520041pwv78c1k97r9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Morning Dew 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010126317',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520042pwv7r92ob38y',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Morning Dew 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48032803',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520043pwv7lseq140l',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Morning Dew 50ml',
    12,
    43.95,
    0,
    527.4,
    'Cologne',
    NULL,
    '4801010126218',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    527.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520044pwv7fhooxovk',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Powder Mist 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010125303',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520045pwv7natioq28',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Powder Mist 25ml',
    6,
    26.15,
    0,
    156.9,
    'Cologne',
    NULL,
    '48039086',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    156.9,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520046pwv7mffhr4ei',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Powder Mist 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010125204',
    'pieces',
    1,
    18,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520047pwv7dlsn4iet',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Regular 25ml',
    12,
    27.05,
    0,
    324.6,
    'Cologne',
    NULL,
    '48032766',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    27.05,
    NULL,
    NULL,
    NULL,
    324.6,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520048pwv7qd26wi07',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Regular 50ml',
    12,
    39.2,
    0,
    470.4,
    'Cologne',
    NULL,
    '4801010121213',
    'pieces',
    1,
    6,
    12,
    1,
    NULL,
    39.2,
    NULL,
    NULL,
    NULL,
    470.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520049pwv7yozhuoy3',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Slide 125ml',
    12,
    89.2,
    0,
    1070.4,
    'Cologne',
    NULL,
    '4801010120223',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    1070.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004apwv7exjvtcz8',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Slide 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48040525',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004bpwv7nnf3wx5o',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Slide 50ml',
    12,
    43.95,
    0,
    527.4,
    'Cologne',
    NULL,
    '4801010120124',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    527.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004cpwv7vsnox2jl',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Summer Swing 125ml',
    6,
    89.2,
    0,
    535.2,
    'Cologne',
    NULL,
    '4801010122326',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    89.2,
    NULL,
    NULL,
    NULL,
    535.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004dpwv73jhu1iyy',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Summer Swing 25ml',
    12,
    26.15,
    0,
    313.8,
    'Cologne',
    NULL,
    '48039116',
    'pieces',
    1,
    12,
    12,
    1,
    NULL,
    26.15,
    NULL,
    NULL,
    NULL,
    313.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004epwv7uskhefg1',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Cologne Summer Swing 50ml',
    6,
    43.95,
    0,
    263.7,
    'Cologne',
    NULL,
    '4801010122227',
    'pieces',
    1,
    12,
    6,
    1,
    NULL,
    43.95,
    NULL,
    NULL,
    NULL,
    263.7,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004fpwv790zaiqh0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Milk+Rice 100ml',
    12,
    98.45,
    0,
    1181.4,
    'Lotion',
    NULL,
    '9556006060346',
    'pieces',
    1,
    24,
    12,
    1,
    NULL,
    98.45,
    NULL,
    NULL,
    NULL,
    1181.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004gpwv76aeu0n46',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Milk+Rice 50ml',
    6,
    53.05,
    0,
    318.3,
    'Lotion',
    NULL,
    '4801010515104',
    'pieces',
    1,
    24,
    6,
    1,
    NULL,
    53.05,
    NULL,
    NULL,
    NULL,
    318.3,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004hpwv7nb47jyex',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Pink 50ml',
    6,
    46.9,
    0,
    281.4,
    'Lotion',
    NULL,
    '8850007031109',
    'pieces',
    1,
    1,
    6,
    1,
    NULL,
    46.9,
    NULL,
    NULL,
    NULL,
    281.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004ipwv727tpzc12',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Lotion Regular 100ml',
    6,
    87.75,
    0,
    526.5,
    'Lotion',
    NULL,
    '8850007030744',
    'pieces',
    1,
    6,
    6,
    1,
    NULL,
    87.75,
    NULL,
    NULL,
    NULL,
    526.5,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004jpwv73b98u7xq',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Breathable 15s',
    0,
    25.8,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '4801010369127',
    NULL,
    1,
    12,
    NULL,
    NULL,
    NULL,
    25.8,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004kpwv7ua3ioegf',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Breathable 20s',
    1,
    55.84,
    0,
    2010.24,
    'Sanitary Napkins',
    NULL,
    '8850007331261',
    'Cases',
    1,
    36,
    1,
    36,
    NULL,
    55.84,
    NULL,
    NULL,
    NULL,
    2010.24,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004lpwv7rlmo3ooo',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Breathable 8s',
    0,
    24.21,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '8850007331308',
    NULL,
    48,
    24,
    NULL,
    NULL,
    NULL,
    24.21,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004mpwv7cmrjr1w2',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Super Dry 15s',
    1,
    25.75,
    0,
    927,
    'Sanitary Napkins',
    NULL,
    '4801010361121',
    'Cases',
    1,
    36,
    1,
    36,
    NULL,
    25.75,
    NULL,
    NULL,
    NULL,
    927,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004npwv7u9ab20vx',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Carefree Panty Liner Super Dry 8s',
    1,
    24.21,
    0,
    1162.08,
    'Sanitary Napkins',
    NULL,
    '8850007331384',
    'Cases',
    1,
    48,
    1,
    48,
    NULL,
    24.21,
    NULL,
    NULL,
    NULL,
    1162.08,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004opwv7bimvs1ok',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Reg. Soft non-wing 12s',
    1,
    55.5,
    0,
    2664,
    'Sanitary Napkins',
    NULL,
    '8850007371441',
    'Cases',
    1,
    24,
    1,
    48,
    NULL,
    55.5,
    NULL,
    NULL,
    NULL,
    2664,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004ppwv7in6i4fji',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft All Night w/ wings 4s',
    1,
    52.96,
    0,
    2542.08,
    'Sanitary Napkins',
    NULL,
    '4801010327103',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    52.96,
    NULL,
    NULL,
    NULL,
    2542.08,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004qpwv706dtiwl0',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Long w/ wings 8s',
    1,
    44.85,
    0,
    2152.8,
    'Sanitary Napkins',
    NULL,
    '8850007373261',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    44.85,
    NULL,
    NULL,
    NULL,
    2152.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004rpwv7t0e3jsj7',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. non-wing 8s',
    1,
    41.26,
    0,
    1980.48,
    'Sanitary Napkins',
    NULL,
    '8850007371397',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    41.26,
    NULL,
    NULL,
    NULL,
    1980.48,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004spwv7j5hb7jb5',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 16s',
    1,
    74.6,
    0,
    3580.8,
    'Sanitary Napkins',
    NULL,
    '8850007372882',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    74.6,
    NULL,
    NULL,
    NULL,
    3580.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004tpwv77n7n2lo5',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 1pd',
    0,
    5,
    0,
    0,
    'Sanitary Napkins',
    NULL,
    '8850007374053',
    NULL,
    1,
    120,
    NULL,
    NULL,
    NULL,
    5,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004upwv7u2finl7f',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Cottony Soft Reg. w/ wings 8s',
    1,
    41.26,
    0,
    1980.48,
    'Sanitary Napkins',
    NULL,
    '8850007371403',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    41.26,
    NULL,
    NULL,
    NULL,
    1980.48,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004vpwv7zgeogeam',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess Dry Max Maxi w/o Wings 8s',
    1,
    44.55,
    0,
    2138.4,
    'Sanitary Napkins',
    NULL,
    '8850007372561',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    44.55,
    NULL,
    NULL,
    NULL,
    2138.4,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004wpwv7d1c90u44',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Modess DryMax Maxi Wings 8s',
    1,
    45.9,
    0,
    2203.2,
    'Sanitary Napkins',
    NULL,
    '8850007371434',
    'Cases',
    1,
    1,
    1,
    48,
    NULL,
    45.9,
    NULL,
    NULL,
    NULL,
    2203.2,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004xpwv7uqeztc0o',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Shampoo Regular 100ml',
    24,
    97.25,
    0,
    2334,
    'Shampoo',
    NULL,
    '9556006014547',
    'pieces',
    1,
    24,
    24,
    1,
    NULL,
    97.25,
    NULL,
    NULL,
    NULL,
    2334,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004ypwv7vngy3od9',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Shampoo Shiny Drops 100ml',
    24,
    89.95,
    0,
    2158.8,
    'Shampoo',
    NULL,
    '4801010524304',
    'pieces',
    1,
    48,
    24,
    1,
    NULL,
    89.95,
    NULL,
    NULL,
    NULL,
    2158.8,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han52004zpwv7362ew3ib',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons B Shampoo w/ Honey 100ml',
    24,
    81.5,
    0,
    1956,
    'Shampoo',
    NULL,
    '9556006014585',
    'pieces',
    1,
    36,
    24,
    1,
    NULL,
    81.5,
    NULL,
    NULL,
    NULL,
    1956,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cml6han520050pwv7wum4hp74',
    'cml6han4z002wpwv7jptm0cqf',
    NULL,
    'Johnsons Baby Wipes 20s',
    0,
    50.6,
    0,
    0,
    'Wipe Tissue',
    NULL,
    '4710032504303',
    NULL,
    1,
    24,
    NULL,
    NULL,
    NULL,
    50.6,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-03 10:51:26.242',
    '2026-02-03 10:51:26.242'
  );
INSERT INTO
  `purchase_order_item` (
    `id`,
    `purchaseOrderId`,
    `productId`,
    `itemDescription`,
    `quantity`,
    `unitPrice`,
    `tax`,
    `total`,
    `category`,
    `sku`,
    `barcode`,
    `buyingUom`,
    `qtyPerCase`,
    `offtake`,
    `orderQty`,
    `pieces`,
    `costPricePerCase`,
    `costPricePerPiece`,
    `discount1`,
    `discount2`,
    `discount3`,
    `netCostAmount`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmlewujkf000fzcv758sz8c0w',
    'cmlewujkb000ezcv7d2u5rgte',
    NULL,
    'SKYFLAKES',
    1,
    4.17,
    0,
    4.17,
    NULL,
    NULL,
    '387052121177',
    'pc',
    1,
    NULL,
    1,
    NULL,
    4.17,
    4.17,
    NULL,
    NULL,
    NULL,
    NULL,
    '2026-02-09 08:28:58.377',
    '2026-02-09 08:28:58.377'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

INSERT INTO
  `reminder` (
    `id`,
    `title`,
    `memo`,
    `date`,
    `endDate`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `isRead`
  )
VALUES
  (
    'cml630dfu0000iwv7ccb0u9nx',
    'event ni',
    'optional ni',
    '2026-02-03 01:00:51.187',
    NULL,
    1,
    '2026-02-03 04:11:32.488',
    '2026-02-03 04:11:32.488',
    0
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: request
# ------------------------------------------------------------

INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `formName`
  )
VALUES
  (
    '934294aa-f422-45af-9e87-5ffb7055b005',
    'REQ-00002',
    'Rex',
    'CCTV Installer',
    '123',
    'Software Dept',
    NULL,
    'Damage',
    'Charles',
    0,
    'Ver Fier 2',
    'Rex Domingo',
    'Rex Domingo',
    '2026-02-03 10:17:06.078',
    'To Verify',
    '2026-02-03 10:17:06.078',
    '2026-02-03 10:17:06.078',
    'ACCOUNT DEDUCTION REQUEST FORM'
  );
INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `formName`
  )
VALUES
  (
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    'REQ-00003',
    'YOng',
    'Gen Mngr',
    '12335',
    'ljma',
    NULL,
    'Damage Computer',
    'Jason',
    0,
    'Ver Fier',
    'Rex Domingo',
    'Rex Domingo',
    '2026-02-03 10:46:29.899',
    'To Verify',
    '2026-02-03 10:46:29.899',
    '2026-02-03 10:46:29.899',
    'ACCOUNT DEDUCTION REQUEST FORM'
  );
INSERT INTO
  `request` (
    `id`,
    `requestNumber`,
    `requesterName`,
    `position`,
    `accountNo`,
    `businessUnit`,
    `department`,
    `purpose`,
    `chargeTo`,
    `amount`,
    `verifiedBy`,
    `approvedBy`,
    `processedBy`,
    `date`,
    `status`,
    `createdAt`,
    `updatedAt`,
    `formName`
  )
VALUES
  (
    'ec05873d-da80-400a-9e6e-451982aaf64d',
    'REQ-00001',
    'Rex Domingo',
    NULL,
    NULL,
    NULL,
    NULL,
    'Employee Salary Cash Advance',
    NULL,
    15000,
    NULL,
    'Son Jha',
    NULL,
    '2026-02-03 08:47:08.172',
    'To Process',
    '2026-02-03 08:47:08.172',
    '2026-02-03 09:27:07.837',
    'REQUEST AND AUTHORIZATION OF CASH ADVANCES'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: request_item
# ------------------------------------------------------------

INSERT INTO
  `request_item` (
    `id`,
    `requestId`,
    `productId`,
    `description`,
    `quantity`,
    `unit`,
    `unitPrice`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '02559f1e-a48c-404c-8928-c9045a285a56',
    '934294aa-f422-45af-9e87-5ffb7055b005',
    NULL,
    'CCTV installer',
    1,
    NULL,
    0,
    0,
    '2026-02-03 10:17:06.078',
    '2026-02-03 10:17:06.078'
  );
INSERT INTO
  `request_item` (
    `id`,
    `requestId`,
    `productId`,
    `description`,
    `quantity`,
    `unit`,
    `unitPrice`,
    `total`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'a7878542-1963-4fff-946e-1ef0a981174c',
    'b618538c-0a48-4de7-9b3d-49919a4c2117',
    NULL,
    'Keyboard',
    1,
    NULL,
    449.97,
    449.97,
    '2026-02-03 10:46:29.899',
    '2026-02-03 10:46:29.899'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

INSERT INTO
  `supplier` (
    `id`,
    `name`,
    `contactPerson`,
    `email`,
    `phone`,
    `address`,
    `paymentTerms`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `additionalInfo`,
    `contactFirstName`,
    `fax`,
    `isTaxExempt`,
    `paymentTermsValue`,
    `phoneAlternative`,
    `vatInfo`
  )
VALUES
  (
    'cmkxt7ev30000pov7aicz502z',
    'Davao Reach Global Dist.Corp-Johnson',
    NULL,
    NULL,
    NULL,
    NULL,
    'COD',
    1,
    '2026-01-28 09:14:55.354',
    '2026-02-10 02:26:14.179',
    'Markup: 0%',
    NULL,
    NULL,
    0,
    '30',
    '09357117604',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: transactions
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cmkz0donf0000mkv79698rf8x',
    'admin',
    'Rex',
    'Domingo',
    'manager@ljma.com',
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-01-29 05:23:31.464',
    '2026-01-29 05:23:31.464',
    '123700',
    NULL,
    NULL
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4xg7sz00006kv7is4z8efq',
    'Ver',
    'Ver',
    'Fier',
    NULL,
    'Purchaser',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Purchases\",\"Suppliers\",\"Product Brand\",\"Category\",\"Unit of Measure\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH FUND REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\"]',
    1,
    '2026-02-02 08:48:07.807',
    '2026-02-02 08:48:07.807',
    '123',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4yaaj900016kv7oliupi1e',
    'Carl',
    'Carl',
    'Tuganay',
    NULL,
    'Auditor',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Adjustment History\",\"Purchases\",\"Sales\",\"Customers\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\"]',
    1,
    '2026-02-02 09:11:31.027',
    '2026-02-02 09:11:31.027',
    '123700',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4ybmxx00026kv78dkx7znr',
    'Son',
    'Son',
    'Jha',
    NULL,
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-02-02 09:12:33.764',
    '2026-02-02 09:12:33.764',
    '123',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml4yqb0j0000jgv7kq0t3fhs',
    'Ver2',
    'Ver',
    'Fier 2',
    NULL,
    'Purchaser',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Purchases\",\"Suppliers\",\"Product Brand\",\"Category\",\"Unit of Measure\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\"]',
    1,
    '2026-02-02 09:23:58.146',
    '2026-02-02 09:23:58.146',
    '123',
    NULL,
    'Verifier'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `password`,
    `designation`,
    `formPermissions`
  )
VALUES
  (
    'cml7e8di30000psv75i84gs9i',
    'Flor',
    'Flor',
    'Rebutabo',
    NULL,
    'Administrator',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Non-Invoiced Cash Sale\",\"Add/Edit user\",\"Reports\",\"Income Statement\",\"Balance Sheet\",\"ACCOUNT DEDUCTION REQUEST FORM\",\"CASH ADVANCE REQUEST FOR FOR CONTRACTOR\",\"CASH FUND REQUEST FORM\",\"CONTRACTOR CASH ADVANCE MONITORING FILE\",\"DISBURSEMENT\",\"HOUSE CHARGE REQUEST FORM\",\"JOB ORDER REQUEST FORM\",\"JOB ORDER REQUEST FORM INTERNAL\",\"MATERNAL REQUEST FORM\",\"PURCHASE ORDER REQUEST (EXTERNAL)\",\"PURCHASE ORDER REQUEST (SUPERMARKET)\",\"REQUEST AND AUTHORIZATION OF CASH ADVANCES\",\"STORE USE REQUEST FORM\"]',
    1,
    '2026-02-04 02:13:27.767',
    '2026-02-04 02:13:27.767',
    '123',
    NULL,
    'Approver'
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
