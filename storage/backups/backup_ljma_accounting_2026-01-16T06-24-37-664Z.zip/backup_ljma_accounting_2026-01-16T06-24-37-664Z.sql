/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `_prisma_migrations` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_job` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filePath` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileSize` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `completedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backup_schedule` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backupTime` datetime(3) NOT NULL,
  `frequency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: brand
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `brand` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brand_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `business_profile` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `businessName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactPhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactTel` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` longtext COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: category
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `category` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentCategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `chart_of_account` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `accnt_no` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` double DEFAULT '0',
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `header` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `accnt_type_no` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `chart_of_account_accnt_no_key` (`accnt_no`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `conversion_factor` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unitName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `factor` double NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: customer
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `customer` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactFirstName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phonePrimary` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneAlternative` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `creditLimit` double DEFAULT '0',
  `isTaxExempt` tinyint(1) NOT NULL DEFAULT '0',
  `paymentTerms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'days',
  `paymentTermsValue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '30',
  `salesperson` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerGroup` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `isEntitledToLoyaltyPoints` tinyint(1) NOT NULL DEFAULT '0',
  `pointSetting` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loyaltyCalculationMethod` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'automatic',
  `loyaltyCardNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `loyaltyCardId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalPoints` double NOT NULL DEFAULT '0',
  `pointSettingId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiryDate` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loyalty_point_customerId_fkey` (`customerId`),
  KEY `loyalty_point_pointSettingId_fkey` (`pointSettingId`),
  CONSTRAINT `loyalty_point_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loyalty_point_pointSettingId_fkey` FOREIGN KEY (`pointSettingId`) REFERENCES `loyalty_point_setting` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `loyalty_point_setting` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `equivalentPoint` double NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: notification
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `notification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entityId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: product
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `product` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalDescription` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subcategoryId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brandId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplierId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitOfMeasureId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitPrice` double NOT NULL DEFAULT '0',
  `costPrice` double NOT NULL DEFAULT '0',
  `stockQuantity` int NOT NULL DEFAULT '0',
  `minStockLevel` int NOT NULL DEFAULT '0',
  `maxStockLevel` int DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `salesOrder` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoCreateChildren` tinyint(1) NOT NULL DEFAULT '0',
  `initialStock` int NOT NULL DEFAULT '0',
  `reorderPoint` int NOT NULL DEFAULT '0',
  `incomeAccountId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expenseAccountId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code_key` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `reminder` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) NOT NULL,
  `endDate` datetime(3) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sales_user` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniqueId` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_user_uniqueId_key` (`uniqueId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: supplier
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `supplier` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPerson` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentTerms` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: transactions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq` int DEFAULT NULL,
  `ledger` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transNo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime(3) DEFAULT NULL,
  `invoiceNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `particulars` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debit` double DEFAULT '0',
  `credit` double DEFAULT '0',
  `balance` double DEFAULT '0',
  `checkAccountNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkNumber` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateMatured` datetime(3) DEFAULT NULL,
  `accountName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankName` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankBranch` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isCoincide` tinyint(1) DEFAULT NULL,
  `dailyClosing` int DEFAULT NULL,
  `approval` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToLedger` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ftToAccount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ssma_timestamp` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `unit_of_measure` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_of_measure_code_key` (`code`),
  UNIQUE KEY `unit_of_measure_name_key` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_permission` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permission_username_key` (`username`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: _prisma_migrations
# ------------------------------------------------------------

INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '5acb0466-2d50-4fee-a1d6-1e1fca5a6d0a',
    'ce22d20a307f7a87b58fca9e5a6ba88f0e225960099123b743bc796342a88579',
    '2025-12-29 06:44:42.322',
    '20251229064442_add_accnt_type_no',
    NULL,
    NULL,
    '2025-12-29 06:44:42.209',
    1
  );
INSERT INTO
  `_prisma_migrations` (
    `id`,
    `checksum`,
    `finished_at`,
    `migration_name`,
    `logs`,
    `rolled_back_at`,
    `started_at`,
    `applied_steps_count`
  )
VALUES
  (
    '84ea1c0a-9514-421e-882e-0b3dc359c71c',
    '5ebf57ea84ec53062797d0268b6568a9273cd404b143252c3a6594ca1c6d3dcb',
    '2025-12-29 06:02:13.219',
    '20251229060212_rename_account_number_to_accnt_no',
    NULL,
    NULL,
    '2025-12-29 06:02:12.372',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_job
# ------------------------------------------------------------

INSERT INTO
  `backup_job` (
    `id`,
    `status`,
    `filePath`,
    `fileName`,
    `fileSize`,
    `createdBy`,
    `log`,
    `createdAt`,
    `completedAt`
  )
VALUES
  (
    'cmkghu6tq0000a8v75rmm9lq7',
    'RUNNING',
    NULL,
    NULL,
    NULL,
    'admin@ljma.com',
    'Dumping database...',
    '2026-01-16 06:24:37.643',
    NULL
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backup_schedule
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: brand
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: business_profile
# ------------------------------------------------------------

INSERT INTO
  `business_profile` (
    `id`,
    `businessName`,
    `address`,
    `owner`,
    `contactPhone`,
    `contactTel`,
    `email`,
    `tin`,
    `permit`,
    `logo`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkdsj7sz0002bsv7d8nhxwk3',
    'LJMA Accounting',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    NULL,
    '2026-01-14 09:00:42.946',
    '2026-01-14 09:00:42.946'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: category
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: chart_of_account
# ------------------------------------------------------------

INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqray2200008cbktxyoaavy',
    4000,
    'General Sales',
    5000,
    'Income',
    'No',
    'Yes',
    'Income',
    '2025-12-29 06:07:35.397',
    '2025-12-29 06:07:35.397',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqrdlc600018cbks2593gvi',
    3000,
    'Issued Capital',
    5000,
    'Equity',
    'No',
    'No',
    'Equity',
    '2025-12-29 06:09:38.885',
    '2025-12-29 06:09:38.885',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqrfwnz00028cbkcekcohhr',
    1000,
    'Checking Account',
    50000,
    'Asset',
    'No',
    'No',
    'Asset',
    '2025-12-29 06:11:26.878',
    '2025-12-29 06:11:26.878',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqrsx0o00038cbkezpmbrl0',
    2000,
    'Credit Card',
    6500,
    'Liability',
    'No',
    'No',
    'Liability',
    '2025-12-29 06:21:33.863',
    '2025-12-29 06:21:33.863',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqs9s6v00048cbkppvihkuq',
    5000,
    'General Products Purchased',
    26000,
    'Expense',
    'Yes',
    'No',
    'Expense',
    '2025-12-29 06:34:40.758',
    '2025-12-29 06:34:40.758',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqtpm0l0000h8bkwys5tzu0',
    5001,
    'Saving Account',
    5000,
    'Expense',
    'No',
    'No',
    'Expense',
    '2025-12-29 07:14:58.867',
    '2025-12-29 07:14:58.867',
    2
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmjqtx89y0001h8bkoind87ip',
    4001,
    'Interest Revenue',
    6000,
    'Income',
    'No',
    'Yes',
    'Income',
    '2025-12-29 07:20:54.309',
    '2025-12-29 07:20:54.309',
    2
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y100000awv7vlhn1qn3',
    1110,
    'Checking Account',
    50000,
    'Asset',
    'No',
    'Yes',
    'Assets',
    '2026-01-14 08:46:30.463',
    '2026-01-14 08:46:30.463',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y180001awv7w1ypct44',
    1120,
    'Savings Account',
    100000,
    'Asset',
    'No',
    'Yes',
    'Assets',
    '2026-01-14 08:46:30.475',
    '2026-01-14 08:46:30.475',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y1d0002awv7oh3987ct',
    1150,
    'Undeposited Funds',
    0,
    'Asset',
    'No',
    'Yes',
    'Assets',
    '2026-01-14 08:46:30.480',
    '2026-01-14 08:46:30.480',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y1i0003awv71w8ilabu',
    1190,
    'Petty Cash',
    5000,
    'Asset',
    'No',
    'Yes',
    'Assets',
    '2026-01-14 08:46:30.485',
    '2026-01-14 08:46:30.485',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y1n0004awv7lhqjlgv4',
    1210,
    'Accounts Receivable',
    25000,
    'Asset',
    'No',
    'No',
    'Assets',
    '2026-01-14 08:46:30.489',
    '2026-01-14 08:46:30.489',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y1u0005awv7he2kma3x',
    1310,
    'Inventory',
    75000,
    'Asset',
    'No',
    'No',
    'Assets',
    '2026-01-14 08:46:30.496',
    '2026-01-14 08:46:30.496',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y1y0006awv733jwplny',
    2110,
    'Credit Card',
    -15000,
    'Liability',
    'No',
    'Yes',
    'Liabilities',
    '2026-01-14 08:46:30.501',
    '2026-01-14 08:46:30.501',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y210007awv7um7x5f5z',
    2150,
    'Loan',
    -50000,
    'Liability',
    'No',
    'No',
    'Liabilities',
    '2026-01-14 08:46:30.504',
    '2026-01-14 08:46:30.504',
    1
  );
INSERT INTO
  `chart_of_account` (
    `id`,
    `accnt_no`,
    `name`,
    `balance`,
    `type`,
    `header`,
    `bank`,
    `category`,
    `createdAt`,
    `updatedAt`,
    `accnt_type_no`
  )
VALUES
  (
    'cmkds0y240008awv7qetwq8at',
    2210,
    'Accounts Payable',
    -30000,
    'Liability',
    'No',
    'No',
    'Liabilities',
    '2026-01-14 08:46:30.508',
    '2026-01-14 08:46:30.508',
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: conversion_factor
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: customer
# ------------------------------------------------------------

INSERT INTO
  `customer` (
    `id`,
    `code`,
    `customerName`,
    `contactFirstName`,
    `address`,
    `phonePrimary`,
    `phoneAlternative`,
    `email`,
    `isActive`,
    `creditLimit`,
    `isTaxExempt`,
    `paymentTerms`,
    `paymentTermsValue`,
    `salesperson`,
    `customerGroup`,
    `isEntitledToLoyaltyPoints`,
    `pointSetting`,
    `loyaltyCalculationMethod`,
    `loyaltyCardNumber`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y39000hawv7zest4pfr',
    'CUST001',
    'John Doe',
    'John',
    '123 Main St, City',
    '+1234567890',
    NULL,
    'john.doe@example.com',
    1,
    50000,
    0,
    '30',
    '30',
    'Sales Team',
    'Regular',
    1,
    '1',
    'automatic',
    '1234567890123',
    '2026-01-14 08:46:30.548',
    '2026-01-14 08:48:29.330'
  );
INSERT INTO
  `customer` (
    `id`,
    `code`,
    `customerName`,
    `contactFirstName`,
    `address`,
    `phonePrimary`,
    `phoneAlternative`,
    `email`,
    `isActive`,
    `creditLimit`,
    `isTaxExempt`,
    `paymentTerms`,
    `paymentTermsValue`,
    `salesperson`,
    `customerGroup`,
    `isEntitledToLoyaltyPoints`,
    `pointSetting`,
    `loyaltyCalculationMethod`,
    `loyaltyCardNumber`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y3g000iawv73z3jxllm',
    'CUST002',
    'Jane Smith',
    'Jane',
    '456 Oak Ave, Town',
    '+1234567891',
    NULL,
    'jane.smith@example.com',
    1,
    75000,
    0,
    '15',
    '15',
    'Sales Team',
    'VIP',
    1,
    '2',
    'automatic',
    '9876543210987',
    '2026-01-14 08:46:30.554',
    '2026-01-14 08:48:29.336'
  );
INSERT INTO
  `customer` (
    `id`,
    `code`,
    `customerName`,
    `contactFirstName`,
    `address`,
    `phonePrimary`,
    `phoneAlternative`,
    `email`,
    `isActive`,
    `creditLimit`,
    `isTaxExempt`,
    `paymentTerms`,
    `paymentTermsValue`,
    `salesperson`,
    `customerGroup`,
    `isEntitledToLoyaltyPoints`,
    `pointSetting`,
    `loyaltyCalculationMethod`,
    `loyaltyCardNumber`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y3m000jawv7txvvlc5w',
    'CUST003',
    'Bob Johnson',
    'Bob',
    '789 Pine Rd, Village',
    '+1234567892',
    NULL,
    'bob.johnson@example.com',
    1,
    25000,
    0,
    '30',
    '30',
    'Sales Team',
    'Regular',
    0,
    NULL,
    'automatic',
    NULL,
    '2026-01-14 08:46:30.560',
    '2026-01-14 08:48:29.342'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point
# ------------------------------------------------------------

INSERT INTO
  `loyalty_point` (
    `id`,
    `customerId`,
    `loyaltyCardId`,
    `totalPoints`,
    `pointSettingId`,
    `expiryDate`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hr7000880v7ht748yxg',
    'cmkds0y39000hawv7zest4pfr',
    '1234567890123',
    150,
    'cmkds3hqe000580v7irm6taar',
    '2026-12-31 00:00:00.000',
    '2026-01-14 08:48:29.347',
    '2026-01-14 08:48:29.347'
  );
INSERT INTO
  `loyalty_point` (
    `id`,
    `customerId`,
    `loyaltyCardId`,
    `totalPoints`,
    `pointSettingId`,
    `expiryDate`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hra000980v706y3jnmq',
    'cmkds0y3g000iawv73z3jxllm',
    '9876543210987',
    450,
    'cmkds3hqg000680v7mprd4kbp',
    '2026-12-31 00:00:00.000',
    '2026-01-14 08:48:29.350',
    '2026-01-14 08:48:29.350'
  );
INSERT INTO
  `loyalty_point` (
    `id`,
    `customerId`,
    `loyaltyCardId`,
    `totalPoints`,
    `pointSettingId`,
    `expiryDate`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hrd000a80v755qt7x0o',
    'cmkds0y39000hawv7zest4pfr',
    '1234567890123',
    75,
    'cmkds3hqe000580v7irm6taar',
    '2025-12-31 00:00:00.000',
    '2026-01-14 08:48:29.353',
    '2026-01-14 08:48:29.353'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: loyalty_point_setting
# ------------------------------------------------------------

INSERT INTO
  `loyalty_point_setting` (
    `id`,
    `description`,
    `amount`,
    `equivalentPoint`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hqe000580v7irm6taar',
    'Every P100 = 1 point',
    100,
    1,
    '2026-01-14 08:48:29.317',
    '2026-01-14 08:48:29.317'
  );
INSERT INTO
  `loyalty_point_setting` (
    `id`,
    `description`,
    `amount`,
    `equivalentPoint`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hqg000680v7mprd4kbp',
    'Every P200 = 3 points',
    200,
    3,
    '2026-01-14 08:48:29.320',
    '2026-01-14 08:48:29.320'
  );
INSERT INTO
  `loyalty_point_setting` (
    `id`,
    `description`,
    `amount`,
    `equivalentPoint`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hqk000780v734mfmagy',
    'Every P500 = 10 points',
    500,
    10,
    '2026-01-14 08:48:29.323',
    '2026-01-14 08:48:29.323'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: notification
# ------------------------------------------------------------

INSERT INTO
  `notification` (
    `id`,
    `type`,
    `title`,
    `message`,
    `entityId`,
    `isRead`,
    `createdAt`
  )
VALUES
  (
    'cmkdsiqec0001bsv76hslnccm',
    'reminder_create',
    'New Reminder',
    'Meeting CRM',
    'cmkdsiqe40000bsv71iur22vg',
    1,
    '2026-01-14 09:00:20.388'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: product
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: reminder
# ------------------------------------------------------------

INSERT INTO
  `reminder` (
    `id`,
    `title`,
    `memo`,
    `date`,
    `endDate`,
    `isActive`,
    `createdAt`,
    `updatedAt`,
    `isRead`
  )
VALUES
  (
    'cmkdsiqe40000bsv71iur22vg',
    'Meeting CRM',
    'Meeting with the team',
    '2026-01-14 09:01:00.000',
    NULL,
    1,
    '2026-01-14 09:00:20.377',
    '2026-01-14 09:00:20.377',
    0
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sales_user
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: supplier
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: transactions
# ------------------------------------------------------------

INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y290009awv70p1mr56m',
    12345,
    'General',
    'txn_12345',
    'txn_12345',
    'acct_business_checking',
    '2023-10-26 10:00:00.000',
    NULL,
    'Invoice Payment #INV-2023-001',
    5000,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:46:30.513',
    '2026-01-14 08:46:30.513'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y2g000aawv7xqz4ry45',
    12346,
    'General',
    'txn_12346',
    'txn_12346',
    'acct_corporate_card',
    '2023-10-26 11:30:00.000',
    NULL,
    'Office Supplies',
    250.75,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:46:30.519',
    '2026-01-14 08:46:30.519'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y2k000bawv767puwefx',
    12347,
    'General',
    'txn_12347',
    'txn_12347',
    'acct_business_savings',
    '2023-10-27 14:00:00.000',
    NULL,
    'Urgent Fund Transfer',
    10000,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:46:30.524',
    '2026-01-14 08:46:30.524'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y2o000cawv7lchfaetz',
    12348,
    'General',
    'txn_12348',
    'txn_12348',
    'acct_unknown_offshore',
    '2023-10-27 14:05:00.000',
    NULL,
    'Reversal of txn_12347',
    9999.99,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:46:30.527',
    '2026-01-14 08:46:30.527'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds0y2s000dawv7ti4pl11c',
    12349,
    'General',
    'txn_12349',
    'txn_12349',
    'acct_marketing_budget',
    '2023-10-28 23:55:00.000',
    NULL,
    'Marketing Subscription',
    499.99,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:46:30.531',
    '2026-01-14 08:46:30.531'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds2uq600000cv7sdpryf8o',
    12345,
    'General',
    'txn_12345',
    'txn_12345',
    'acct_business_checking',
    '2023-10-26 10:00:00.000',
    NULL,
    'Invoice Payment #INV-2023-001',
    5000,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:47:59.502',
    '2026-01-14 08:47:59.502'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds2uqc00010cv7ni3vvz3o',
    12346,
    'General',
    'txn_12346',
    'txn_12346',
    'acct_corporate_card',
    '2023-10-26 11:30:00.000',
    NULL,
    'Office Supplies',
    250.75,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:47:59.508',
    '2026-01-14 08:47:59.508'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds2uqf00020cv7g6i4ctxk',
    12347,
    'General',
    'txn_12347',
    'txn_12347',
    'acct_business_savings',
    '2023-10-27 14:00:00.000',
    NULL,
    'Urgent Fund Transfer',
    10000,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:47:59.511',
    '2026-01-14 08:47:59.511'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds2uqi00030cv71ulqa9q1',
    12348,
    'General',
    'txn_12348',
    'txn_12348',
    'acct_unknown_offshore',
    '2023-10-27 14:05:00.000',
    NULL,
    'Reversal of txn_12347',
    9999.99,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:47:59.514',
    '2026-01-14 08:47:59.514'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds2uqn00040cv7d908ijvj',
    12349,
    'General',
    'txn_12349',
    'txn_12349',
    'acct_marketing_budget',
    '2023-10-28 23:55:00.000',
    NULL,
    'Marketing Subscription',
    499.99,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:47:59.519',
    '2026-01-14 08:47:59.519'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hpq000080v7ccinjjxp',
    12345,
    'General',
    'txn_12345',
    'txn_12345',
    'acct_business_checking',
    '2023-10-26 10:00:00.000',
    NULL,
    'Invoice Payment #INV-2023-001',
    5000,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:48:29.294',
    '2026-01-14 08:48:29.294'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hpw000180v7ilmakttv',
    12346,
    'General',
    'txn_12346',
    'txn_12346',
    'acct_corporate_card',
    '2023-10-26 11:30:00.000',
    NULL,
    'Office Supplies',
    250.75,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:48:29.299',
    '2026-01-14 08:48:29.299'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hpz000280v77qi3danw',
    12347,
    'General',
    'txn_12347',
    'txn_12347',
    'acct_business_savings',
    '2023-10-27 14:00:00.000',
    NULL,
    'Urgent Fund Transfer',
    10000,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:48:29.302',
    '2026-01-14 08:48:29.302'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hq3000380v7ipzdcyf9',
    12348,
    'General',
    'txn_12348',
    'txn_12348',
    'acct_unknown_offshore',
    '2023-10-27 14:05:00.000',
    NULL,
    'Reversal of txn_12347',
    9999.99,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:48:29.306',
    '2026-01-14 08:48:29.306'
  );
INSERT INTO
  `transactions` (
    `id`,
    `seq`,
    `ledger`,
    `transNo`,
    `code`,
    `accountNumber`,
    `date`,
    `invoiceNumber`,
    `particulars`,
    `debit`,
    `credit`,
    `balance`,
    `checkAccountNumber`,
    `checkNumber`,
    `dateMatured`,
    `accountName`,
    `bankName`,
    `bankBranch`,
    `user`,
    `isCoincide`,
    `dailyClosing`,
    `approval`,
    `ftToLedger`,
    `ftToAccount`,
    `ssma_timestamp`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hq6000480v7aia27fgj',
    12349,
    'General',
    'txn_12349',
    'txn_12349',
    'acct_marketing_budget',
    '2023-10-28 23:55:00.000',
    NULL,
    'Marketing Subscription',
    499.99,
    0,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'system',
    NULL,
    NULL,
    'Auto',
    NULL,
    NULL,
    NULL,
    '2026-01-14 08:48:29.310',
    '2026-01-14 08:48:29.310'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: unit_of_measure
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_permission
# ------------------------------------------------------------

INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `password`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkds3hri000b80v7cangiy0n',
    'admin@ljma.com',
    'Super',
    'Admin',
    NULL,
    'Admin',
    'admin123',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Setup\",\"Cashier Admin\",\"Backup Database\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\",\"Add/Edit user\"]',
    1,
    '2026-01-14 08:48:29.356',
    '2026-01-14 08:48:29.356'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `password`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkgapfut0000q4v7jy2qeg8s',
    'audit',
    'Audit',
    'Tor',
    'admin@ljma.com',
    'Auditor',
    '123',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Adjustment History\",\"Purchases\",\"Sales\",\"Customers\",\"Reports\",\"Income Statement\",\"Balance Sheet\"]',
    1,
    '2026-01-16 03:04:58.752',
    '2026-01-16 03:04:58.752'
  );
INSERT INTO
  `user_permission` (
    `id`,
    `username`,
    `firstName`,
    `lastName`,
    `contactNo`,
    `accountType`,
    `password`,
    `permissions`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'cmkgbd2bs000010v7i1e141bp',
    'manager',
    'Man',
    'Ager',
    'manager@ljma.com',
    'Manager',
    '123',
    '[\"Dashboard\",\"Inventory\",\"Stocks\",\"Stock movement\",\"Stock Adjustment\",\"Adjustment History\",\"Purchases\",\"Warehouse\",\"Product Brand\",\"Category\",\"Price Type\",\"Unit of Measure\",\"Sales\",\"Customers\",\"Suppliers\",\"Cashier Admin\",\"Positive Adjustment\",\"Negative Adjustment\",\"Transfer Stocks\",\"Add Purchase Order\",\"Approve Purchase Order\",\"Receive Purchase Order\",\"Void Purchase Order\",\"Add/Edit Purchase Cost\",\"Add/Edit Category\",\"Add/Edit Price Type\",\"Customer List\",\"Customer Balances\",\"Customer Payment\",\"Customer Loyalty Points\",\"Loyalty Points Setting\"]',
    1,
    '2026-01-16 03:23:20.966',
    '2026-01-16 03:23:20.966'
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
